#!/usr/bin/env python3
"""no_question 改名探针（v2）：判题返回空 results 时 error.code 与记录 error
均为 no_question，旧名 no_question_detected 不再出现。

用法：python3 tests/probe_no_question.py
  进程内跑：建临时 Store＋job，把 judge.judge_image 桩成返回空 results，
  直接调 gateway._run_judge，再断言 job 与 solve_failed 记录。
  不起 HTTP 服务，不需要 Qwen Key。退出码 0=通过，1=失败。
"""
import os
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)

os.environ["JIANTI_DATA_DIR"] = tempfile.mkdtemp(prefix="v3test-noq-")

import gateway  # noqa: E402
import judge  # noqa: E402
from models import new_job  # noqa: E402
from store import Store  # noqa: E402


def main():
    gateway.store = Store()
    job_id = "job-probe-noq"
    job = new_job(job_id, "2040059832773436", "12345678", 100, "jt-lite-2.0")
    job["stages"]["uploading"] = "done"
    job["stages"]["gateway"] = "done"
    job["stage"] = "model"
    job["stages"]["model"] = "processing"
    gateway.store.data["jobs"][job_id] = job

    orig = judge.judge_image
    judge.judge_image = lambda image, model_id: {"results": []}
    try:
        gateway._run_judge(job_id, b"\xff\xd8\xff\xe0" + b"\x00" * 100)
    finally:
        judge.judge_image = orig

    job = gateway.store.data["jobs"][job_id]
    print(f"job status={job['status']} error={job['error']} "
          f"failure_reason={job['failure_reason']}")
    recs = [r for r in gateway.store.data["records"]
            if r.get("kind") == "solve_failed"]
    print(f"solve_failed 记录：{recs[-1]['detail'] if recs else '无'}")
    ok = (job["status"] == "failed"
          and (job["error"] or {}).get("code") == "no_question"
          and job["failure_reason"] == "no_question"
          and recs and recs[-1]["detail"].get("error") == "no_question")
    old = "no_question_detected"
    leaked = (old in str(job["error"]) or old in str(recs[-1]["detail"])
              if recs else True)
    if leaked:
        print(f"FAIL: 旧名 {old} 仍在 job／记录里")
        ok = False
    print("PASS: error.code 与记录 error 均为 no_question，旧名已清"
          if ok else "FAIL: no_question 改名探针未通过")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
