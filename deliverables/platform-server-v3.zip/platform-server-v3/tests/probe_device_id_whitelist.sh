#!/bin/bash
# 首位 5-9 设备 ID 白名单探针（Nyx 189③，RECHECK #12，v3 增补）。
# 用法：bash tests/probe_device_id_whitelist.py
#   实例：端口 18002，数据目录 /tmp/v3test-whitelist-data（每次重建）。
#   断言：首位 5-9 的 16 位纯数字 bind/bind-scan 均 400 invalid_device_id；
#   首位 0/1/2/3/4 仍能绑 201；带空格的号去空格后能绑 201（Nyx 189②）。
# 注意：脚本里出现的手机号／密码均为测试假数据，不是真实凭证。
set -u
cd "$(dirname "$0")/.."

PORT=18002
DATA=/tmp/v3test-whitelist-data
BASE=http://127.0.0.1:$PORT
RESP=/tmp/v3test-whitelist-resp.json
PASS=0; FAIL=0; FAILED_NAMES=""

note() { echo; echo "== $* =="; }
req() { local method=$1 path=$2; shift 2; local out
  out=$(curl -s -w "\n%{http_code}" -X "$method" "$BASE$path" "$@")
  CODE="${out##*$'\n'}"; BODY="${out%$'\n'*}"
  printf '%s' "$BODY" > "$RESP"
  echo "[$CODE] $method $path -> $BODY"; }
jget() { python3 -c "import json;d=json.load(open('$RESP'));print($1 if $1 is not None else '')" 2>/dev/null; }
expect_code() { if [ "$CODE" = "$1" ]; then PASS=$((PASS+1)); echo "PASS: $2 (HTTP $1)";
  else FAIL=$((FAIL+1)); FAILED_NAMES="$FAILED_NAMES|$2"; echo "FAIL: $2 (want HTTP $1, got $CODE: $BODY)"; fi; }
expect_eq() { if [ "$1" = "$2" ]; then PASS=$((PASS+1)); echo "PASS: $3 ($1)";
  else FAIL=$((FAIL+1)); FAILED_NAMES="$FAILED_NAMES|$3"; echo "FAIL: $3 (want [$2], got [$1])"; fi; }

rm -rf "$DATA"
JIANTI_PORT=$PORT JIANTI_DATA_DIR=$DATA JIANTI_JUDGE_DELAY_SECONDS=5 \
  JIANTI_RATE_LIMIT_GENERAL_PER_MIN=10000 python3 app.py > /tmp/v3test-whitelist-server.log 2>&1 &
SRVPID=$!
sleep 1
kill -0 $SRVPID 2>/dev/null || { echo "服务器没起来"; cat /tmp/v3test-whitelist-server.log; exit 1; }
trap 'kill $SRVPID 2>/dev/null; rm -rf "$DATA"' EXIT

note "0. 注册并校验管理密码"
req POST /users/register -H 'Content-Type: application/json' \
  -d '{"phone":"13800138001","login_password":"12345678","admin_password":"123456","sms_code":"123456"}'
expect_code 201 "注册 201"
TOKEN=$(jget "d.get('token')")
req POST /users/admin-password/verify -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' -d '{"admin_password":"123456"}'
expect_code 200 "管理密码校验通过"

bind() { req POST /terminals/bind -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' -d "{\"device_id\":\"$1\"}"; }
bind_scan() { req POST /terminals/bind-scan -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' -d "{\"scan_payload\":\"$1\"}"; }

note "1. 首位 5-9 手动绑一律 400 invalid_device_id"
for first in 5 6 7 8 9; do
  bind "${first}999059832773436"
  expect_code 400 "首位 $first 手动绑 400"
  expect_eq "$(jget "d.get('error',{}).get('code')")" "invalid_device_id" "首位 $first 错误码 invalid_device_id"
done

note "2. 首位 9 扫码绑同样 400 invalid_device_id"
bind_scan "JianTi-9999059832773436"
expect_code 400 "首位 9 扫码绑 400"
expect_eq "$(jget "d.get('error',{}).get('code')")" "invalid_device_id" "扫码首位 9 错误码 invalid_device_id"

note "3. 首位 0/1/2/3/4 仍能绑 201"
bind "0582901647390528"
expect_code 201 "首位 0（其他/未知）绑 201"
expect_eq "$(jget "d.get('device_type')")" "其他/未知" "首位 0 类型 其他/未知"
bind "1040059832773436"
expect_code 201 "首位 1（嵌入式）绑 201"
expect_eq "$(jget "d.get('device_type')")" "嵌入式" "首位 1 类型 嵌入式"
bind "2864190752386419"
expect_code 201 "首位 2（安卓）绑 201"
bind "3762190752386419"
expect_code 201 "首位 3（苹果）绑 201"
expect_eq "$(jget "d.get('device_type')")" "苹果" "首位 3 类型 苹果"
bind "4762190752386419"
expect_code 201 "首位 4（鸿蒙）绑 201"
expect_eq "$(jget "d.get('device_type')")" "鸿蒙" "首位 4 类型 鸿蒙"

note "4. 带空格的号去空格后能绑 201（Nyx 189②）"
bind "3 333 3333 3333 3333"
expect_code 201 "带空格的号去空格后绑 201"
expect_eq "$(jget "d.get('device_id')")" "3333333333333333" "返回的 device_id 已去空格"

note "4b. 带空格的扫码载荷去空格后能绑 201（Nyx 189②）"
bind_scan "JianTi-4762 1907 5238 6419"
expect_code 201 "带空格的扫码载荷绑 201"
expect_eq "$(jget "d.get('device_id')")" "4762190752386419" "扫码返回的 device_id 已去空格"

note "5. 首位 9 的号没入库：查终端列表里没有"
req GET /terminals -H "Authorization: Bearer $TOKEN"
expect_absent() { case "$BODY" in *"$2"*) FAIL=$((FAIL+1)); FAILED_NAMES="$FAILED_NAMES|$1"; echo "FAIL: $1 (body 不应含 [$2])";; *) PASS=$((PASS+1)); echo "PASS: $1";; esac; }
expect_absent "列表里没有首位 9 的号" "9999059832773436"
expect_absent "列表里没有首位 5 的号" "5999059832773436"

echo
echo "探针结果：PASS $PASS，FAIL $FAIL"
[ -n "$FAILED_NAMES" ] && echo "失败项：$FAILED_NAMES"
[ "$FAIL" = 0 ]
