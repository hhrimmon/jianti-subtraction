# 自测记录（简题嵌入式终端固件 v1，2026-11-18）

依据：PRD v5.6（MD5 3a3872ab）、原型板子 v113、手机 v155/v157、
开发手册 v2（§1、§2、§5）、平台接口 v9（MD5 91393356，dev commit b8c487dc）。

## 已跑过的（真实结果，不伪造）

### 1. 主机自测：36/0 通过
命令：`python3 tests/host_sim.py`（自动起桩服务器 127.0.0.1:18000，跑完即停）
结果：**36 passed, 0 failed**（2026-11-18 15:07，见下方清单）

- 卡规则：默认 5 张倍率 0 总可用 5；每日 5 倍率 3 总可用 20；每日 9 倍率 3 总可用 36；
  倍率上限 3、每日上限 9；预支上限＝每日×倍率；余额 floor 0。
- 设备 ID：16 位分组 4-4-4-4；首位 1＝嵌入式；二维码载荷带 `JianTi-` 前缀。
- 导航铁律：1 滑→2、2 滑→1（转圈）、1 滑→2 再进取景器；只有 1、2 屏能滑动；
  取景器只能从 home 进；A 页上一题/下一题首尾循环。
- 对桩服务器 A1–A13：A10 环境公开口温度 `---°C`；A8 服务器配置默认官方；
  A1 非 JPEG 拒收 41501、空图拒收、设备号不对拒收 40001、正常 JPEG 建 job；
  A2 五阶段依次点亮、未解锁时 answer 为 null、思路第一句是判对错；
  A3 查卡余额 5；A4 扣卡 5→4 且拿到 answer；同一题再点不扣卡（同一幂等键与已解锁双重保障）；
  A5 倍率 0 时预支到上限报 40301；A6 发申请单 pending；A7 撤回、已撤回再撤回报 409；
  A13 跳过不扣卡；A12 取消未决任务；A2 不存在的 job 报 404。

### 2. C 代码静态核查
- `cards.c`（纯规则，无 ESP 依赖）：`gcc -std=c11 -Wall -Wextra -c cards.c` 编译通过，无警告。
- 全部 23 个 `main/*.[ch]` 文件花括号/圆括号/方括号配对平衡（脚本核对）。
- 桩服务器与自测脚本均为 Python 标准库，无第三方依赖。

## 未跑过的（诚实说明，不伪造构建成功）

### 3. ESP-IDF 硬件构建：未跑
本容器无 ESP-IDF 工具链：`idf.py`、`pio` 均不存在，`~/esp/esp-idf`、`/opt/esp*` 均不存在。
因此 `idf.py build`、`idf.py flash` 均未执行，**没有声称构建通过**。
需要装的东西（按官方文档）：
- ESP-IDF v5.5.6，禁用 v6（`https://docs.espressif.com/projects/esp-idf/en/v5.5/esp32p4/get-started/`），
  微雪 BSP 1.0.1 在 5.5 验证，v6 不兼容；Windows 本地用 F:\esp\.espressif\v5.5.6\esp-idf，
  执行 `install.sh` + `export.sh`，确认 `idf.py --version` 能跑；
- 之后按 README 执行 `idf.py set-target esp32p4 && idf.py build`。
- 依赖由 `main/idf_component.yml` 声明，首次构建时由 IDF Component Manager 拉取
 （`esp_lvgl_port`、`waveshare/esp32_p4_wifi6_touch_lcd_4_3`、`esp_qrcode`）。

### 4. 真机联调：待后
- 真网关 v9：联调时服务器端 v9 到了 Nyx 再通知；当前自测用的是本地桩服务器，
  只验逻辑与接口形状，不代表真网关已通。
- 真 OV5647 拍照、真 Wi-Fi/Soft AP、LVGL 真屏显示与触摸、双 OTA 分区烧录验证，均待真机。
- 摄像头引脚号以 Waveshare BSP v1.0.1 例程为准，板级联调时以 BSP 头文件核对。

## 逐屏对照 v113（代码对照，非真机截图）

| 屏 | 代码位置 | 对照点 |
|---|---|---|
| 1 锁屏 | `ui_screens.c` S1、`app.c` jt_app_init | 时间只到分、温度 `---°C`、MEMO 服务端下发、齿轮进 7 |
| 2 home | `ui_screens.c` S2 | 服务器已连接、解题卡今日剩余、拍到几道是几道、简单拍题、蓝色圆钮 |
| 3 取景器 | `ui_screens.c` S3、`camera_capture.c` | 真机画面＋底部黑条＋白色快门＋返回/勾；只从 2 进 |
| 4 处理 | `ui_screens.c` S4、`gateway.c` A2 | 五阶段点亮、轮询 1 秒一次最多 60 秒、超时 50401、无手动退出 |
| 5 思路 A | `ui_screens.c` S5、`app.c` jt_app_tap_card | 共 N 题第 M 题·思路、解题卡 N 张、思路第一句判对错、上一题/下一题循环 |
| 6 结果 B | `ui_screens.c` S6 | 共 N 题第 M 题·结果、等号链、底部无按钮、拐弯箭头只回本题 A |
| 7 设置 | `ui_screens.c` S7、`wifi_net.c`、`softap_prov.c`、`qr_display.c` | SSID 前 8 位、信号强/中/弱、官方/自有、连通测试三步、设备 ID＋二维码 |
| 8 领取 | `ui_screens.c` S8、`app.c` | 今日剩余·已预支、预支 1 张、申请发完停领取页、撤回即撤回 |

真机截图待联调时补，不拿原型截图冒充真机结果。
