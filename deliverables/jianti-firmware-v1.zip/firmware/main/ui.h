#pragma once
#include <stdbool.h>
/* 界面语言（实拍为准）：浅灰蓝底扁平，无渐变无阴影；顶栏左“简题”黑粗＋
 * “极简作业AI助手”灰小字，右“服务器”按钮＋LAN；主界面巨大蓝色圆形“拍题”
 * 按钮居中，下方灰色小字“对准题目，按一下”；解题/拍照红色扁平按钮，
 * 返回/上一题灰色，下一题蓝色，均为小圆角扁平矩形；字体普通黑体，
 * 拍题大字、其余小字；取景器是真机拍照画面＋底部黑条＋红色拍照按钮。
 * 字体规范：最小 26 号打底，最大约最小的两倍、不到两倍；时间是大字，约最大。
 * LVGL 9.5.0；屏 480×800（ST7701，竖屏原生 MIPI-DSI）。 */
#define JT_COLOR_BG       0xDDE6EE /* 浅灰蓝底 */
#define JT_COLOR_BLUE     0x2B7DE9 /* 拍题圆钮 / 下一题 */
#define JT_COLOR_RED      0xE53935 /* 解题/拍照 */
#define JT_COLOR_GREY     0x9AA0A6 /* 返回/上一题 */
#define JT_COLOR_TEXT     0x111111
#define JT_COLOR_MUTED    0x666666
void jt_ui_init(void);
void jt_ui_show_screen(int screen_1_8);
void jt_ui_set_stage(int stage_index_0_4);
void jt_ui_show_stage_failed(int stage_index, const char *reason);
void jt_ui_show_toast(const char *text); /* 一句话提示，不写多余解释句 */
void jt_ui_show_qr_page(const char *payload); /* 整屏只有码＋关闭 */
