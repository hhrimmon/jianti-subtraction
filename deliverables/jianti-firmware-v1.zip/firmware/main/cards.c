#include "cards.h"
int jt_cards_total_available(int daily_total, int multiplier) {
    if (daily_total < 0) daily_total = 0;
    if (daily_total > JT_CARD_DAILY_MAX) daily_total = JT_CARD_DAILY_MAX;
    if (multiplier < 0) multiplier = 0;
    if (multiplier > JT_CARD_MULTIPLIER_MAX) multiplier = JT_CARD_MULTIPLIER_MAX;
    return daily_total * (1 + multiplier);
}
int jt_cards_advance_limit(int daily_total, int multiplier) {
    if (daily_total < 0) daily_total = 0;
    if (daily_total > JT_CARD_DAILY_MAX) daily_total = JT_CARD_DAILY_MAX;
    if (multiplier < 0) multiplier = 0;
    if (multiplier > JT_CARD_MULTIPLIER_MAX) multiplier = JT_CARD_MULTIPLIER_MAX;
    return daily_total * multiplier;
}
int jt_cards_floor0(int v) { return v < 0 ? 0 : v; }
bool jt_cards_can_advance(int advanced, int daily_total, int multiplier) {
    return advanced < jt_cards_advance_limit(daily_total, multiplier);
}
