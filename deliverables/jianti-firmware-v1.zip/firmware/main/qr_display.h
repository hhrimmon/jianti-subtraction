#pragma once
/* 设备二维码（第 7 屏“显示设备二维码”按钮 → 整屏只有码＋关闭）。
 * 载荷：JianTi-<16 位设备 ID>。渲染用 esp_qrcode 组件，整屏只留码＋关闭，
 * 不写多余文字。 */
void jt_qr_show_device_id(void); /* 切到二维码全屏页 */
void jt_qr_hide(void);           /* 点“关闭”回设置页 */
