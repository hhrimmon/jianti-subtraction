idf_component_register(
  SRCS "main.c" "app.c" "device_id.c" "config_store.c" "gateway.c"
       "cards.c" "camera_capture.c" "wifi_net.c" "ui.c" "ui_screens.c"
       "qr_display.c" "softap_prov.c"
  INCLUDE_DIRS "."
  REQUIRES esp_wifi esp_event esp_netif esp_http_client esp-tls nvs_flash
           esp_lvgl_port driver esp_timer json esp_qrcode
)
