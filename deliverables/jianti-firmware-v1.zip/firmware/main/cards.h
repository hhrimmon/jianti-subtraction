#pragma once
#include <stdbool.h>
/* 解题卡规则（PRD v5.6 第 4 章 + 手册 v2 §2.3）。服务端是唯一事实来源：
 * 余额、规则一律以服务端 A3 返回为准；终端不自己维护余额变量。
 * 本文件只做本地纯规则校验（上限/下限/同一题只扣一次的本地去重键），
 * 真正扣卡/预支/审批以服务端实时结算为准，多端并发以服务端为准。 */
#define JT_CARD_DAILY_DEFAULT 5
#define JT_CARD_DAILY_MAX 9
#define JT_CARD_MULTIPLIER_DEFAULT 0
#define JT_CARD_MULTIPLIER_MAX 3
int jt_cards_total_available(int daily_total, int multiplier); /* daily*(1+mult) */
int jt_cards_advance_limit(int daily_total, int multiplier);  /* daily*mult */
int jt_cards_floor0(int v); /* 余额下限为 0，屏上不许出现负数 */
bool jt_cards_can_advance(int advanced, int daily_total, int multiplier);
