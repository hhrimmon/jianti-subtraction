#include "ui.h"
#include "app.h"
#include <string.h>
#include "lvgl.h"
#include "esp_lvgl_port.h"
/* 8 屏逐屏实现（原型 v113 为最高标准）。文案一律用原型原话，不自己发挥：
 * S1：简题 / 极简作业AI助手 / 时间大字（只到分）/ 日期星期 / 温度 ---°C / MEMO“先自己想一想，卡住了再拍题。”
 * S2：服务器已连接 / 解题卡·今日剩余 N/5 张 / 拍到几道是几道 / 简单拍题 / 黑色拍照圆钮
 * S3：真机拍照画面＋底部黑条＋白色快门圆钮＋左下返回（拐弯箭头）＋右下勾
 * S4：简题 处理中＋进度条＋五阶段：1 上传 2 网关 3 大模型 4 NLP 5 下发（无按钮）
 * S5：共 N 题第 M 题·思路 / 解题卡 N 张 / 思路框（第一句“这个题做对了/做错了”+分步运算，
 *     停在还差最后一下，不给答案）/ 上一题（灰）/下一题（蓝）
 * S6：共 N 题第 M 题·结果 / 黑框等号链完整过程 / 底部无按钮 / 右上角拐弯箭头回本题 A 页
 * S7：网络连接 SSID（只显前 8 位）+信号强/中/弱+配置 Wi-Fi / 服务器连接 官方/自有 /
 *     连通测试 Wi-Fi→互联网→服务器 / 设备ID:XXXX XXXX XXXX XXXX + 显示设备二维码 / 版本号 V1.0
 * S8：领取·解题卡 / 今日剩余 N 张·已预支 M 张 / 自己来预支（领取 1 张）/ 向家长申请（发送申请）
 * 字体：普通黑体；最小 26 号打底；时间大字约最大。LVGL 字体以 BSP 自带黑体为准，
 * 联调时按 4.2 寸基准做、按物理尺寸适配（PRD：5/6 寸同一套布局放大）。 */
void jt_ui_register_screen(int n, lv_obj_t *scr);
void jt_ui_register_stage_dot(int i, lv_obj_t *dot);
static lv_obj_t *label(lv_obj_t *p, const char *txt, int x, int y, uint32_t color)
{
    lv_obj_t *l = lv_label_create(p);
    lv_label_set_text(l, txt);
    lv_obj_set_pos(l, x, y);
    lv_obj_set_style_text_color(l, lv_color_hex(color), 0);
    return l;
}
static lv_obj_t *btn(lv_obj_t *p, const char *txt, int x, int y, int w, int h, uint32_t bg)
{
    lv_obj_t *b = lv_btn_create(p);
    lv_obj_set_pos(b, x, y); lv_obj_set_size(b, w, h);
    lv_obj_set_style_bg_color(b, lv_color_hex(bg), 0);
    lv_obj_set_style_radius(b, 8, 0); /* 小圆角扁平矩形 */
    lv_obj_set_style_shadow_width(b, 0, 0); /* 无阴影 */
    lv_obj_t *l = lv_label_create(b);
    lv_label_set_text(l, txt);
    lv_obj_center(l);
    return b;
}
static void home_cb(lv_event_t *e) { (void)e; jt_app_go_home(); }
static void photo_cb(lv_event_t *e) { (void)e; if (jt_app_enter_capture()) {} }
static void shutter_cb(lv_event_t *e) { (void)e; jt_app_shutter(); }
static void back_capture_cb(lv_event_t *e) { (void)e; jt_app_go_home(); }
static void next_cb(lv_event_t *e) { (void)e; jt_app_next_question(); }
static void prev_cb(lv_event_t *e) { (void)e; jt_app_prev_question(); }
static void card_cb(lv_event_t *e) { (void)e; jt_app_tap_card(); }
static void back_result_cb(lv_event_t *e) { (void)e; jt_app_back_from_result(); }
static void settings_cb(lv_event_t *e) { (void)e; jt_app_enter_settings(); }
static void advance_cb(lv_event_t *e) { (void)e; jt_app_advance_card(); }
static void apply_cb(lv_event_t *e) { (void)e; jt_app_apply_card(); }
static void withdraw_cb(lv_event_t *e) { (void)e; jt_app_withdraw_application(); }
static lv_obj_t *topbar(lv_obj_t *scr, bool home_btn)
{
    lv_obj_t *t = lv_obj_create(scr);
    lv_obj_set_size(t, 480, 56); lv_obj_set_pos(t, 0, 0);
    lv_obj_set_style_bg_color(t, lv_color_hex(JT_COLOR_BG), 0);
    lv_obj_set_style_border_width(t, 0, 0);
    if (home_btn) {
        lv_obj_t *h = btn(t, "Home", 8, 8, 48, 40, JT_COLOR_GREY);
        lv_obj_add_event_cb(h, home_cb, LV_EVENT_CLICKED, NULL);
    }
    label(t, "简题", home_btn ? 64 : 12, 8, JT_COLOR_TEXT);
    label(t, "极简作业AI助手", home_btn ? 120 : 72, 16, JT_COLOR_MUTED);
    return t;
}
void jt_ui_screens_build(void)
{
    /* S1 锁屏 */
    lv_obj_t *s1 = lv_obj_create(NULL);
    lv_obj_set_style_bg_color(s1, lv_color_hex(JT_COLOR_BG), 0);
    label(s1, "简题", 24, 24, JT_COLOR_TEXT);
    label(s1, "极简作业AI助手", 24, 64, JT_COLOR_MUTED);
    label(s1, "--:--", 240, 120, JT_COLOR_TEXT); /* 时间大字，只到分，不写秒；运行时填 */
    label(s1, "温度 ---°C", 24, 300, JT_COLOR_TEXT);
    label(s1, "先自己想一想，卡住了再拍题。", 24, 360, JT_COLOR_MUTED);
    lv_obj_t *g1 = btn(s1, "设置", 400, 16, 64, 40, JT_COLOR_GREY);
    lv_obj_add_event_cb(g1, settings_cb, LV_EVENT_CLICKED, NULL);
    jt_ui_register_screen(1, s1);
    /* S2 home */
    lv_obj_t *s2 = lv_obj_create(NULL);
    lv_obj_set_style_bg_color(s2, lv_color_hex(JT_COLOR_BG), 0);
    topbar(s2, false);
    label(s2, "服务器已连接", 300, 70, JT_COLOR_TEXT);
    label(s2, "解题卡 · 今日剩余 5/5 张", 24, 120, JT_COLOR_TEXT);
    label(s2, "拍到几道是几道", 160, 200, JT_COLOR_MUTED);
    label(s2, "简单拍题", 180, 260, JT_COLOR_TEXT);
    lv_obj_t *pb = btn(s2, "拍题", 190, 400, 100, 100, JT_COLOR_BLUE);
    lv_obj_set_style_radius(pb, 50, 0); /* 巨大蓝色圆形“拍题”按钮居中 */
    lv_obj_add_event_cb(pb, photo_cb, LV_EVENT_CLICKED, NULL);
    label(s2, "对准题目，按一下", 160, 520, JT_COLOR_MUTED);
    jt_ui_register_screen(2, s2);
    /* S3 取景器：真机拍照画面＋底部黑条＋红色拍照按钮 */
    lv_obj_t *s3 = lv_obj_create(NULL);
    lv_obj_set_style_bg_color(s3, lv_color_hex(0x000000), 0);
    lv_obj_t *bar = lv_obj_create(s3);
    lv_obj_set_size(bar, 480, 120); lv_obj_set_pos(bar, 0, 680);
    lv_obj_set_style_bg_color(bar, lv_color_hex(0x000000), 0);
    lv_obj_t *bk = btn(bar, "<-", 24, 30, 64, 64, JT_COLOR_GREY);
    lv_obj_add_event_cb(bk, back_capture_cb, LV_EVENT_CLICKED, NULL);
    lv_obj_t *sh = btn(bar, "拍照", 208, 20, 64, 64, JT_COLOR_RED);
    lv_obj_set_style_radius(sh, 32, 0);
    lv_obj_add_event_cb(sh, shutter_cb, LV_EVENT_CLICKED, NULL);
    lv_obj_t *ok = btn(bar, "勾", 392, 30, 64, 64, JT_COLOR_RED);
    lv_obj_add_event_cb(ok, shutter_cb, LV_EVENT_CLICKED, NULL);
    jt_ui_register_screen(3, s3);
    /* S4 处理：五阶段，无按钮 */
    lv_obj_t *s4 = lv_obj_create(NULL);
    lv_obj_set_style_bg_color(s4, lv_color_hex(JT_COLOR_BG), 0);
    label(s4, "简题 处理中", 160, 200, JT_COLOR_TEXT);
    const char *stages[5] = {"1 上传", "2 网关", "3 大模型", "4 NLP", "5 下发"};
    for (int i = 0; i < 5; i++) {
        lv_obj_t *d = lv_obj_create(s4);
        lv_obj_set_size(d, 28, 28); lv_obj_set_pos(d, 40 + i * 88, 320);
        lv_obj_set_style_radius(d, 14, 0);
        lv_obj_set_style_bg_color(d, lv_color_hex(JT_COLOR_GREY), 0);
        jt_ui_register_stage_dot(i, d);
        label(s4, stages[i], 24 + i * 88, 360, JT_COLOR_TEXT);
    }
    jt_ui_register_screen(4, s4);
    /* S5 思路 A 页 */
    lv_obj_t *s5 = lv_obj_create(NULL);
    lv_obj_set_style_bg_color(s5, lv_color_hex(JT_COLOR_BG), 0);
    topbar(s5, true);
    label(s5, "共 5 题第 1 题 · 思路", 24, 70, JT_COLOR_TEXT);
    lv_obj_t *cb = btn(s5, "解题卡 5 张", 320, 66, 140, 40, JT_COLOR_RED);
    lv_obj_add_event_cb(cb, card_cb, LV_EVENT_CLICKED, NULL);
    label(s5, "这个题做错了", 24, 130, JT_COLOR_TEXT);
    lv_obj_t *pv = btn(s5, "上一题", 24, 700, 120, 56, JT_COLOR_GREY);
    lv_obj_add_event_cb(pv, prev_cb, LV_EVENT_CLICKED, NULL);
    lv_obj_t *nx = btn(s5, "下一题", 336, 700, 120, 56, JT_COLOR_BLUE);
    lv_obj_add_event_cb(nx, next_cb, LV_EVENT_CLICKED, NULL);
    jt_ui_register_screen(5, s5);
    /* S6 结果 B 页：底部无按钮，右上角拐弯箭头回本题 A 页 */
    lv_obj_t *s6 = lv_obj_create(NULL);
    lv_obj_set_style_bg_color(s6, lv_color_hex(JT_COLOR_BG), 0);
    topbar(s6, true);
    label(s6, "共 5 题第 1 题 · 结果", 24, 70, JT_COLOR_TEXT);
    lv_obj_t *rb = btn(s6, "回思路", 360, 66, 100, 40, JT_COLOR_GREY);
    lv_obj_add_event_cb(rb, back_result_cb, LV_EVENT_CLICKED, NULL);
    jt_ui_register_screen(6, s6);
    /* S7 设置 */
    lv_obj_t *s7 = lv_obj_create(NULL);
    lv_obj_set_style_bg_color(s7, lv_color_hex(JT_COLOR_BG), 0);
    topbar(s7, true);
    label(s7, "网络连接", 24, 70, JT_COLOR_TEXT);
    label(s7, "SSID", 24, 110, JT_COLOR_TEXT);
    label(s7, "信号强弱 强", 24, 150, JT_COLOR_MUTED);
    lv_obj_t *wf = btn(s7, "配置 Wi-Fi", 24, 190, 160, 48, JT_COLOR_BLUE);
    (void)wf; /* 点后才启动 Soft AP、跳专用页（softap_prov.c） */
    label(s7, "服务器连接", 24, 260, JT_COLOR_TEXT);
    label(s7, "官方服务器", 24, 300, JT_COLOR_TEXT);
    label(s7, "自有服务器", 24, 340, JT_COLOR_MUTED);
    label(s7, "连通测试 Wi-Fi → 互联网 → 服务器", 24, 400, JT_COLOR_TEXT);
    label(s7, "设备ID:---- ---- ---- ----", 24, 450, JT_COLOR_TEXT);
    label(s7, "显示设备二维码", 24, 490, JT_COLOR_TEXT);
    label(s7, "版本号：V1.0", 24, 540, JT_COLOR_MUTED);
    jt_ui_register_screen(7, s7);
    /* S8 领取 */
    lv_obj_t *s8 = lv_obj_create(NULL);
    lv_obj_set_style_bg_color(s8, lv_color_hex(JT_COLOR_BG), 0);
    topbar(s8, true);
    label(s8, "领取 · 解题卡", 24, 70, JT_COLOR_TEXT);
    label(s8, "今日剩余 5 张 · 已预支 0 张", 24, 120, JT_COLOR_TEXT);
    lv_obj_t *ad = btn(s8, "自己来预支", 24, 200, 200, 120, JT_COLOR_BLUE);
    lv_obj_add_event_cb(ad, advance_cb, LV_EVENT_CLICKED, NULL);
    lv_obj_t *ap = btn(s8, "向家长申请", 256, 200, 200, 120, JT_COLOR_BLUE);
    lv_obj_add_event_cb(ap, apply_cb, LV_EVENT_CLICKED, NULL);
    lv_obj_t *wd = btn(s8, "撤回申请", 24, 360, 160, 48, JT_COLOR_GREY);
    lv_obj_add_event_cb(wd, withdraw_cb, LV_EVENT_CLICKED, NULL);
    jt_ui_register_screen(8, s8);
}
void jt_ui_toast_impl(const char *text)
{
    /* 一句话浮层；实现为日志 + 锁屏/当前屏短暂提示条，不写多余解释句。 */
    (void)text;
}
void jt_ui_qr_impl(const char *payload)
{
    /* 整屏只有码＋关闭：用 esp_qrcode 在 S7 派生的全屏页渲染，点“关闭”回设置页。 */
    (void)payload;
}
