#pragma once
#include <stdbool.h>
/* 终端配置（NVS 持久化）。服务端是唯一事实来源：卡余额、卡规则、服务器配置
 * 一律以服务端拉取为准，终端不自己维护余额变量、不缓存旧规则。
 * 本地只存连接必需的配置；取不到服务端配置时按上次保存的官方默认走，
 * 并在第 7 屏显示“配置未更新”，不编一个地址。 */
typedef enum { JT_SERVER_OFFICIAL = 0, JT_SERVER_CUSTOM = 1 } jt_server_mode_t;
typedef struct {
    char ssid[33];            /* SSID 名；屏上只显示前 8 位 */
    char ssid_password[65];   /* 仅存 NVS，不显示、不记日志 */
    jt_server_mode_t server_mode; /* 官方/自有互斥，默认官方，选中即保存 */
    char custom_ip[64];       /* 自有时填的 IP；官方时为空 */
    char terminal_token[128]; /* 终端凭证（U22：绑定时发放，开发时定；绝不写进日志/代码） */
    bool bound;               /* 是否已绑定家庭账号 */
    int  daily_total;         /* 每日张数缓存（服务端为准，默认 5，最大 9） */
    int  advance_multiplier;  /* 预支倍率缓存（服务端为准，默认 0，最大 3） */
} jt_config_t;
bool jt_config_load(jt_config_t *cfg);
bool jt_config_save(const jt_config_t *cfg);
bool jt_config_clear_credentials(void); /* 不用时清凭证，不留密码/token 在盘上 */
