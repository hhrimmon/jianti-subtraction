#include "app.h"
#include <string.h>
#include <stdio.h>
#include "esp_log.h"
#include "device_id.h"
#include "config_store.h"
#include "ui.h"
#include "wifi_net.h"
#include "camera_capture.h"
static const char *TAG = "app";
static int s_poll_elapsed_ms = 0;
jt_app_t g_app;
void jt_app_init(void)
{
    memset(&g_app, 0, sizeof(g_app));
    g_app.screen = JT_SCREEN_LOCK;
    g_app.total_questions = -1;
    g_app.current_index = 0;
    g_app.cards.daily_total = JT_CARD_DAILY_DEFAULT;
    g_app.cards.balance = JT_CARD_DAILY_DEFAULT;
    strncpy(g_app.temperature, "---°C", sizeof(g_app.temperature)-1);
    jt_device_id_get(g_app.device_id);
    jt_gateway_set_auth(g_app.device_id, NULL); /* 终端凭证绑定时发（U22，开发时定） */
    jt_config_t cfg; jt_config_load(&cfg);
    if (cfg.server_mode == JT_SERVER_CUSTOM && cfg.custom_ip[0]) {
        char base[128]; snprintf(base, sizeof(base), "http://%s:8000", cfg.custom_ip);
        jt_gateway_set_base(base);
    }
    jt_ui_init();
    jt_ui_show_screen(1);
    /* 锁屏温度/MEMO：启动/联网时拉取（A10 公开口），失败显示 ---°C 与上次 MEMO。 */
    jt_gateway_fetch_environment(g_app.temperature, sizeof(g_app.temperature),
                                 NULL, 0, g_app.memo, sizeof(g_app.memo));
    jt_ui_show_screen(1);
}
bool jt_app_go_home(void)
{
    if (g_app.screen == JT_SCREEN_PROCESSING) jt_app_leave_processing();
    g_app.screen = JT_SCREEN_HOME;
    /* 进 home/领取页时查卡：余额以服务端为准，终端不自己维护余额变量。 */
    jt_card_status_t c;
    if (jt_gateway_cards_check(NULL, NULL, &c) == JT_OK) g_app.cards = c;
    jt_ui_show_screen(2);
    return true;
}
bool jt_app_swipe(int direction)
{
    (void)direction;
    if (g_app.screen == JT_SCREEN_LOCK) { g_app.screen = JT_SCREEN_HOME; jt_ui_show_screen(2); return true; }
    if (g_app.screen == JT_SCREEN_HOME) { g_app.screen = JT_SCREEN_LOCK; jt_ui_show_screen(1); return true; }
    return false; /* 其他页面一律不能滑动 */
}
bool jt_app_enter_capture(void)
{
    if (g_app.screen != JT_SCREEN_HOME) return false; /* 只从第 2 屏点拍照圆钮进 */
    g_app.screen = JT_SCREEN_CAPTURE;
    jt_ui_show_screen(3);
    return true;
}
bool jt_app_shutter(void)
{
    if (g_app.screen != JT_SCREEN_CAPTURE) return false;
    uint8_t *jpeg = NULL; size_t len = 0;
    /* 板子不做“拍题先判绑定码”（手机端开发需求，板子只在设置里亮自己的二维码）。 */
    if (!jt_camera_capture_jpeg(&jpeg, &len)) {
        jt_ui_show_toast("没拍到题，请重拍");
        return false;
    }
    char idem[37]; jt_uuid_v4(idem);
    jt_job_t job; memset(&job, 0, sizeof(job));
    jt_err_t e = jt_gateway_solve(jpeg, len, idem, &job);
    jt_camera_release(jpeg);
    if (e != JT_OK) {
        /* 网关拒收停在第 3 屏或第 2 屏，不进第 4 屏；40101/40001 跳设置页提示绑定。 */
        if (e == JT_ERR_TERMINAL_NOT_BOUND || e == JT_ERR_MISSING_TERMINAL_ID) {
            g_app.screen = JT_SCREEN_SETTINGS; jt_ui_show_screen(7);
            jt_ui_show_toast("设备未绑定");
        } else if (e == JT_ERR_PAYLOAD_TOO_LARGE) {
            jt_ui_show_toast("照片太大，请靠近一点拍");
        } else {
            jt_ui_show_toast("判题服务暂时接不通，稍后再试");
        }
        ESP_LOGE(TAG, "solve failed: %d", (int)e);
        return false;
    }
    g_app.job = job;
    s_poll_elapsed_ms = 0;
    g_app.screen = JT_SCREEN_PROCESSING;
    jt_ui_show_screen(4);
    jt_ui_set_stage(0);
    return true;
}
void jt_app_poll_tick(void)
{
    /* 第 4 屏轮询：1 秒一次、最多 60 秒，超时按 50401 处理；五步全亮才进思路页。 */
    if (g_app.screen != JT_SCREEN_PROCESSING) return;
    s_poll_elapsed_ms += JT_POLL_INTERVAL_MS;
    if (s_poll_elapsed_ms > JT_POLL_MAX_MS) {
        jt_ui_show_stage_failed(g_app.job.stage_index, "网络异常");
        return;
    }
    jt_job_t job = g_app.job;
    int n = 0;
    jt_err_t e = jt_gateway_poll(job.job_id, &job, g_app.questions, 16, &n);
    if (e != JT_OK) {
        if (e == JT_ERR_POLL_TIMEOUT) jt_ui_show_stage_failed(job.stage_index, "网络异常");
        return;
    }
    g_app.job = job;
    g_app.n_questions = n;
    g_app.total_questions = n;
    if (job.failed) {
        /* 识别失败：停在失败步，打叉变红；给重拍（回第 3 屏）与返回（回第 2 屏）两个出口；
         * 不进思路页，不扣卡，不留“判题成功”记录。 */
        jt_ui_show_stage_failed(job.stage_index, "没看清题目，请重拍");
        return;
    }
    jt_ui_set_stage(job.stage_index);
    if (job.stage_index >= 4 && n > 0) {
        s_poll_elapsed_ms = 0;
        g_app.current_index = 0;
        g_app.screen = JT_SCREEN_THINKING;
        jt_ui_show_screen(5);
    }
}
bool jt_app_next_question(void)
{
    if (g_app.screen != JT_SCREEN_THINKING || g_app.n_questions <= 0) return false;
    g_app.current_index = (g_app.current_index + 1) % g_app.n_questions; /* 首尾循环 */
    jt_ui_show_screen(5);
    return true;
}
bool jt_app_prev_question(void)
{
    if (g_app.screen != JT_SCREEN_THINKING || g_app.n_questions <= 0) return false;
    g_app.current_index = (g_app.current_index - 1 + g_app.n_questions) % g_app.n_questions;
    jt_ui_show_screen(5);
    return true;
}
bool jt_app_tap_card(void)
{
    if (g_app.screen != JT_SCREEN_THINKING || g_app.n_questions <= 0) return false;
    jt_question_t *q = &g_app.questions[g_app.current_index];
    jt_card_status_t c;
    if (jt_gateway_cards_check(q->question_id, g_app.batch_id, &c) != JT_OK) {
        jt_ui_show_toast("查不到余额，稍后再试");
        return false;
    }
    g_app.cards = c;
    if (c.unlocked) { /* 已解锁再点不扣卡，直接进结果页 */
        g_app.screen = JT_SCREEN_RESULT; jt_ui_show_screen(6); return true;
    }
    if (!c.can_deduct || c.balance <= 0) {
        g_app.screen = JT_SCREEN_CLAIM; jt_ui_show_screen(8);
        jt_ui_show_toast("解题卡已用光");
        return false;
    }
    char idem[37]; jt_uuid_v4(idem);
    char answer[2048] = {0};
    jt_card_status_t after;
    jt_err_t e = jt_gateway_cards_deduct(q->question_id, g_app.batch_id, g_app.job.job_id, idem, &after, answer, sizeof(answer));
    if (e == JT_ERR_ALREADY_UNLOCKED) { g_app.screen = JT_SCREEN_RESULT; jt_ui_show_screen(6); return true; }
    if (e == JT_ERR_NO_CARD) { g_app.screen = JT_SCREEN_CLAIM; jt_ui_show_screen(8); return false; }
    if (e != JT_OK) { jt_ui_show_toast("查不到余额，稍后再试"); return false; }
    g_app.cards = after;
    strncpy(q->answer, answer, sizeof(q->answer)-1);
    q->answer_present = true; q->unlocked = true;
    g_app.screen = JT_SCREEN_RESULT; jt_ui_show_screen(6);
    return true;
}
bool jt_app_back_from_result(void)
{
    if (g_app.screen != JT_SCREEN_RESULT) return false;
    g_app.screen = JT_SCREEN_THINKING; jt_ui_show_screen(5); return true; /* 只回本题 A 页 */
}
bool jt_app_advance_card(void)
{
    if (g_app.screen != JT_SCREEN_CLAIM) return false;
    char idem[37]; jt_uuid_v4(idem);
    jt_card_status_t after;
    jt_err_t e = jt_gateway_cards_advance(idem, &after);
    if (e == JT_ERR_ADVANCE_LIMIT) { jt_ui_show_toast("今天预支已到上限"); return false; }
    if (e != JT_OK) { jt_ui_show_toast("预支失败，稍后再试"); return false; }
    g_app.cards = after;
    jt_ui_show_toast("解题卡已领取，请合理使用。");
    return true;
}
bool jt_app_apply_card(void)
{
    if (g_app.screen != JT_SCREEN_CLAIM) return false;
    char idem[37]; jt_uuid_v4(idem);
    char app_id[64] = {0};
    jt_err_t e = jt_gateway_apply(NULL, idem, app_id, sizeof(app_id));
    if (e != JT_OK) {
        /* 申请发送失败：停留在领取页，不显示“申请已发送。”，给“重新发送”按钮。 */
        jt_ui_show_toast("申请没发出去，点‘发送申请’再试一次");
        return false;
    }
    strncpy(g_app.application_id, app_id, sizeof(g_app.application_id)-1);
    g_app.has_application_pending = true;
    jt_ui_show_toast("申请已发送。");
    return true;
}
bool jt_app_withdraw_application(void)
{
    if (!g_app.has_application_pending || !g_app.application_id[0]) return false;
    if (jt_gateway_withdraw(g_app.application_id) != JT_OK) return false;
    g_app.has_application_pending = false;
    g_app.application_id[0] = '\0';
    return true;
}
bool jt_app_enter_settings(void)
{
    if (g_app.screen == JT_SCREEN_PROCESSING) jt_app_leave_processing();
    g_app.screen = JT_SCREEN_SETTINGS; jt_ui_show_screen(7); return true;
}
bool jt_app_leave_processing(void)
{
    if (g_app.job.job_id[0]) jt_gateway_cancel_job(g_app.job.job_id); /* A12 */
    return true;
}
