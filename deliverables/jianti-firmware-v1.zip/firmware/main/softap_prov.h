#pragma once
#include <stdbool.h>
/* Soft AP 配网（手册 v2 §5）。板子无键盘：开机起 Soft AP，屏上提示连接手机热点，
 * 手机连上后选家里 Wi-Fi 输密码；联网成功后终端显示一个绑定二维码，手机扫码
 * 完成绑定，再进横屏主界面；全程只有一个二维码。
 * 第 7 屏点“配置 Wi-Fi”才启动 Soft AP、跳专用页；关页热点随之关。
 * 配网就是连 Wi-Fi：配网页里不放官方/自有服务器二选一、不放自有服务器填 IP。 */
bool jt_softap_start(void);  /* 热点名 JianTi-<16 位设备 ID> */
void jt_softap_stop(void);
bool jt_softap_is_running(void);
void jt_softap_hotspot_name(char out[32]); /* JianTi-<16 位数字> */
