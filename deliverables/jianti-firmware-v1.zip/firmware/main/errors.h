#pragma once
/* 错误码表：手册 v2 §2.5 + 接口文档 A1/A2 通用码。只列已定稿的码，不编新码。
 * 落屏与处理见 gateway.c / app.c；学生屏上只给一句话提示，不显示内部状态。 */
typedef enum {
    JT_OK = 0,
    JT_ERR_MODEL_NOT_CONNECTED = 100, /* model_not_connected：F1 停在“大模型”步 */
    JT_ERR_JUDGE_FAILED        = 101, /* judge_failed */
    JT_ERR_NO_QUESTION          = 102, /* no_question_detected：空白题不直达答案 */
    JT_ERR_POLL_TIMEOUT         = 50401, /* 50401：轮询 1 秒一次、最多 60 秒超时 */
    JT_ERR_PAYLOAD_TOO_LARGE    = 413, /* payload_too_large：超 8MB，重拍 */
    JT_ERR_UNSUPPORTED_MEDIA    = 415, /* unsupported_media_type：非 JPEG */
    JT_ERR_EMPTY_IMAGE          = 103, /* empty_image */
    JT_ERR_MISSING_TERMINAL_ID  = 104, /* missing_terminal_id：回设置页绑定 */
    JT_ERR_TERMINAL_NOT_BOUND   = 403, /* terminal_not_bound：提示去绑定 */
    JT_ERR_UNAUTHORIZED         = 401, /* unauthorized */
    JT_ERR_RATE_LIMITED         = 429, /* rate_limited：稍后再试 */
    JT_ERR_JOB_NOT_FOUND        = 404, /* job_not_found / question_not_found */
    JT_ERR_FORBIDDEN            = 105, /* forbidden：不是本家庭组的题目 */
    JT_ERR_SCAN_NO_DATA         = 422, /* scan_no_data */
    JT_ERR_SCAN_NO_DEVICE_ID    = 423, /* scan_no_device_id */
    JT_ERR_DEVICE_ID_DUPLICATE  = 409, /* device_id_duplicate */
    JT_ERR_ADVANCE_LIMIT        = 40901, /* advance_limit_reached（409） */
    JT_ERR_NO_CARD              = 40201, /* 40201：无卡，不扣、不进结果页，转领取页 */
    JT_ERR_ALREADY_UNLOCKED     = 40902, /* 40901：已解锁/重复扣，不再扣，直接进结果页 */
    JT_ERR_APPLICATION_NOT_FOUND = 40401,
    JT_ERR_APPLICATION_WITHDRAWN = 40903,
    JT_ERR_APPLICATION_DECIDED  = 40904,
    JT_ERR_APPLICATION_SEND_FAILED = 106, /* application_send_failed：留领取页、可重试 */
    JT_ERR_CARD_QUERY_TIMEOUT   = 107, /* card_query_timeout：停思路页，不进结果页 */
    JT_ERR_APPROVAL_SUBMIT_FAILED = 108,
    JT_ERR_SERVER_CONFIG_FETCH_FAILED = 109, /* 继续用上次配置，第 7 屏显示未更新 */
    JT_ERR_CONNECTIVITY_FAILED  = 110, /* connectivity_test_failed：停在那一步，打叉变红 */
    JT_ERR_RECORD_WRITE_FAILED  = 111,
    JT_ERR_INTERNAL             = 500,
    JT_ERR_NOT_FOUND            = 40402,
} jt_err_t;
