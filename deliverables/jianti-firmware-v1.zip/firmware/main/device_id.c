#include "device_id.h"
#include <string.h>
#include "esp_wifi.h"
#include "esp_log.h"
static const char *TAG = "device_id";
/* Wi-Fi 地址（C6 经 SDIO 提供）取 MAC，后 15 位十进制化：
 * 取 MAC 低 5 字节作 40 位整数，对 10^15 取模，不足 15 位左补 0；
 * 首位固定 '1'（嵌入式）。MAC 全 0 或读不到时返回 false，不编一个码顶上去。 */
bool jt_device_id_get(char out[JT_DEVICE_ID_LEN + 1])
{
    uint8_t mac[6] = {0};
    if (esp_wifi_get_mac(WIFI_IF_STA, mac) != ESP_OK) {
        ESP_LOGE(TAG, "read wifi mac failed");
        return false;
    }
    uint64_t v = 0;
    for (int i = 1; i < 6; i++) v = (v << 8) | mac[i];
    uint64_t tail = v % 1000000000000000ULL; /* 10^15 */
    if (tail == 0 && mac[1] == 0 && mac[2] == 0 && mac[3] == 0 && mac[4] == 0 && mac[5] == 0) {
        ESP_LOGE(TAG, "mac is zero, refuse to invent device id");
        return false;
    }
    out[0] = JT_DEVICE_ID_TYPE_EMBEDDED;
    for (int i = 15; i >= 1; i--) { out[i] = (char)('0' + (tail % 10)); tail /= 10; }
    out[16] = '\0';
    return true;
}
void jt_device_id_format_grouped(const char id[JT_DEVICE_ID_LEN + 1], char out[JT_DEVICE_ID_LEN + 4])
{
    /* 1040059832773436 -> 1040 0598 3277 3436 */
    int o = 0;
    for (int i = 0; i < 16; i++) {
        out[o++] = id[i];
        if (i == 3 || i == 7 || i == 11) out[o++] = ' ';
    }
    out[o] = '\0';
}
void jt_device_id_qr_payload(const char id[JT_DEVICE_ID_LEN + 1], char out[8 + JT_DEVICE_ID_LEN])
{
    memcpy(out, "JianTi-", 7);
    memcpy(out + 7, id, 16);
    out[23] = '\0';
}
