#include "qr_display.h"
#include "device_id.h"
#include "ui.h"
#include "esp_qrcode.h"
#include <string.h>
void jt_qr_show_device_id(void)
{
    char id[17] = {0};
    char payload[24] = {0};
    if (!jt_device_id_get(id)) { jt_ui_show_toast("设备号未生成，请检查绑定"); return; }
    jt_device_id_qr_payload(id, payload);
    /* esp_qrcode 在 LVGL 画布上渲染；整屏只留码＋关闭（见 ui_screens.c）。 */
    jt_ui_show_qr_page(payload);
}
void jt_qr_hide(void) { jt_ui_show_screen(7); }
