#include "gateway.h"
#include <string.h>
#include <stdio.h>
#include "esp_http_client.h"
#include "esp_log.h"
#include "esp_random.h"
#include "cJSON.h"
static const char *TAG = "gateway";
const char *JT_STAGE_NAMES[5] = {"uploading", "gateway", "model", "nlp", "delivering"};
static char s_base[128] = "http://solve.mhq-ai.xyz:8000";
static char s_terminal_id[17] = {0};
static char s_token[128] = {0};
void jt_gateway_set_base(const char *base_url) { strncpy(s_base, base_url, sizeof(s_base)-1); }
void jt_gateway_set_auth(const char *tid, const char *tok) {
    if (tid) strncpy(s_terminal_id, tid, 16);
    if (tok) strncpy(s_token, tok, sizeof(s_token)-1);
}
void jt_uuid_v4(char out[37]) {
    uint8_t b[16]; esp_fill_random(b, sizeof(b));
    b[6] = (b[6] & 0x0F) | 0x40; b[8] = (b[8] & 0x3F) | 0x80;
    snprintf(out, 37, "%02x%02x%02x%02x-%02x%02x-%02x%02x-%02x%02x-%02x%02x%02x%02x%02x%02x",
        b[0],b[1],b[2],b[3],b[4],b[5],b[6],b[7],b[8],b[9],b[10],b[11],b[12],b[13],b[14],b[15]);
}
/* ---- 内部：带鉴权头的 HTTP 调用。code 非 0 即按 errors.h 映射，不编假答案。 ---- */
typedef struct { char *buf; size_t len; size_t cap; } resp_t;
static esp_err_t on_data(esp_http_client_event_t *e) {
    if (e->event_id != HTTP_EVENT_ON_DATA) return ESP_OK;
    resp_t *r = (resp_t*)e->user_data;
    if (r->len + e->data_len + 1 > r->cap) return ESP_FAIL;
    memcpy(r->buf + r->len, e->data, e->data_len); r->len += e->data_len; r->buf[r->len] = '\0';
    return ESP_OK;
}
static jt_err_t code_to_err(int code) {
    switch (code) {
        case 0: return JT_OK;
        case 40001: return JT_ERR_TERMINAL_NOT_BOUND;
        case 40101: return JT_ERR_UNAUTHORIZED;
        case 40002: case 41501: return JT_ERR_UNSUPPORTED_MEDIA;
        case 41301: return JT_ERR_PAYLOAD_TOO_LARGE;
        case 40003: return JT_ERR_MISSING_TERMINAL_ID;
        case 40201: return JT_ERR_NO_CARD;
        case 40901: return JT_ERR_ALREADY_UNLOCKED;
        case 40301: return JT_ERR_ADVANCE_LIMIT;
        case 40902: return JT_ERR_ALREADY_UNLOCKED;
        case 50401: return JT_ERR_POLL_TIMEOUT;
        default:
            if (code >= 400 && code < 500) return JT_ERR_NOT_FOUND;
            return JT_ERR_INTERNAL;
    }
}
static jt_err_t do_req(const char *method, const char *path, const char *content_type,
                       const uint8_t *body, size_t body_len, const char *idem_key,
                       char *resp_buf, size_t resp_cap, int *out_http)
{
    char url[256];
    snprintf(url, sizeof(url), "%s%s", s_base, path);
    resp_t r = { .buf = resp_buf, .len = 0, .cap = resp_cap };
    resp_buf[0] = '\0';
    esp_http_client_config_t cfg = { .url = url, .event_handler = on_data, .user_data = &r, .timeout_ms = 15000 };
    esp_http_client_handle_t c = esp_http_client_init(&cfg);
    esp_http_client_set_method(c, strcmp(method, "POST") == 0 ? HTTP_METHOD_POST : HTTP_METHOD_GET);
    esp_http_client_set_header(c, "X-Terminal-Id", s_terminal_id);
    if (s_token[0]) { char ah[160]; snprintf(ah, sizeof(ah), "Bearer %s", s_token); esp_http_client_set_header(c, "Authorization", ah); }
    if (content_type) esp_http_client_set_header(c, "Content-Type", content_type);
    if (idem_key) esp_http_client_set_header(c, "Idempotency-Key", idem_key);
    if (body && body_len) esp_http_client_set_post_field(c, (const char*)body, (int)body_len);
    esp_err_t e = esp_http_client_perform(c);
    int http = esp_http_client_get_status_code(c);
    if (out_http) *out_http = http;
    esp_http_client_cleanup(c);
    if (e != ESP_OK) { ESP_LOGE(TAG, "%s %s transport failed", method, path); return JT_ERR_INTERNAL; }
    cJSON *root = cJSON_Parse(resp_buf);
    if (!root) return JT_ERR_INTERNAL;
    cJSON *code = cJSON_GetObjectItem(root, "code");
    int c = code ? code->valueint : -1;
    cJSON_Delete(root);
    return code_to_err(c);
}
jt_err_t jt_gateway_solve(const uint8_t *jpeg, size_t len, const char *idem_key, jt_job_t *out_job)
{
    if (!jpeg || len == 0) return JT_ERR_EMPTY_IMAGE;
    if (len > JT_MAX_IMAGE_BYTES) return JT_ERR_PAYLOAD_TOO_LARGE;
    if (jpeg[0] != 0xFF || jpeg[1] != 0xD8) return JT_ERR_UNSUPPORTED_MEDIA; /* JPEG SOI */
    if (!s_terminal_id[0] || strlen(s_terminal_id) != 16) return JT_ERR_MISSING_TERMINAL_ID;
    char resp[2048];
    jt_err_t e = do_req("POST", "/solve", "image/jpeg", jpeg, len, idem_key, resp, sizeof(resp), NULL);
    if (e != JT_OK) return e;
    cJSON *root = cJSON_Parse(resp);
    cJSON *data = root ? cJSON_GetObjectItem(root, "data") : NULL;
    if (!data) { if (root) cJSON_Delete(root); return JT_ERR_INTERNAL; }
    cJSON *jid = cJSON_GetObjectItem(data, "job_id");
    if (jid && cJSON_IsString(jid)) strncpy(out_job->job_id, jid->valuestring, sizeof(out_job->job_id)-1);
    cJSON *st = cJSON_GetObjectItem(data, "stage");
    out_job->stage = JT_STAGE_UPLOADING; out_job->stage_index = 0;
    if (st && cJSON_IsString(st)) for (int i = 0; i < 5; i++)
        if (strcmp(st->valuestring, JT_STAGE_NAMES[i]) == 0) { out_job->stage_index = i; out_job->stage = (jt_stage_t)i; }
    cJSON *qc = cJSON_GetObjectItem(data, "question_count");
    out_job->question_count = (qc && cJSON_IsNumber(qc)) ? qc->valueint : -1;
    out_job->failed = false;
    cJSON_Delete(root);
    return JT_OK;
}
jt_err_t jt_gateway_poll(const char *job_id, jt_job_t *out_job,
                         jt_question_t *questions, int max_q, int *out_n)
{
    char path[96]; snprintf(path, sizeof(path), "/solve/%s", job_id);
    char resp[8192];
    jt_err_t e = do_req("GET", path, NULL, NULL, 0, NULL, resp, sizeof(resp), NULL);
    if (e != JT_OK) return e;
    cJSON *root = cJSON_Parse(resp);
    cJSON *data = root ? cJSON_GetObjectItem(root, "data") : NULL;
    if (!data) { if (root) cJSON_Delete(root); return JT_ERR_INTERNAL; }
    cJSON *st = cJSON_GetObjectItem(data, "stage");
    if (st && cJSON_IsString(st)) for (int i = 0; i < 5; i++)
        if (strcmp(st->valuestring, JT_STAGE_NAMES[i]) == 0) { out_job->stage_index = i; out_job->stage = (jt_stage_t)i; }
    cJSON *status = cJSON_GetObjectItem(data, "status");
    if (status && cJSON_IsString(status) && strcmp(status->valuestring, "failed") == 0) {
        out_job->failed = true; out_job->stage = JT_STAGE_FAILED;
        cJSON *fr = cJSON_GetObjectItem(data, "failure_reason");
        if (fr && cJSON_IsString(fr)) strncpy(out_job->failure_reason, fr->valuestring, sizeof(out_job->failure_reason)-1);
    }
    cJSON *qs = cJSON_GetObjectItem(data, "questions");
    int n = 0;
    if (qs && cJSON_IsArray(qs)) {
        int cnt = cJSON_GetArraySize(qs);
        for (int i = 0; i < cnt && i < max_q; i++) {
            cJSON *q = cJSON_GetArrayItem(qs, i);
            jt_question_t *dst = &questions[n];
            memset(dst, 0, sizeof(*dst));
            cJSON *v;
            v = cJSON_GetObjectItem(q, "question_id"); if (v && cJSON_IsString(v)) strncpy(dst->question_id, v->valuestring, sizeof(dst->question_id)-1);
            v = cJSON_GetObjectItem(q, "batch_id"); if (v && cJSON_IsString(v)) strncpy(dst->batch_id, v->valuestring, sizeof(dst->batch_id)-1);
            v = cJSON_GetObjectItem(q, "correct"); dst->correct = v ? cJSON_IsTrue(v) : false;
            v = cJSON_GetObjectItem(q, "thinking"); if (v && cJSON_IsString(v)) strncpy(dst->thinking, v->valuestring, sizeof(dst->thinking)-1);
            v = cJSON_GetObjectItem(q, "answer");
            dst->answer_present = (v && cJSON_IsString(v));
            if (dst->answer_present) strncpy(dst->answer, v->valuestring, sizeof(dst->answer)-1);
            v = cJSON_GetObjectItem(q, "unlocked"); dst->unlocked = v ? cJSON_IsTrue(v) : false;
            n++;
        }
    }
    if (out_n) *out_n = n;
    cJSON_Delete(root);
    return JT_OK;
}
static jt_err_t json_post(const char *path, const char *json, const char *idem_key, char *resp, size_t cap)
{
    return do_req("POST", path, "application/json",
                  (const uint8_t*)json, json ? strlen(json) : 0, idem_key, resp, cap, NULL);
}
jt_err_t jt_gateway_cards_check(const char *question_id, const char *batch_id, jt_card_status_t *out)
{
    char body[256];
    snprintf(body, sizeof(body), "{\"question_id\":\"%s\",\"batch_id\":\"%s\"}",
             question_id ? question_id : "", batch_id ? batch_id : "");
    char resp[1024];
    jt_err_t e = json_post("/cards/check", body, NULL, resp, sizeof(resp));
    if (e != JT_OK) return e;
    cJSON *root = cJSON_Parse(resp);
    cJSON *d = root ? cJSON_GetObjectItem(root, "data") : NULL;
    if (!d) { if (root) cJSON_Delete(root); return JT_ERR_INTERNAL; }
    cJSON *v;
    v = cJSON_GetObjectItem(d, "balance"); out->balance = v ? v->valueint : 0;
    v = cJSON_GetObjectItem(d, "daily_total"); out->daily_total = v ? v->valueint : 5;
    v = cJSON_GetObjectItem(d, "advanced"); out->advanced = v ? v->valueint : 0;
    v = cJSON_GetObjectItem(d, "unlocked"); out->unlocked = v ? cJSON_IsTrue(v) : false;
    v = cJSON_GetObjectItem(d, "can_deduct"); out->can_deduct = v ? cJSON_IsTrue(v) : false;
    if (out->balance < 0) out->balance = 0; /* 余额 floor 为 0，屏上不许出现负数 */
    cJSON_Delete(root);
    return JT_OK;
}
jt_err_t jt_gateway_cards_deduct(const char *question_id, const char *batch_id,
                                 const char *job_id, const char *idem_key,
                                 jt_card_status_t *out, char *answer_out, size_t answer_cap)
{
    char body[384];
    snprintf(body, sizeof(body), "{\"question_id\":\"%s\",\"batch_id\":\"%s\",\"job_id\":\"%s\"}",
             question_id, batch_id ? batch_id : "", job_id ? job_id : "");
    char resp[4096];
    jt_err_t e = json_post("/cards/deduct", body, idem_key, resp, sizeof(resp));
    if (e != JT_OK) return e;
    cJSON *root = cJSON_Parse(resp);
    cJSON *d = root ? cJSON_GetObjectItem(root, "data") : NULL;
    if (!d) { if (root) cJSON_Delete(root); return JT_ERR_INTERNAL; }
    cJSON *v;
    v = cJSON_GetObjectItem(d, "balance"); out->balance = v ? v->valueint : 0;
    if (out->balance < 0) out->balance = 0;
    v = cJSON_GetObjectItem(d, "unlocked"); out->unlocked = v ? cJSON_IsTrue(v) : false;
    v = cJSON_GetObjectItem(d, "answer");
    if (v && cJSON_IsString(v) && answer_out) strncpy(answer_out, v->valuestring, answer_cap-1);
    cJSON_Delete(root);
    return JT_OK;
}
jt_err_t jt_gateway_cards_advance(const char *idem_key, jt_card_status_t *out)
{
    char resp[1024];
    jt_err_t e = json_post("/cards/advance", "{}", idem_key, resp, sizeof(resp));
    if (e != JT_OK) return e;
    cJSON *root = cJSON_Parse(resp);
    cJSON *d = root ? cJSON_GetObjectItem(root, "data") : NULL;
    if (!d) { if (root) cJSON_Delete(root); return JT_ERR_INTERNAL; }
    cJSON *v;
    v = cJSON_GetObjectItem(d, "balance"); out->balance = v ? v->valueint : 0;
    v = cJSON_GetObjectItem(d, "advanced"); out->advanced = v ? v->valueint : 0;
    if (out->balance < 0) out->balance = 0;
    cJSON_Delete(root);
    return JT_OK;
}
jt_err_t jt_gateway_apply(const char *question_id, const char *idem_key, char *app_id_out, size_t cap)
{
    char body[320];
    snprintf(body, sizeof(body), "{\"terminal_id\":\"%s\",\"question_id\":\"%s\"}",
             s_terminal_id, question_id ? question_id : "");
    char resp[1024];
    jt_err_t e = json_post("/applications", body, idem_key, resp, sizeof(resp));
    if (e != JT_OK) return e;
    cJSON *root = cJSON_Parse(resp);
    cJSON *d = root ? cJSON_GetObjectItem(root, "data") : NULL;
    cJSON *v = d ? cJSON_GetObjectItem(d, "application_id") : NULL;
    if (v && cJSON_IsString(v) && app_id_out) strncpy(app_id_out, v->valuestring, cap-1);
    if (root) cJSON_Delete(root);
    return JT_OK;
}
jt_err_t jt_gateway_withdraw(const char *application_id)
{
    char path[128]; snprintf(path, sizeof(path), "/applications/%s/withdraw", application_id);
    char resp[512];
    return json_post(path, "{}", NULL, resp, sizeof(resp));
}
jt_err_t jt_gateway_fetch_server_config(int *server_mode_out, char *custom_ip_out, size_t cap)
{
    char resp[1024];
    jt_err_t e = do_req("GET", "/config/server", NULL, NULL, 0, NULL, resp, sizeof(resp), NULL);
    if (e != JT_OK) return JT_ERR_SERVER_CONFIG_FETCH_FAILED;
    cJSON *root = cJSON_Parse(resp);
    cJSON *d = root ? cJSON_GetObjectItem(root, "data") : NULL;
    if (!d) { if (root) cJSON_Delete(root); return JT_ERR_SERVER_CONFIG_FETCH_FAILED; }
    cJSON *m = cJSON_GetObjectItem(d, "server_mode");
    if (server_mode_out) *server_mode_out = (m && cJSON_IsString(m) && strcmp(m->valuestring, "custom") == 0) ? 1 : 0;
    cJSON *ip = cJSON_GetObjectItem(d, "custom_ip");
    if (custom_ip_out) { if (ip && cJSON_IsString(ip)) strncpy(custom_ip_out, ip->valuestring, cap-1); else custom_ip_out[0] = '\0'; }
    cJSON_Delete(root);
    return JT_OK;
}
jt_err_t jt_gateway_fetch_environment(char *temp_out, size_t temp_cap,
                                     char *city_out, size_t city_cap,
                                     char *memo_out, size_t memo_cap)
{
    /* A10 是公开口，不需鉴权；本调用不带 X-Terminal-Id 以外的鉴权头。
     * 未查到/未联网时返回 ---°C，不编数字。 */
    char resp[1024];
    jt_err_t e = do_req("GET", "/config/environment", NULL, NULL, 0, NULL, resp, sizeof(resp), NULL);
    if (e != JT_OK) {
        if (temp_out) strncpy(temp_out, "---°C", temp_cap-1);
        if (memo_out) memo_out[0] = '\0';
        return e;
    }
    cJSON *root = cJSON_Parse(resp);
    cJSON *d = root ? cJSON_GetObjectItem(root, "data") : NULL;
    if (!d) { if (root) cJSON_Delete(root); return JT_ERR_INTERNAL; }
    cJSON *v;
    v = cJSON_GetObjectItem(d, "temperature");
    if (temp_out) strncpy(temp_out, (v && cJSON_IsString(v)) ? v->valuestring : "---°C", temp_cap-1);
    v = cJSON_GetObjectItem(d, "city");
    if (city_out) strncpy(city_out, (v && cJSON_IsString(v)) ? v->valuestring : "", city_cap-1);
    v = cJSON_GetObjectItem(d, "memo");
    if (memo_out) strncpy(memo_out, (v && cJSON_IsString(v)) ? v->valuestring : "", memo_cap-1);
    cJSON_Delete(root);
    return JT_OK;
}
jt_err_t jt_gateway_cancel_job(const char *job_id)
{
    char path[96]; snprintf(path, sizeof(path), "/solve/%s/cancel", job_id);
    char resp[512];
    return json_post(path, "{}", NULL, resp, sizeof(resp));
}
jt_err_t jt_gateway_skip_question(const char *job_id, int question_index)
{
    char path[96]; snprintf(path, sizeof(path), "/solve/%s/skip", job_id);
    char body[64]; snprintf(body, sizeof(body), "{\"question_index\":%d}", question_index);
    char resp[512];
    return json_post(path, body, NULL, resp, sizeof(resp));
}
