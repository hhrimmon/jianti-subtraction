#pragma once
#include <stdbool.h>
/* Wi-Fi（ESP32-C6 经 SDIO，只支持 2.4GHz；配网须覆盖双频合一路由器场景）。
 * 信号强弱用文字强/中/弱；SSID 屏上只显示前 8 位。
 * 连通测试三步：Wi-Fi → 互联网 → 服务器，按真实网络打勾/打叉，不恒通过；
 * 第 3 步必须测服务端拉取的当前服务器配置，未拉取到显示未测。 */
typedef enum { JT_SIG_WEAK = 0, JT_SIG_MEDIUM, JT_SIG_STRONG } jt_sig_t;
bool jt_wifi_init_sta(void);
bool jt_wifi_connect_saved(void); /* 用 NVS 里保存的 SSID/密码连接 */
bool jt_wifi_scan_and_connect(const char *ssid, const char *password);
jt_sig_t jt_wifi_signal(void);
const char *jt_wifi_signal_text(jt_sig_t s); /* 强/中/弱 */
void jt_wifi_ssid_display8(char out[9]); /* SSID 前 8 位 */
typedef struct { bool wifi_ok; bool internet_ok; bool server_ok; bool server_tested; } jt_conn_test_t;
jt_conn_test_t jt_connectivity_test(void); /* 三步依次测 */
