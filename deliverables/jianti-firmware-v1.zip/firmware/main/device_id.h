#pragma once
#include <stdint.h>
#include <stdbool.h>
/* 设备 ID（手册 v2 §1.5）：16 位纯数字，第 1 位是终端类型码（1=嵌入式）。
 * 后 15 位来自 Wi-Fi 地址转换；拿不到 Wi-Fi 地址时用本地稳定哈希转 15 位，
 * 原始串号不上传；同一台每次一致。服务端不替设备编 ID，终端不自动顺延。
 * 显示按 4-4-4-4 分组，冒号紧挨数字 1：设备ID:1040 0598 3277 3436（此为原型演示码，
 * 仅作格式示例，真实设备 ID 运行时由 Wi-Fi 地址生成，绝不写死演示码）。
 * 二维码载荷带 JianTi- 前缀：JianTi-<16 位数字>；解析两种形式都接。 */
#define JT_DEVICE_ID_LEN 16
#define JT_DEVICE_ID_TYPE_EMBEDDED '1'
bool jt_device_id_get(char out[JT_DEVICE_ID_LEN + 1]);      /* 运行时生成，失败返回 false */
void jt_device_id_format_grouped(const char id[JT_DEVICE_ID_LEN + 1],
                                 char out[JT_DEVICE_ID_LEN + 4]); /* 4-4-4-4，加 3 空格 */
void jt_device_id_qr_payload(const char id[JT_DEVICE_ID_LEN + 1],
                             char out[8 + JT_DEVICE_ID_LEN]);   /* JianTi- + 16 位 */
