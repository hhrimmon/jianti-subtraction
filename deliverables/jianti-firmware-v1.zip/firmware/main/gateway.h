#pragma once
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include "errors.h"
/* 网关客户端（接口 v9，MD5 91393356）。终端只跟网关 8000 说话，不直连业务模块、
 * 不直连大模型、不直连存储层。全部拉取/轮询，不建 WebSocket/SSE/推送通道。
 * 官方地址写死：solve.mhq-ai.xyz:8000（板上不显示）；自有地址由服务端配置下发。
 * 除 POST /solve（raw JPEG）外一律 JSON；返回一律 JSON 信封 {code,message,data}，
 * 程序只判 code，message 只作展示。 */
#define JT_GATEWAY_OFFICIAL_HOST "solve.mhq-ai.xyz"
#define JT_GATEWAY_PORT 8000
#define JT_MAX_IMAGE_BYTES (8 * 1024 * 1024) /* 8MB 上限（2026-11-08 由 2MB 改到 8MB） */
#define JT_POLL_INTERVAL_MS 1000
#define JT_POLL_MAX_MS 60000 /* 轮询 1 秒一次、最多 60 秒，超时按 50401 处理 */
typedef enum { JT_STAGE_UPLOADING=0, JT_STAGE_GATEWAY, JT_STAGE_MODEL, JT_STAGE_NLP, JT_STAGE_DELIVERING, JT_STAGE_DONE, JT_STAGE_FAILED } jt_stage_t;
extern const char *JT_STAGE_NAMES[5]; /* uploading/gateway/model/nlp/delivering */
typedef struct {
    char job_id[64];
    jt_stage_t stage;
    int stage_index; /* 0-4 */
    int question_count; /* 可为 -1（null，终端不拿它当题数定稿） */
    bool failed;
    char failure_reason[64]; /* recognition_failed 等 */
    char failure_text[128];  /* 给人看的一句话 */
} jt_job_t;
typedef struct {
    char question_id[64];
    char batch_id[64];
    bool correct;            /* 只判最终结果，不判过程 */
    char thinking[2048];     /* 思路：第一句“这个题做对了/做错了”+分步运算，停在还差最后一下 */
    char answer[2048];       /* 完整过程+答案；未解锁时服务端返回 null，终端不得编 */
    bool answer_present;     /* false = 服务端未给答案（未解锁），绝不编一个顶上去 */
    bool unlocked;
} jt_question_t;
typedef struct {
    int balance;        /* 今日剩余（服务端为准，>=0） */
    int daily_total;    /* 每日张数，默认 5，最大 9 */
    int advanced;       /* 已预支张数 */
    bool unlocked;      /* 该题是否已解锁 */
    bool can_deduct;
} jt_card_status_t;
/* base_url 由配置决定：官方 http://solve.mhq-ai.xyz:8000；自有 http://<custom_ip>:8000
 *（U21：默认 http、端口 8000，地址自带端口时以地址为准）。 */
void jt_gateway_set_base(const char *base_url);
void jt_gateway_set_auth(const char *terminal_id_16, const char *bearer_token);
/* A1：POST /solve，raw JPEG。未绑定一律拒收；非 JPEG、超 8MB 一律拒收。
 * 成功建 job 才进第 4 屏；网关拒收（40001/40101/41301/41501/50301）时停在
 * 第 3 屏或第 2 屏，不进第 4 屏。同一张照片重发用同一个 Idempotency-Key。 */
jt_err_t jt_gateway_solve(const uint8_t *jpeg, size_t len, const char *idem_key, jt_job_t *out_job);
/* A2：GET /solve/{job_id}，轮询查进度。五步全亮才进思路页；失败停在失败步。 */
jt_err_t jt_gateway_poll(const char *job_id, jt_job_t *out_job,
                         jt_question_t *questions, int max_q, int *out_n);
/* A3：POST /cards/check。失败时不按本地余额扣卡、不进结果页。 */
jt_err_t jt_gateway_cards_check(const char *question_id, const char *batch_id, jt_card_status_t *out);
/* A4：POST /cards/deduct。直接扣 1 张，无确认弹窗；同一批同一题只扣一次，
 * 已解锁再点不扣卡直接进结果页；返回 answer 才进第 6 屏。 */
jt_err_t jt_gateway_cards_deduct(const char *question_id, const char *batch_id,
                                 const char *job_id, const char *idem_key,
                                 jt_card_status_t *out, char *answer_out, size_t answer_cap);
/* A5：POST /cards/advance，每次 1 张。A6：POST /applications 发申请单。
 * A7：POST /applications/{id}/withdraw，取消=撤回。 */
jt_err_t jt_gateway_cards_advance(const char *idem_key, jt_card_status_t *out);
jt_err_t jt_gateway_apply(const char *question_id, const char *idem_key, char *app_id_out, size_t cap);
jt_err_t jt_gateway_withdraw(const char *application_id);
/* A8：GET /config/server，取不到按上次官方默认走，第 7 屏显示未更新。
 * A10：GET /config/environment，公开口，不需鉴权；未查到显示 ---°C，不编数字。 */
jt_err_t jt_gateway_fetch_server_config(int *server_mode_out, char *custom_ip_out, size_t cap);
jt_err_t jt_gateway_fetch_environment(char *temp_out, size_t temp_cap,
                                     char *city_out, size_t city_cap,
                                     char *memo_out, size_t memo_cap);
/* A12：离开处理页取消未决步骤。A13：跳过当前题，不扣卡。 */
jt_err_t jt_gateway_cancel_job(const char *job_id);
jt_err_t jt_gateway_skip_question(const char *job_id, int question_index);
/* 幂等键：每次操作生成一个 UUID（v4）。同一操作重发用同一个键。 */
void jt_uuid_v4(char out[37]);
