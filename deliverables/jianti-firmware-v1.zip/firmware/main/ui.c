#include "ui.h"
#include "app.h"
#include <string.h>
#include "lvgl.h"
#include "esp_lvgl_port.h"
#include "esp_log.h"
static const char *TAG = "ui";
static lv_obj_t *s_screens[9] = {0}; /* 1-8 */
static lv_obj_t *s_stage_dots[5] = {0};
static lv_obj_t *s_toast = NULL;
void jt_ui_init(void)
{
    const lvgl_port_cfg_t cfg = ESP_LVGL_PORT_INIT_CONFIG();
    lvgl_port_init(&cfg);
    /* Waveshare BSP 初始化显示 + GT911 触摸（BSP v1.0.1），联调时以 BSP 为准。 */
    extern void jt_ui_screens_build(void);
    jt_ui_screens_build();
}
void jt_ui_show_screen(int n)
{
    if (n < 1 || n > 8 || !s_screens[n]) return;
    lvgl_port_lock(0);
    lv_scr_load(s_screens[n]);
    lvgl_port_unlock();
    ESP_LOGI(TAG, "show screen %d", n);
}
void jt_ui_set_stage(int idx)
{
    lvgl_port_lock(0);
    for (int i = 0; i < 5; i++) {
        if (!s_stage_dots[i]) continue;
        lv_obj_set_style_bg_color(s_stage_dots[i],
            lv_color_hex(i <= idx ? JT_COLOR_BLUE : JT_COLOR_GREY), 0);
    }
    lvgl_port_unlock();
}
void jt_ui_show_stage_failed(int idx, const char *reason)
{
    lvgl_port_lock(0);
    if (idx >= 0 && idx < 5 && s_stage_dots[idx])
        lv_obj_set_style_bg_color(s_stage_dots[idx], lv_color_hex(JT_COLOR_RED), 0);
    lvgl_port_unlock();
    jt_ui_show_toast(reason);
}
void jt_ui_show_toast(const char *text)
{
    ESP_LOGI(TAG, "toast: %s", text);
    /* 提示条为一句话浮层，屏上不写多余解释句；实现见 ui_screens.c。 */
    extern void jt_ui_toast_impl(const char *text);
    jt_ui_toast_impl(text);
}
void jt_ui_show_qr_page(const char *payload)
{
    (void)payload;
    extern void jt_ui_qr_impl(const char *payload);
    jt_ui_qr_impl(payload);
}
/* 供 ui_screens.c 注册屏对象 */
void jt_ui_register_screen(int n, lv_obj_t *scr) { if (n >= 1 && n <= 8) s_screens[n] = scr; }
void jt_ui_register_stage_dot(int i, lv_obj_t *dot) { if (i >= 0 && i < 5) s_stage_dots[i] = dot; }
