/* 简题嵌入式终端固件 — 入口
 * 板子：微雪 ESP32-P4-WIFI6-Touch-LCD-4.3-C（SKU 33875）
 * 流程：开机 → 配网（Soft AP，全程一个绑定二维码）→ 绑定 → 横屏主界面（第 2 屏 home）
 * 判题/解题全部走网关 8000，终端只做拍照、显示、管理入口，不做本地判题、
 * 不做本地大模型运算、不存卡账本。 */
#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "app.h"
#include "wifi_net.h"
#include "camera_capture.h"
#include "softap_prov.h"
static const char *TAG = "jianti";
static void poll_task(void *arg)
{
    (void)arg;
    while (1) {
        jt_app_poll_tick(); /* 第 4 屏轮询：1 秒一次 */
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}
void app_main(void)
{
    ESP_LOGI(TAG, "jianti terminal starting (PRD v5.6, prototype v113, interface v9)");
    esp_err_t e = nvs_flash_init();
    if (e == ESP_ERR_NVS_NO_FREE_PAGES || e == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ESP_ERROR_CHECK(nvs_flash_init());
    }
    jt_wifi_init_sta();
    /* 开机配网：无保存的 Wi-Fi 时起 Soft AP，屏上提示连手机热点；
     * 有保存的 Wi-Fi 时直接连，联网成功后显示绑定二维码（全程一个二维码）。 */
    if (!jt_wifi_connect_saved()) {
        jt_softap_start();
    }
    if (!jt_camera_init()) ESP_LOGE(TAG, "camera init failed, capture will fail gracefully");
    jt_app_init();
    xTaskCreate(poll_task, "jt_poll", 4096, NULL, 5, NULL);
}
