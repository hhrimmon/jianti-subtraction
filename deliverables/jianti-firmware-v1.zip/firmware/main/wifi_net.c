#include "wifi_net.h"
#include <string.h>
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_netif.h"
#include "esp_log.h"
#include "esp_http_client.h"
#include "config_store.h"
static const char *TAG = "wifi";
bool jt_wifi_init_sta(void)
{
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_create_default_wifi_sta();
    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_start());
    return true;
}
bool jt_wifi_connect_saved(void)
{
    jt_config_t c; jt_config_load(&c);
    if (!c.ssid[0]) return false;
    return jt_wifi_scan_and_connect(c.ssid, c.ssid_password);
}
bool jt_wifi_scan_and_connect(const char *ssid, const char *password)
{
    wifi_config_t wc = {0};
    strncpy((char*)wc.sta.ssid, ssid, sizeof(wc.sta.ssid)-1);
    strncpy((char*)wc.sta.password, password ? password : "", sizeof(wc.sta.password)-1);
    wc.sta.threshold.authmode = WIFI_AUTH_WPA2_PSK;
    if (esp_wifi_set_config(WIFI_IF_STA, &wc) != ESP_OK) return false;
    if (esp_wifi_connect() != ESP_OK) return false;
    /* 等待连接结果由事件循环处理；此处只返回发起结果，状态由 app 轮询。 */
    ESP_LOGI(TAG, "connecting to saved SSID (name not logged in full)");
    return true;
}
jt_sig_t jt_wifi_signal(void)
{
    wifi_ap_record_t ap;
    if (esp_wifi_sta_get_ap_info(&ap) != ESP_OK) return JT_SIG_WEAK;
    if (ap.rssi >= -55) return JT_SIG_STRONG;
    if (ap.rssi >= -70) return JT_SIG_MEDIUM;
    return JT_SIG_WEAK;
}
const char *jt_wifi_signal_text(jt_sig_t s) { return s == JT_SIG_STRONG ? "强" : (s == JT_SIG_MEDIUM ? "中" : "弱"); }
void jt_wifi_ssid_display8(char out[9])
{
    jt_config_t c; jt_config_load(&c);
    size_t n = strlen(c.ssid); if (n > 8) n = 8;
    memcpy(out, c.ssid, n); out[n] = '\0';
}
jt_conn_test_t jt_connectivity_test(void)
{
    jt_conn_test_t r = {0};
    wifi_ap_record_t ap;
    r.wifi_ok = (esp_wifi_sta_get_ap_info(&ap) == ESP_OK);
    if (!r.wifi_ok) return r;
    /* 第二步：互联网（对公网地址做一次 HTTP HEAD，不编一个“通”的假结果） */
    esp_http_client_config_t cfg = { .url = "http://example.com", .timeout_ms = 5000 };
    esp_http_client_handle_t c = esp_http_client_init(&cfg);
    esp_http_client_set_method(c, HTTP_METHOD_HEAD);
    r.internet_ok = (esp_http_client_perform(c) == ESP_OK);
    esp_http_client_cleanup(c);
    if (!r.internet_ok) return r;
    /* 第三步：服务器——测服务端拉取的当前服务器配置；未拉取到显示未测。 */
    jt_config_t cc; jt_config_load(&cc);
    char base[128];
    if (cc.server_mode == JT_SERVER_CUSTOM && cc.custom_ip[0])
        snprintf(base, sizeof(base), "http://%s:8000", cc.custom_ip);
    else
        snprintf(base, sizeof(base), "http://solve.mhq-ai.xyz:8000");
    char url[192]; snprintf(url, sizeof(url), "%s/config/server", base);
    esp_http_client_config_t c2 = { .url = url, .timeout_ms = 5000 };
    esp_http_client_handle_t h2 = esp_http_client_init(&c2);
    esp_err_t e = esp_http_client_perform(h2);
    int http = esp_http_client_get_status_code(h2);
    esp_http_client_cleanup(h2);
    r.server_tested = true;
    r.server_ok = (e == ESP_OK && http == 200);
    return r;
}
