#include "softap_prov.h"
#include <string.h>
#include <stdio.h>
#include "esp_wifi.h"
#include "esp_netif.h"
#include "device_id.h"
static bool s_running = false;
void jt_softap_hotspot_name(char out[32])
{
    char id[17] = {0};
    if (!jt_device_id_get(id)) { snprintf(out, 32, "JianTi-unknown"); return; }
    snprintf(out, 32, "JianTi-%s", id);
}
bool jt_softap_start(void)
{
    char name[32]; jt_softap_hotspot_name(name);
    esp_netif_create_default_wifi_ap();
    wifi_config_t wc = {0};
    strncpy((char*)wc.ap.ssid, name, sizeof(wc.ap.ssid)-1);
    wc.ap.ssid_len = strlen(name);
    wc.ap.authmode = WIFI_AUTH_OPEN;
    wc.ap.max_connection = 1;
    if (esp_wifi_set_mode(WIFI_MODE_APSTA) != ESP_OK) return false;
    if (esp_wifi_set_config(WIFI_IF_AP, &wc) != ESP_OK) return false;
    s_running = true;
    return true;
}
void jt_softap_stop(void) { esp_wifi_set_mode(WIFI_MODE_STA); s_running = false; }
bool jt_softap_is_running(void) { return s_running; }
