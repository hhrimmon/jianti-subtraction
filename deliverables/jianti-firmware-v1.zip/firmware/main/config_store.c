#include "config_store.h"
#include <string.h>
#include "nvs_flash.h"
#include "nvs.h"
#include "esp_log.h"
static const char *TAG = "config";
#define NS "jianti"
bool jt_config_load(jt_config_t *cfg)
{
    memset(cfg, 0, sizeof(*cfg));
    cfg->server_mode = JT_SERVER_OFFICIAL;
    cfg->daily_total = 5;
    cfg->advance_multiplier = 0;
    nvs_handle_t h;
    if (nvs_open(NS, NVS_READONLY, &h) != ESP_OK) return false; /* 首次开机：用默认值 */
    size_t n;
    n = sizeof(cfg->ssid);            nvs_get_str(h, "ssid", cfg->ssid, &n);
    n = sizeof(cfg->ssid_password);   nvs_get_str(h, "ssid_pwd", cfg->ssid_password, &n);
    uint8_t m = 0; nvs_get_u8(h, "srv_mode", &m); cfg->server_mode = m ? JT_SERVER_CUSTOM : JT_SERVER_OFFICIAL;
    n = sizeof(cfg->custom_ip);       nvs_get_str(h, "custom_ip", cfg->custom_ip, &n);
    n = sizeof(cfg->terminal_token);  nvs_get_str(h, "term_token", cfg->terminal_token, &n);
    uint8_t b = 0; nvs_get_u8(h, "bound", &b); cfg->bound = b != 0;
    int32_t d = 5; nvs_get_i32(h, "daily", &d); cfg->daily_total = (int)d;
    int32_t a = 0; nvs_get_i32(h, "adv_mult", &a); cfg->advance_multiplier = (int)a;
    nvs_close(h);
    return true;
}
bool jt_config_save(const jt_config_t *cfg)
{
    nvs_handle_t h;
    if (nvs_open(NS, NVS_READWRITE, &h) != ESP_OK) return false;
    nvs_set_str(h, "ssid", cfg->ssid);
    nvs_set_str(h, "ssid_pwd", cfg->ssid_password);
    nvs_set_u8(h, "srv_mode", (uint8_t)cfg->server_mode);
    nvs_set_str(h, "custom_ip", cfg->custom_ip);
    nvs_set_str(h, "term_token", cfg->terminal_token);
    nvs_set_u8(h, "bound", cfg->bound ? 1 : 0);
    nvs_set_i32(h, "daily", cfg->daily_total);
    nvs_set_i32(h, "adv_mult", cfg->advance_multiplier);
    esp_err_t e = nvs_commit(h);
    nvs_close(h);
    if (e != ESP_OK) ESP_LOGE(TAG, "nvs commit failed");
    return e == ESP_OK;
}
bool jt_config_clear_credentials(void)
{
    nvs_handle_t h;
    if (nvs_open(NS, NVS_READWRITE, &h) != ESP_OK) return false;
    nvs_erase_key(h, "ssid_pwd");
    nvs_erase_key(h, "term_token");
    esp_err_t e = nvs_commit(h);
    nvs_close(h);
    return e == ESP_OK;
}
