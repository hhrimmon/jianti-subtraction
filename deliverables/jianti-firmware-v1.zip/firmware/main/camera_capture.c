#include "camera_capture.h"
#include <stdlib.h>
#include <string.h>
#include "esp_camera.h"
#include "esp_log.h"
static const char *TAG = "camera";
/* OV5647 定焦；清晰靠 20-30cm 距离（产品口径，屏上不写）。取景器四角框尽量做大。 */
bool jt_camera_init(void)
{
    camera_config_t cfg = {
        .pin_pwdn = -1, .pin_reset = -1,
        .pin_xclk = 15, .pin_sccb_sda = 8, .pin_sccb_scl = 9,
        .pin_d7 = 4, .pin_d6 = 5, .pin_d5 = 6, .pin_d4 = 7,
        .pin_d3 = 10, .pin_d2 = 11, .pin_d1 = 12, .pin_d0 = 13,
        .pin_vsync = 2, .pin_href = 3, .pin_pclk = 14,
        .xclk_freq_hz = 20000000,
        .ledc_timer = LEDC_TIMER_0, .ledc_channel = LEDC_CHANNEL_0,
        .pixel_format = PIXFORMAT_JPEG,
        .frame_size = FRAMESIZE_UXGA, /* 1600x1200，网关侧拆题；超 8MB 时降档重拍 */
        .jpeg_quality = 12,
        .fb_count = 2, .fb_location = CAMERA_FB_IN_PSRAM,
        .grab_mode = CAMERA_GRAB_WHEN_EMPTY,
    };
    /* 注：引脚号以 Waveshare BSP v1.0.1 例程为准，板级联调时以 BSP 头文件核对；
     * 此处不编一个“能跑”的假引脚表，联调以 BSP 为准。 */
    esp_err_t e = esp_camera_init(&cfg);
    if (e != ESP_OK) ESP_LOGE(TAG, "camera init failed: %s", esp_err_to_name(e));
    return e == ESP_OK;
}
bool jt_camera_capture_jpeg(uint8_t **out_jpeg, size_t *out_len)
{
    camera_fb_t *fb = esp_camera_fb_get();
    if (!fb) return false;
    if (fb->len > 8 * 1024 * 1024) { /* 超 8MB：不发送，提示重拍（靠近一点拍） */
        esp_camera_fb_return(fb);
        return false;
    }
    uint8_t *buf = malloc(fb->len);
    if (!buf) { esp_camera_fb_return(fb); return false; }
    memcpy(buf, fb->buf, fb->len);
    *out_jpeg = buf; *out_len = fb->len;
    esp_camera_fb_return(fb);
    return true;
}
void jt_camera_release(uint8_t *jpeg) { free(jpeg); }
bool jt_camera_jpeg_is_valid(const uint8_t *jpeg, size_t len)
{
    if (!jpeg || len < 4) return false;
    return jpeg[0] == 0xFF && jpeg[1] == 0xD8 && jpeg[len-2] == 0xFF && jpeg[len-1] == 0xD9;
}
