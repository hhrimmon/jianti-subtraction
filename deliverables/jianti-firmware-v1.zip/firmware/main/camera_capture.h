#pragma once
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
/* 摄像头（OV5647，MIPI-CSI，P4 硬件 JPEG 编解码与 ISP）。
 * 只做拍题一种状态，不用前置摄像头、不用其他拍摄模式。
 * 拍摄不要求整页，拍入框内的题、有几道是几道；照片压到 8MB 以内发网关。 */
bool jt_camera_init(void);
bool jt_camera_capture_jpeg(uint8_t **out_jpeg, size_t *out_len); /* 调用方用完须 free */
void jt_camera_release(uint8_t *jpeg);
bool jt_camera_jpeg_is_valid(const uint8_t *jpeg, size_t len); /* SOI/EOI 检查 */
