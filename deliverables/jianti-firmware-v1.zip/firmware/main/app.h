#pragma once
#include <stdbool.h>
#include "gateway.h"
/* 应用状态机（PRD v5.6 第 1-2 章 + 手册 v2 §2）。
 * 屏：1 锁屏、2 home、3 取景器、4 处理、5 思路(A)、6 结果(B)、7 设置、8 领取。
 * 导航铁律：
 * - 1⇄2 左右滑循环、来回转圈，不是单向一进一退；滑到 home 再往同一方向滑即回锁屏，
 *   绝不从 home 滑进第 3 屏；第 3 屏只点拍照钮进；只有 1、2 屏可以滑动，其他页面一律不能滑动。
 * - 每屏左上角 Home 键直回第 2 屏；B 页拐弯箭头只回本题 A 页；取景器返回钮回第 2 屏。
 * - 无 60 秒自动回锁屏，停留在当前屏，手动返回。
 * - 处理页无手动退出按钮；五步全亮才进思路页；离开处理页取消未决步骤（A12）。 */
typedef enum { JT_SCREEN_LOCK=1, JT_SCREEN_HOME=2, JT_SCREEN_CAPTURE=3, JT_SCREEN_PROCESSING=4,
               JT_SCREEN_THINKING=5, JT_SCREEN_RESULT=6, JT_SCREEN_SETTINGS=7, JT_SCREEN_CLAIM=8 } jt_screen_t;
typedef struct {
    jt_screen_t screen;
    int total_questions;   /* 本批题数（服务端下发，-1=未知） */
    int current_index;     /* 0-based，A 页翻题用 */
    jt_job_t job;
    jt_question_t questions[16];
    int n_questions;
    jt_card_status_t cards; /* 服务端为准 */
    char batch_id[64];
    char application_id[64];
    bool has_application_pending;
    char temperature[16];  /* ---°C 或服务端值，不编数字 */
    char memo[256];        /* 服务端下发，不能内置写死 */
    char device_id[17];
} jt_app_t;
extern jt_app_t g_app;
void jt_app_init(void);
bool jt_app_go_home(void);                 /* Home 键：直回第 2 屏 */
bool jt_app_swipe(int direction);          /* 1=左滑，-1=右滑；只有 1、2 屏有效 */
bool jt_app_enter_capture(void);           /* 只从第 2 屏点拍照圆钮进 */
bool jt_app_shutter(void);                 /* 快门/勾：拍→A1→第 4 屏；拒收停在第 3/2 屏 */
void jt_app_poll_tick(void);               /* 第 4 屏轮询：1 秒一次、最多 60 秒 */
bool jt_app_next_question(void);           /* A 页下一题：首尾循环 */
bool jt_app_prev_question(void);           /* A 页上一题：首尾循环 */
bool jt_app_tap_card(void);                /* 点“解题卡 N 张”：先查卡，有卡扣 1 张进 B 页，无卡转领取页 */
bool jt_app_back_from_result(void);        /* B 页拐弯箭头：只回本题 A 页 */
bool jt_app_advance_card(void);            /* 领取页：自己来预支，每次 1 张 */
bool jt_app_apply_card(void);              /* 领取页：向家长申请，发完停领取页 */
bool jt_app_withdraw_application(void);    /* 撤回申请：取消=撤回 */
bool jt_app_enter_settings(void);
bool jt_app_leave_processing(void);        /* 离开处理页：调 A12 取消未决步骤 */
