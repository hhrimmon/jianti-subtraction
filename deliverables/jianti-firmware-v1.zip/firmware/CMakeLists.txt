# 简题嵌入式终端固件 — ESP-IDF 工程（全新开发，不套旧代码）
# 板子：微雪 ESP32-P4-WIFI6-Touch-LCD-4.3-C（SKU 33875，带 OV5647）
# 依据：PRD v5.6（MD5 3a3872ab）、原型板子 v113、手机 v155/v157、
#       开发手册 v2（§1、§2、§5）、平台接口 v9（MD5 91393356，dev commit b8c487dc）
# 工具链：ESP-IDF v5.5.6，禁用 v6（见 README）；本容器无 ESP-IDF 工具链，未在本地编译，
#         构建结果以 README 与 SELFTEST.md 为准，不伪造。
cmake_minimum_required(VERSION 3.16)
include($ENV{IDF_PATH}/tools/cmake/project.cmake)
project(jianti_terminal)
