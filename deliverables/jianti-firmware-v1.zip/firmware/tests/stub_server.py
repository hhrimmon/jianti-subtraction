#!/usr/bin/env python3
"""简题网关桩服务器（仅供主机自测）。实现接口 v9 第一组 A1/A2/A3/A4/A5/A6/A7/A8/A10/A12/A13
的最小内存版，行为按《平台接口-20261116.md》（MD5 91393356）：
- A1 收 JPEG（只验 SOI，不真判题），建 job，返回 job_id + stage=uploading
- A2 轮询：每次调用 stage 前进一格（uploading→gateway→model→nlp→delivering），
  到 delivering 时下发演示题（见 test_vectors.json，明确标注为演示夹具）；
  answer 未解锁时为 null，扣卡后才给值
- A3 查卡：余额服务端算，floor 0；A4 扣卡：同一批同一题只扣一次；
  A5 预支每次 1 张，上限 daily*mult；A6 发申请；A7 撤回；A8 取服务器配置；
  A10 环境公开口：温度 ---°C（桩不编城市温度），MEMO 为空
- A11 已作废，不实现。用法：python3 stub_server.py [port，默认 18000]"""
import json, uuid, threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs

STATE = {
    "daily_total": 5, "multiplier": 0, "balance": 5, "advanced": 0,
    "jobs": {}, "unlocked": set(), "deduct_keys": set(), "advance_keys": set(),
    "applications": {}, "server_mode": "official", "custom_ip": None,
}
DEMO_Q = {
    "question_id": "demo-q-001", "batch_id": "demo-batch-001",
    "correct": False,
    "thinking": "这个题做错了\n5 × (−2) 先算出来，是 −10\n−(−4) 变成 +4，式子成了 (−3) + (−10) + 4\n(−3) 加 (−10) 是 −13，剩下的 −13 + 4 接着算",
    "answer": "(−3) + 5 × (−2) − (−4)\n= (−3) + (−10) + 4\n= −13 + 4\n= −9",
}
STAGES = ["uploading", "gateway", "model", "nlp", "delivering"]

def env(code, data=None, message="ok"):
    return {"code": code, "message": message, "data": data}

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def _send(self, obj, http=200):
        b = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(http); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def _auth(self):
        tid = self.headers.get("X-Terminal-Id", "")
        return len(tid) == 16 and tid.isdigit()
    def _json(self):
        n = int(self.headers.get("Content-Length") or 0)
        return json.loads(self.rfile.read(n) or b"{}") if n else {}
    def do_POST(self):
        p = urlparse(self.path).path
        if p == "/solve":
            if not self._auth():
                return self._send(env(40001, None, "设备未绑定"), 400)
            n = int(self.headers.get("Content-Length") or 0)
            body = self.rfile.read(n) if n else b""
            if n == 0: return self._send(env(40002, None, "请求体不是 JPEG"), 400)
            if n > 8*1024*1024: return self._send(env(41301, None, "超 8MB"), 413)
            if len(body) < 2 or body[0] != 0xFF or body[1] != 0xD8:
                return self._send(env(41501, None, "非 JPEG"), 415)
            jid = "job-" + uuid.uuid4().hex[:12]
            STATE["jobs"][jid] = {"stage_index": 0, "failed": False}
            return self._send(env(0, {"job_id": jid, "stage": "uploading",
                                       "question_count": 1, "created_at": "2026-11-18 20:00:00"}))
        if p == "/cards/check":
            if not self._auth(): return self._send(env(40101, None, "未鉴权"), 401)
            b = self._json()
            qid = b.get("question_id") or ""
            return self._send(env(0, {"balance": max(0, STATE["balance"]),
                                      "daily_total": STATE["daily_total"],
                                      "advanced": STATE["advanced"],
                                      "unlocked": qid in STATE["unlocked"],
                                      "can_deduct": STATE["balance"] > 0 and qid not in STATE["unlocked"]}))
        if p == "/cards/deduct":
            if not self._auth(): return self._send(env(40101, None, "未鉴权"), 401)
            key = self.headers.get("Idempotency-Key", "")
            if not key: return self._send(env(40003, None, "缺 Idempotency-Key"), 400)
            b = self._json(); qid = b.get("question_id", "")
            if qid in STATE["unlocked"]:
                return self._send(env(0, {"balance": max(0, STATE["balance"]), "unlocked": True,
                                          "question_id": qid, "answer": DEMO_Q["answer"]}))
            if ("deduct:" + key) in STATE["deduct_keys"]:
                return self._send(env(0, {"balance": max(0, STATE["balance"]), "unlocked": True,
                                          "question_id": qid, "answer": DEMO_Q["answer"]}))
            if STATE["balance"] <= 0:
                return self._send(env(40201, None, "无卡"), 402)
            STATE["deduct_keys"].add("deduct:" + key)
            STATE["balance"] -= 1; STATE["unlocked"].add(qid)
            return self._send(env(0, {"balance": STATE["balance"], "unlocked": True,
                                      "question_id": qid, "answer": DEMO_Q["answer"]}))
        if p == "/cards/advance":
            key = self.headers.get("Idempotency-Key", "")
            if ("adv:" + key) in STATE["advance_keys"]:
                return self._send(env(0, {"balance": STATE["balance"], "advanced": STATE["advanced"],
                                          "advance_limit": STATE["daily_total"]*STATE["multiplier"],
                                          "remaining_advance": 0}))
            limit = STATE["daily_total"] * STATE["multiplier"]
            if STATE["advanced"] >= limit:
                return self._send(env(40301, None, "到预支上限"), 403)
            STATE["advance_keys"].add("adv:" + key)
            STATE["advanced"] += 1; STATE["balance"] += 1
            return self._send(env(0, {"balance": STATE["balance"], "advanced": STATE["advanced"],
                                      "advance_limit": limit,
                                      "remaining_advance": limit - STATE["advanced"]}))
        if p == "/applications":
            key = self.headers.get("Idempotency-Key", "")
            b = self._json()
            if b.get("terminal_id", "") != self.headers.get("X-Terminal-Id", ""):
                return self._send(env(400, None, "terminal_id 与头不一致"), 400)
            aid = "app-" + uuid.uuid4().hex[:12]
            STATE["applications"][aid] = "pending"
            return self._send(env(0, {"application_id": aid, "status": "pending",
                                      "created_at": "2026-11-18 20:00:00"}))
        if p.startswith("/applications/") and p.endswith("/withdraw"):
            aid = p.split("/")[2]
            if aid not in STATE["applications"]:
                return self._send(env(404, None, "单不存在"), 404)
            if STATE["applications"][aid] != "pending":
                return self._send(env(409, None, "状态已终结"), 409)
            STATE["applications"][aid] = "withdrawn"
            return self._send(env(0, {"application_id": aid, "status": "withdrawn"}))
        if p.startswith("/solve/") and p.endswith("/cancel"):
            jid = p.split("/")[2]
            if jid not in STATE["jobs"]: return self._send(env(404, None, "job 不存在"), 404)
            STATE["jobs"][jid]["failed"] = True
            return self._send(env(0, {"job_id": jid, "status": "cancelled"}))
        if p.startswith("/solve/") and p.endswith("/skip"):
            jid = p.split("/")[2]
            if jid not in STATE["jobs"]: return self._send(env(404, None, "job 不存在"), 404)
            return self._send(env(0, {"skipped": True, "job_id": jid, "question_index": 0}))
        return self._send(env(404, None, "没有这个接口"), 404)
    def do_GET(self):
        u = urlparse(self.path); p = u.path
        if p.startswith("/solve/"):
            jid = p.split("/")[2]
            job = STATE["jobs"].get(jid)
            if not job: return self._send(env(404, None, "job 不存在"), 404)
            idx = job["stage_index"]
            stage = STAGES[idx]
            if idx < 4: job["stage_index"] += 1
            qs = []
            if stage == "delivering":
                q = dict(DEMO_Q); q["unlocked"] = DEMO_Q["question_id"] in STATE["unlocked"]
                q["answer"] = DEMO_Q["answer"] if q["unlocked"] else None
                qs = [q]
            return self._send(env(0, {"job_id": jid, "stage": stage, "stage_index": idx,
                                      "question_count": 1, "questions": qs}))
        if p == "/config/server":
            return self._send(env(0, {"server_mode": STATE["server_mode"],
                                      "custom_ip": STATE["custom_ip"], "updated_at": "2026-11-18 20:00:00"}))
        if p == "/config/environment":
            return self._send(env(0, {"temperature": "---°C", "city": None, "memo": "",
                                      "updated_at": "2026-11-18 20:00:00"}))
        return self._send(env(404, None, "没有这个接口"), 404)

if __name__ == "__main__":
    import sys
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 18000
    HTTPServer(("127.0.0.1", port), H).serve_forever()
