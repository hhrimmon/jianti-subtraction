#!/usr/bin/env python3
"""主机自测：模拟终端状态机 + 网关桩服务器（tests/stub_server.py），验证
F1 主链路、F2 翻题循环、F3 预支/申请、卡规则、导航铁律、失败分支。
这是主机逻辑模拟，不是真机测试；真机（ESP32-P4 板 + 真网关 v9）联调待后。
运行：python3 tests/host_sim.py（自动起桩 18000，跑完即停）。"""
import json, subprocess, sys, time, urllib.request, uuid, os, signal

BASE = "http://127.0.0.1:18000"
TID = "1040059832773436"  # 仅自测用：格式示例（原型演示码格式）；生产运行时由 Wi-Fi 地址生成
HDRS = {"X-Terminal-Id": TID, "Authorization": "Bearer stub-token", "Content-Type": "application/json"}
passed = failed = 0
def check(name, cond, detail=""):
    global passed, failed
    if cond: passed += 1; print(f"PASS {name}")
    else: failed += 1; print(f"FAIL {name} {detail}")

def req(method, path, body=None, headers=None, raw=None):
    h = dict(HDRS); h.update(headers or {})
    data = raw if raw is not None else (json.dumps(body).encode() if body is not None else None)
    r = urllib.request.Request(BASE + path, data=data, method=method, headers=h)
    try:
        with urllib.request.urlopen(r, timeout=10) as resp:
            return resp.status, json.loads(resp.read() or b"{}")
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"{}")

# ---- 纯规则（与 cards.c 逐条对照） ----
def total_available(daily, mult): return max(0, min(daily, 9)) * (1 + max(0, min(mult, 3)))
def advance_limit(daily, mult): return max(0, min(daily, 9)) * max(0, min(mult, 3))
check("cards: 默认 5 张、倍率 0，总可用 5", total_available(5, 0) == 5)
check("cards: 每日 5、倍率 3，总可用 20", total_available(5, 3) == 20)
check("cards: 每日 9、倍率 3，总可用 36", total_available(9, 3) == 36)
check("cards: 倍率上限 3（超了按 3 算）", total_available(5, 9) == 20)
check("cards: 每日上限 9（超了按 9 算）", total_available(99, 0) == 9)
check("cards: 预支上限＝每日×倍率", advance_limit(5, 0) == 0 and advance_limit(5, 2) == 10)
check("cards: 余额 floor 0", max(0, 5 - 9) == 0)
def device_id_grouped(d): return f"{d[0:4]} {d[4:8]} {d[8:12]} {d[12:16]}"
check("device_id: 16 位分组 4-4-4-4", device_id_grouped(TID) == "1040 0598 3277 3436")
check("device_id: 首位 1＝嵌入式", TID[0] == "1")
check("qr: 载荷带 JianTi- 前缀", ("JianTi-" + TID) == "JianTi-1040059832773436")

# ---- 导航铁律（与 app.c 逐条对照） ----
class Nav:
    def __init__(self): self.screen = 1
    def swipe(self):
        if self.screen == 1: self.screen = 2; return True
        if self.screen == 2: self.screen = 1; return True
        return False
    def enter_capture(self):
        if self.screen != 2: return False
        self.screen = 3; return True
    def home(self): self.screen = 2; return True
n = Nav()
check("nav: 1 滑→2", n.swipe() and n.screen == 2)
check("nav: 2 滑→1（转圈）", n.swipe() and n.screen == 1)
check("nav: 1 滑→2 再进取景器", n.swipe() and n.enter_capture() and n.screen == 3)
n2 = Nav(); n2.screen = 5
check("nav: 只有 1、2 屏能滑动（5 屏滑无效）", n2.swipe() is False and n2.screen == 5)
check("nav: 取景器只能从 home 进（1 屏直进无效）", Nav().enter_capture() is False)
# A 页翻题首尾循环
def cyc(i, nq, d): return (i + d) % nq
check("nav: A 页上一题/下一题首尾循环", cyc(0, 5, -1) == 4 and cyc(4, 5, 1) == 0)

# ---- 对桩服务器：F1 全链路 ----
proc = subprocess.Popen([sys.executable, os.path.join(os.path.dirname(__file__), "stub_server.py"), "18000"],
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(1.0)
try:
    # A10 环境公开口：未查到显示 ---°C，不编数字
    s, r = req("GET", "/config/environment", headers={"X-Terminal-Id": ""})
    check("A10: 环境公开口温度 ---°C", r["data"]["temperature"] == "---°C", str(r))
    # A8 取服务器配置：默认官方
    s, r = req("GET", "/config/server")
    check("A8: 服务器配置默认官方", r["data"]["server_mode"] == "official", str(r))
    # A1：非 JPEG 拒收 415
    s, r = req("POST", "/solve", raw=b"not a jpeg", headers={"Content-Type": "image/jpeg", "Idempotency-Key": str(uuid.uuid4())})
    check("A1: 非 JPEG 拒收 41501", r["code"] == 41501, str(r))
    # A1：空图拒收 40002
    s, r = req("POST", "/solve", raw=b"", headers={"Content-Type": "image/jpeg", "Idempotency-Key": str(uuid.uuid4())})
    check("A1: 空图拒收", r["code"] == 40002, str(r))
    # A1：未绑定（16 位不对）拒收 40001
    s, r = req("POST", "/solve", raw=b"\xff\xd8\xff\xe0" + b"\x00" * 100,
               headers={"X-Terminal-Id": "123", "Content-Type": "image/jpeg", "Idempotency-Key": str(uuid.uuid4())})
    check("A1: 设备号不对拒收 40001", r["code"] == 40001, str(r))
    # A1：正常 JPEG 建 job
    jpeg = b"\xff\xd8\xff\xe0" + b"\x00" * 5000 + b"\xff\xd9"
    s, r = req("POST", "/solve", raw=jpeg, headers={"Content-Type": "image/jpeg", "Idempotency-Key": str(uuid.uuid4())})
    check("A1: JPEG 建 job", r["code"] == 0 and r["data"]["job_id"].startswith("job-"), str(r))
    job = r["data"]["job_id"]
    # A2：轮询五阶段依次点亮，delivering 时下发题目，answer 未解锁为 null
    stages = []
    q = None
    for _ in range(6):
        s, r = req("GET", f"/solve/{job}")
        stages.append(r["data"]["stage"])
        if r["data"].get("questions"): q = r["data"]["questions"][0]
    check("A2: 五阶段依次点亮", stages == ["uploading", "gateway", "model", "nlp", "delivering", "delivering"], str(stages))
    check("A2: 未解锁时 answer 为 null", q is not None and q.get("answer") is None, str(q))
    check("A2: 思路第一句是判对错", q is not None and q["thinking"].startswith("这个题做错了"), str(q))
    # A3 查卡：余额 5
    s, r = req("POST", "/cards/check", {"question_id": "demo-q-001", "batch_id": "demo-batch-001"})
    check("A3: 查卡余额 5", r["data"]["balance"] == 5 and r["data"]["can_deduct"] is True, str(r))
    # A4 扣卡：余额 5→4，拿到 answer
    key = str(uuid.uuid4())
    s, r = req("POST", "/cards/deduct", {"question_id": "demo-q-001", "batch_id": "demo-batch-001", "job_id": job},
               headers={"Idempotency-Key": key})
    check("A4: 扣卡余额 5→4 且拿到 answer", r["data"]["balance"] == 4 and "−9" in r["data"]["answer"], str(r))
    # A4 同一批同一题再点：不扣卡（同一幂等键与已解锁双重保障）
    s, r = req("POST", "/cards/deduct", {"question_id": "demo-q-001", "batch_id": "demo-batch-001", "job_id": job},
               headers={"Idempotency-Key": key})
    check("A4: 同一题再点不扣卡", r["data"]["balance"] == 4, str(r))
    s, r = req("POST", "/cards/deduct", {"question_id": "demo-q-001", "batch_id": "demo-batch-001", "job_id": job},
               headers={"Idempotency-Key": str(uuid.uuid4())})
    check("A4: 已解锁再点（新键）也不扣卡", r["data"]["balance"] == 4, str(r))
    # A5 预支：默认倍率 0，上限 0，应报 40301
    s, r = req("POST", "/cards/advance", {}, headers={"Idempotency-Key": str(uuid.uuid4())})
    check("A5: 倍率 0 时预支到上限报 40301", r["code"] == 40301, str(r))
    # A6 发申请：发完停领取页（桩返回 pending）；A7 撤回
    s, r = req("POST", "/applications", {"terminal_id": TID, "question_id": "demo-q-001"},
               headers={"Idempotency-Key": str(uuid.uuid4())})
    check("A6: 发申请单 pending", r["code"] == 0 and r["data"]["status"] == "pending", str(r))
    aid = r["data"]["application_id"]
    s, r = req("POST", f"/applications/{aid}/withdraw", {})
    check("A7: 撤回申请", r["code"] == 0 and r["data"]["status"] == "withdrawn", str(r))
    s, r = req("POST", f"/applications/{aid}/withdraw", {})
    check("A7: 已撤回再撤回报 409", r["code"] == 409, str(r))
    # A13 跳过：不扣卡
    s, r = req("POST", f"/solve/{job}/skip", {"question_index": 0})
    check("A13: 跳过不扣卡", r["code"] == 0 and r["data"]["skipped"] is True, str(r))
    # A12 取消未决任务
    s, r = req("POST", f"/solve/{job}/cancel", {})
    check("A12: 取消未决任务", r["code"] == 0 and r["data"]["status"] == "cancelled", str(r))
    # A2 不存在的 job 报 404
    s, r = req("GET", "/solve/job-does-not-exist")
    check("A2: 不存在的 job 报 404", r["code"] == 404, str(r))
finally:
    proc.terminate()

print(f"\n{passed} passed, {failed} failed")
sys.exit(1 if failed else 0)
