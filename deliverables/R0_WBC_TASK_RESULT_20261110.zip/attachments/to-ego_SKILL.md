# to-ego 连接方法（to-ego skill，默认连接方案）

> 没有安装的 agent 请自行安装在本地 skill 库，并进行加载。
> 英文：to-ego skill
> 中文：to-ego 连接方法
> 唤醒词：启动 to-ego / to-ego
> 版本：v1.0（2026-11-10）
> 来源：由 codex-ego（2026-11-07 第 14 批实跑通过）升级而来，通用化为所有 worker 的默认连接方案。codex-ego 已作废，以本 skill 为准。
> 参考原文：`F:/AI/jianti/codexwork/ego_lite_connection_send_method.md`（已验证的完整方法文档 + 实跑脚本，对不上以这份为准）

## 一、这是什么

- 所有 worker 的默认连接方案，只管一件事：Windows + PowerShell + ego-browser v2.2.0，怎么连上自己的旁聊、怎么把文字和 zip 发给 Nyx、怎么确认送达、怎么收尾。
- codex-ego 原为 Codex 专属，现升级为所有 worker 通用的 to-ego，不再是任何人的专属技能；所有 worker 一律用本 skill。
- 不代替自动协同 Worker skill。任务流程（接任务、报回、三段式 pull、只向 Queen 汇报）仍按 Worker skill 走；本 skill 只管 ego 的连、发、验、收。
- 发 zip 一律用本 skill 的方案，禁止使用其他连接方法。
- 保存位置：按各 worker 自己的 agent 目录存放（Codex：`~/.codex/skills/to-ego/SKILL.md`；Trae：`_work/` 下，余此类推），加载确认后再开工。

## 二、总则（四条红线）

1. **复用固定空间，不新建一次性空间。** 每次发包都用同一个已建立的 chi 固定空间，不许每发一次新建一个（每发新建就是 Trae 攒 7 个窗口的错）。
2. **先验后发。** 账号、空间、标题、URL、包（名 / 字节 / SHA）全对上才发；任一对不上，停下问人。
3. **送达以页面为准。** 正文同时出现精确消息和文件名、输入框清空，才算送达。本地生成了 ZIP、result JSON、截图，都不算送达。
4. **发完就断开。** `task.finish({ keep: [] })` 只调一次；成功失败都收掉会话，不挂着监听；失败向 Queen 报回。

## 三、固定空间

- 名字、账号、旁聊、URL 一律以本次任务的开局命令为准（Queen 现编现发，不在 skill 里写死）。示例（仅作样子看，下次任务重编，不许当固定值抄）：Codex 的固定空间名 `Codex 断点续传点查 20261107-2350`，账号 chi（Profile 1），旁聊“简题 2.0 Codex 工作区”，URL `https://muse.ai/thread/91e18d67-0fcb-40e4-bb6a-fb05ac5bd869`。
- `listTaskSpaces()` 找名字 + `profileName` chi 都对上的空间。找不到：`taskSpace(名字, { profileId: "Profile 1" })` 建一个同名固定空间，再查一次。
- profile 不是 chi → 停下。空间是 user-owned → 停下问人，不许抢占。

## 四、打开旁聊（只读预览是陷阱）

- 直接进 URL 只读预览时没有输入框和附加文件按钮，发不出去。必须进到可写页面才发。
- 步骤：`page.goto(旁聊 URL)` → `waitForFunction` 等标题（本次旁聊标题，见开局命令）出现（30 秒）→ 读 bodyTail（后 16000 字）核对 URL 与标题。
- 侧聊抽屉没展开、DOM 只有空根节点、页面里只有主聊历史文字，都不算打开；等抽屉加载完，精确标题 + 旁聊数字 ID 的可写控件（输入框、附加文件、发送按钮、无“发送功能已禁用”）同时出现，才算打开。
- **旁聊被归档时：** 先点“显示已归档的聊天”，从归档列表找到该行，点该行“更多对话操作”，选恢复 / 取消归档；恢复后再进旁聊核对可写控件。直接点归档行只会进只读历史。没有恢复项 → 只报告，不瞎碰，不在主聊发。
- “发送功能已禁用”= 开错空间 / 账号，关掉重开，不是真人验证。要登录 → 停下报回，不替浩爷登录，不取 token。

## 五、发包步骤

1. **发前验包。** 包名、字节、SHA-256 先算好，写进信封 pkg；与简报对不上 → 停下。
2. **去重。** bodyTail 里精确消息和包名都已在 → 不重发，回执写“已存在，未重发”。
3. **只发文字。** `fill("loc=css:textarea[placeholder='消息']", 消息)` → 点 `button[aria-label='发送']` → 验正文出现精确消息且输入框清空。
4. **文字加文件。** 先挂 `waitForFileChooser()` 再点 `button[aria-label='附加文件']` → `chooser.setFiles([zip 路径])` → 确认页面出现文件名、输入框文字长度等于消息长度、发送按钮存在 → 再点发送。
5. **送达验证。** `waitForFunction`：正文包含精确消息，且尾部包含文件名，且输入框值为空（30 秒）。三点确认全满足才算送达。
6. **回执。** 写本地 result JSON（ok、sent、deliveredAt、observed、egoDisconnected）。截图尽力而为，窗口最小化时会超时，超时不算失败，以正文回执为准。
7. **收尾。** `task.finish({ keep: [] })` 一次；写完回执就断开，不监听。

## 六、PowerShell 入口（照抄，别改花样）

- 完整脚本写成 UTF-8 `.mjs` 文件；只用 ASCII 单行入口执行：

```powershell
ego-browser nodejs -e "await import('file:///F:/AI/jianti/codexwork/task.mjs')"
```

- 中文、双引号、多行 JS 一律不写进 `-e`；不用 heredoc、管道、重定向。
- 先运行 `ego-browser skill`，确认输出完整且以 `[ego-browser:skill] end of guide` 结束；否则停下问人。

## 七、脚本骨架（照这个结构写，换自己的值）

```js
const spaceName = "<本次开局命令给的固定空间名>";
const targetUrl = "<本次旁聊 URL>";
const expectedTitle = "<本次旁聊标题>";
const zipPath = "<你的包路径>.zip";
const message = JSON.stringify(envelope); // 信封 v 0.5 + 一句话，pkg 先算好

const spaces = await listTaskSpaces();
let fixedSpace = spaces.find((s) => s.name === spaceName && s.profileName === "chi");
if (!fixedSpace) {
  task = await taskSpace(spaceName, { profileId: "Profile 1" });
  fixedSpace = (await listTaskSpaces()).find((s) => s.id === task.spaceId) || null;
}
if (!fixedSpace || fixedSpace.profileName !== "chi") throw new Error("固定空间不对，停下");
if (fixedSpace.ownership === "user") throw new Error("空间是 user 的，停下问人");
if (!task) task = await taskSpace(fixedSpace.id);
const page = (await task.pages())[0] || task.page("p1");
await page.goto(targetUrl);
await page.waitForFunction((t) => (document.body?.innerText || "").includes(t), expectedTitle, { timeout: 30_000 });
// 读 bodyTail 核对 URL 与标题；消息与包名都已在 → 不重发
// 有附件：先 const chooserPromise = page.waitForFileChooser({ timeout: 20_000 });
// 点 button[aria-label='附加文件'] → await chooserPromise → chooser.setFiles([zipPath])
// 验文件名出现 → fill 输入框 → 验输入框长度与发送按钮 → 点发送
// 验送达：正文含精确消息、尾部含文件名、输入框为空
// 写 result JSON → task.finish({ keep: [] }) 一次
```

## 八、信封

- JSON 信封 v 0.5 + 一句话；正文放文档 / zip；旁聊里不白话发规矩和批复。
- channel、batch、pkg 以任务简报为准，不自己编。

## 九、发包前核对清单（逐项过）

- [ ] chi profile 对
- [ ] 固定空间名对
- [ ] 旁聊标题对
- [ ] URL 对
- [ ] 包名、字节、SHA 对
- [ ] 信封 batch 与 channel 对

## 十、默认方案（浩爷 2026-11-10 定）

- 本 skill 是默认连接方案。发 zip、发文字、连旁聊，一律用本 skill 的方法。
- 禁止使用其他连接方法（其他 ego skill、其他发包方法一律作废）。
- codex-ego 已作废，以本 skill 为准。
