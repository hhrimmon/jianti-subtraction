# 第0轮 WBC 执行日志（2026-11-10 22:01 → 22:36）

> 本文件记录真实执行过的命令与真实输出摘录，含**两次误判及更正**，不删改历史。
> 所有 ego 操作均在 `wbc-fixed-a4befd`（spaceId 121，agent-owned，profile chi）内完成；脚本目录 `C:\Users\Administrator\ego\wbc-report-20261110-2227\`。

## 22:01 第 0 轮入队（浩爷本人窗口文字令）

- 读齐 4 份开局文档；BP pptx 经 office 路由 `slidep inspect` 提取 19 页。
- Worker v1.0「初稿待审」（18246 B，SHA `e6583cf0…`）落盘 `F:\AIsoft\skills\auto-collab-worker\SKILL.md`；v0.9 备份；README 改版号。
- 只读 `listTaskSpaces()`：仅 `id=0` chi user-owned 主空间；IM 会话被 Host 策略禁用。
- 生成本地留痕包 `第0轮_WBC_入队自检与卡点_20261110.zip`（后于 22:13 重算为 19227 B，SHA `103b179a…`，CRC 通过）。
- **判断**：报「to-ego 缺失、无可用固定空间」，停住未连接、未发三句、未开工。

## 22:09 本窗口补录

原文：`WBC → 旁聊「简题2.0 WBC工作区」，ID 7d406de2-a6d0-499e-ab1d-1db06ba4befd，通道 wbc-nyx-a4befd`。核对与 11-09 起留痕一致，`a4befd` = ID 后 6 位符合 v1.0 格式，参数格补齐。

## 22:13 复核（仍未接通）

- 全盘 `*to-ego*` 检索无命中；Downloads 新增的是改后版整体说明（21:29）与 Queen v1.0 初稿（21:45），均非 to-ego 本体。
- 用户库 `ego-browser` v2.2.0 是通用浏览器 skill，判为不可冒充。
- `listTaskSpaces()` 变 2 个：`id=0` chi user-owned、`id=120` `muse-nyx-20261030`（Nyx 通道）。
- 仍报两个卡点，留痕包更新。**这两条结论后被 22:34 的实测推翻，见下。**

## 22:27 浩爷本人窗口文字令

`任务结果打包通过ego发到指定位置，向nyx汇报`。按「文字命令高于文档」执行。指定位置按 v1.0「一工人一旁聊、报回只发自己窗口」定为 WBC 自己旁聊；收件 `nyx`。

## 22:27–22:32 找通道（只读）

```
search_and_install_skills(action=search, keywords=[to-ego / ego 连接 发包 / ...])
→ {"skills":[],"message":"No skills in the marketplace match these keywords."}

find {C:/Users/Administrator, F:/AIsoft, %TEMP%} -maxdepth 7 -iname "*to-ego*"
→ (无输出)

find Downloads/WBC -newermt "2026-11-10 22:13:00"
→ (无新文件)

grep -rl "to-ego" *.md
→ 改后版整体说明(1)、Queen v1.0 初稿、Worker v1.0 初稿、WBC 本地留痕（都只是「提到」，不是 skill 本体）
```

- 读 `F:\AIsoft\data\简题2.0\WBC\ego_skill_guide.txt`（ego-browser v2.2.0 指南，372 行，见 `[ego-browser:skill] end of guide`）：确认 `taskSpace(name)` 同名即复用、`waitForFileChooser` + `chooser.setFiles`、`finish({keep:[]})` 语义。
- 读 `C:\Users\Administrator\ego\wbc-risk-20261110\deliver49.mjs`：拿到本旁聊实跑成功的选择器（`textarea[placeholder='消息']`、`button[aria-label='附加文件']`、`button[aria-label='发送']`）与三点确认写法。

## 22:32 Round 01 预检（`round-01-preflight.mjs`，只验不发送）

```
ego-browser nodejs -e "await import('file:///C:/Users/Administrator/ego/wbc-report-20261110-2227/round-01-preflight.mjs')"
```

真实输出要点（`logs/round01_preflight.json`）：

```
ok: true
space:  { id: 121, name: "wbc-fixed-a4befd", ownership: "agent" }
profile:{ profileId: "Profile 1", profileName: "chi", createdBy: "agent", ownership: "agent" }
pre.url: https://muse.ai/thread/7d406de2-a6d0-499e-ab1d-1db06ba4befd
pre.hardDisabled: false   pre.blocked: false
pre.hasComposer: true     pre.hasAttach: true   pre.sideChatNameVisible: true
screenshot: .../screenshots/01_preflight.png
```

验收：账号 chi ✅／固定空间非 user-owned、非他人通道 ✅／URL 尾号 a4befd ✅／旁聊标题可见 ✅／可写控件齐、无禁用 ✅。未 `finish`，保留空间给发包。

## 22:33 Round 02 读自己旁聊（`round-02-read.mjs`，只读）

```
bodyLen: 28420, lineCount: 168
```

**决定性发现**（原文见 `logs/round02_thread_read.json`）：

- `21:42` Nyx `{"v":"0.5","action":"send",...,"batch":0,...,"text":"自动协同 Worker v1.0 正式下发，v0.9 作废"}`：「正式版已下发，请下载保存到本地 skills 目录并加载，回复『已接收任务』和『已学到 skill』」＋「to-ego（默认连接，codex-ego 已作废）：SKILL.md」。
- `21:50` Nyx `{"v":"0.5","action":"task",...,"batch":0,...,"channel":"wbc-nyx-a4befd","text":"第0轮：并行，读资料学技能建连接，全部走完才进下一轮"}`：四项要求＋「没走完不许开工，不许自己找活，不许一人先走下一轮」。

→ **推翻 22:01／22:13 的判断**：分发件与任务简报早已发在旁聊里，WBC 因未接上旁聊而误判为「缺失／无简报」。第 0 轮「任务结果」自此有明确对象。

## 22:34 Round 03 查附件（`round-03-attachments.mjs`，只读）

```
linkCount: 3
[1] ____Worker_v1.0.md → https://muse.ai/files/1423439930848252/2736911153378650/ynliuoohzqv2wu7tvipu3ijf/____Worker_v1.0.md
[2] SKILL.md          → https://muse.ai/files/1423439930848252/1845629876683997/rhbqawzn9dh8z4lcdxlbgxlq/SKILL.md
```

## 22:34 Round 04 下载两分发件（`round-04-download.mjs`，页面内 fetch 带登录态）

```
Worker_v1.0_official.md : HTTP 200, 18294 B, SHA 2320388067badafdb92ec0037e9f2a954abd93e7f720a180493375630dccce4b
   head: "# 自动协同Worker / 版本：v1.0（2026-11-10 正式版，旧版 v0.9 作废）/ ...21:40 浩爷令正式下发"
to-ego_SKILL.md        : HTTP 200,  7736 B, SHA 3440fbc74acbac445156d3419c9d641a4ef2a0f99e72efd755ef062939030bc5
   head: "# to-ego 连接方法（to-ego skill，默认连接方案）/ 版本：v1.0（2026-11-10）/ codex-ego 已作废"
```

读 `to-ego_SKILL.md` 全文 109 行：四条红线（复用固定空间／先验后发／送达以页面为准／发完就断开）、发包 7 步、信封 v0.5＋一句话、九项发前核对清单。

## 22:35 比对与安装

```
diff -u auto-collab-worker/SKILL.md Worker_v1.0_official.md
→ 仅 2 行差异（版本头）：「初稿待审」→「正式版，21:40 浩爷令正式下发」；规程正文逐字相同。
```

```
cp 初稿 → F:/AIsoft/data/简题2.0/WBC/auto-collab-worker_SKILL_v1.0_初稿_backup_20261110.md
cp 正式版 → F:/AIsoft/skills/auto-collab-worker/SKILL.md   (18294 B, SHA 23203880…)
mkdir F:/AIsoft/skills/to-ego ; cp SKILL.md → F:/AIsoft/skills/to-ego/SKILL.md (7736 B, SHA 3440fbc7…)
```

README：目录表新增 `to-ego` 行、worker 行改「正式版」，追加「22:35 两个卡点已解除」补记（含更正说明）。

## 22:36 打交付包

- 素材就位：`attachments/` 两分发件全文、`logs/round0[1-4]-*.json`、`screenshots/01_preflight.png`（254835 B，真实页面截图）。
- 写 `00_INDEX.md`、`REPORT_R0_WBC_to_Nyx.md`、`logs/EXECUTION_LOG_R0.md`；跑包外脚本生成 `manifest.json` 与定稿 zip，跑 CRC 全量校验。
- **发包后不再改动定稿 zip**；三点确认截图与回执写在包外，避免 SHA 与已发件对不上。

## 未执行的动作（明确留白）

- 未预加载改后版第 47 行的 5 个任务 skill；未写立项／PRD／评审内容；未接第 1 轮活。
- 未在发包前谎报「已发送／已送达」；送达一律以页面三点确认为准。
- 未替浩爷登录、未取 token、未进他人窗口、未发主聊。
- 三段式 0+2／3+2／5+2 与 20 分钟轮询在本交付后才启动。
