"""server_config.py — 服务端配置常量（平台服务器端 v1，Python 3 标准库 only）.

相对探针骨架的改动（手册 v2 §2.3、§6.1，接口文档）：
- 预支倍率默认值 1 -> 0（定稿，2026-11-16；原型 1 只是演示值）。
- 五阶段名按接口文档 A2 的已定口径：uploading／gateway／model／nlp／
  delivering（骨架的 upload／deliver 已改名）。
- 轮询约定：1 秒一次、最多 60 秒、超时 50401（已定，接口 A2）。
- 限流数值仍是骨架自定占位（通用 120／分钟、/solve 每终端 10／分钟），
  见 ASSUMPTIONS.md V1-A12；定稿值未定，不悄悄定死。
演示值（原型里的 12345678、演示余额、充值档位等）一律不在这里出现。
"""
from __future__ import annotations

# ---- 网关 ----
GATEWAY_PORT = 8000
GATEWAY_HOST = "127.0.0.1"  # 默认只绑本机；部署时由启动参数改，不改代码

# 官方服务器地址：PRD 5.1，写死，板上不显示。
OFFICIAL_SERVER_HOST = "solve.mhq-ai.xyz"
OFFICIAL_SERVER_URL = "https://solve.mhq-ai.xyz"

# ---- /solve 上传 ----
MAX_UPLOAD_BYTES = 8 * 1024 * 1024  # 8MB，2026-11-08 由 2MB 改到 8MB
JPEG_MAGIC = b"\xff\xd8\xff"

# ---- 解题卡（PRD 第 4 章）----
DAILY_CARDS_DEFAULT = 5
DAILY_CARDS_MAX = 9
ADVANCE_RATIO_DEFAULT = 0   # 定稿默认 0（手册 §2.3；骨架取原型值 1 已改）
ADVANCE_RATIO_MAX = 3
ADVANCE_PER_TIME = 1        # 预支每次 1 张

# ---- 账号 / 家庭组 / 管理密码 ----
FAMILY_ID_LENGTH = 8        # 8 位纯数字，服务端生成，终身不变
ADMIN_PASSWORD_LENGTH = 6   # 6 位数字
INVITE_CODE_LENGTH = 6      # 6 位邀请码

# ---- 设备 ID（PRD 5.3）----
DEVICE_ID_LENGTH = 16       # 1 位类型码 + 15 位设备号，纯数字
# 类型码：1 嵌入式、2 安卓、3 苹果、4 鸿蒙、0 其他/未知，5-9 预留
DEVICE_TYPE_NAMES = {
    "0": "其他/未知", "1": "嵌入式", "2": "安卓", "3": "苹果", "4": "鸿蒙",
    "5": "预留", "6": "预留", "7": "预留", "8": "预留", "9": "预留",
}

# ---- 模型管理（PRD 3.8）：官方 5 个模型，JT Lite 2.0 默认 ----
OFFICIAL_MODELS = [
    {"id": "jt-lite-2.0", "name": "JT Lite 2.0", "default": True},
    {"id": "deepseek-v4.1-flash", "name": "DeepSeek-V4.1-Flash", "default": False},
    {"id": "qwen-3.8", "name": "Qwen 3.8", "default": False},
    {"id": "doubao-seed-2.1-turbo", "name": "豆包 Seed-2.1-Turbo", "default": False},
    {"id": "kimi-k3.1-pro", "name": "Kimi-K3.1-Pro", "default": False},
]
DEFAULT_MODEL_ID = "jt-lite-2.0"

# ---- 处理五阶段（接口 A2 已定口径）----
SOLVE_STAGES = ["uploading", "gateway", "model", "nlp", "delivering"]
SOLVE_STAGE_NAMES = {
    "uploading": "上传", "gateway": "网关", "model": "大模型",
    "nlp": "NLP", "delivering": "下发",
}
POLL_INTERVAL_SECONDS = 1   # 终端轮询间隔 1 秒一次
POLL_TIMEOUT_SECONDS = 60   # 最多 60 秒，超时按 50401 处理（客户端判定）
POLL_TIMEOUT_CODE = "50401"

# ---- 限流（骨架自定占位，见 ASSUMPTIONS.md V1-A12）----
RATE_LIMIT_GENERAL_PER_MIN = 120   # 每 IP 每分钟通用上限
RATE_LIMIT_SOLVE_PER_MIN = 10      # 每终端每分钟 /solve 上限
RATE_LIMIT_WINDOW_SECONDS = 60

# ---- 温度 / MEMO：无数据时的返回值，绝不编数字 ----
TEMPERATURE_UNKNOWN = "---°C"
MEMO_EMPTY = ""

# ---- 其它 v1 自定上限（见 ASSUMPTIONS.md）----
GRANT_COUNT_MAX = 9        # 按张批准的单次上限（由每日张数最大 9 推导）
GRANT_RATIO_MAX = 3        # 按倍批准的倍率上限（与预支倍率同口径）
MEMO_MAX_LENGTH = 200      # MEMO 一句话最长 200 字
INVITE_TEXT_DOWNLOAD_URL = ""  # 邀请话里的下载地址：原型占位地址，未定；v1 留空，不编
