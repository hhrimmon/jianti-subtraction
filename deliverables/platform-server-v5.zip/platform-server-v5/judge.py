"""judge.py — Qwen 客户端 + stub（标准库 urllib，平台服务器端 v1）.

规则（手册 v2 §2.1、§4.1，任务书）：
- Qwen 是主链路；API Key 只从环境变量 QWEN_API_KEY 读，绝不写进代码、
  文档、日志、报错返回。
- 没有 Key -> stub 模式：返回明确的“模型未接通”错误，绝不编假答案、
  绝不编对错/思路/答案。调用方（gateway）据此把 job 置为 failed。
- 有 Key -> 调 DashScope OpenAI 兼容接口做一次图文判题；调不通也如实
  返回失败，不编答案。模型名到 API model id 的映射仍是骨架自定
  （N1 已定：部署时再定，开发阶段留空，不追这条），见 ASSUMPTIONS.md V1-A1。
"""
from __future__ import annotations

import base64
import json
import os
import urllib.error
import urllib.request

MODEL_NOT_CONNECTED = {
    "code": "model_not_connected",
    "message": "模型未接通：未配置 QWEN_API_KEY，判题服务不可用，未生成任何答案。",
}

# 产品模型名 -> DashScope 兼容接口 model id（骨架自定映射，见 ASSUMPTIONS.md N1）。
# JT Lite 2.0 是官方默认模型，但其 API id 未在 PRD/原型中给出，这里按
# “默认走 Qwen 视觉模型”映射；Nyx/浩爷定下真实 id 后只改这一张表。
API_MODEL_MAP = {
    "jt-lite-2.0": "qwen-vl-max",
    "deepseek-v4.1-flash": "deepseek-v4.1-flash",  # 非 Qwen 系：经 Qwen 兼容通道不一定能调通
    "qwen-3.8": "qwen-vl-plus",
    "doubao-seed-2.1-turbo": "doubao-seed-2.1-turbo",
    "kimi-k3.1-pro": "kimi-k3.1-pro",
}
DASH_SCOPE_URL = "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions"

JUDGE_PROMPT = (
    "你是小学数学批改老师。看这张作业照片，照片里有几道题就判几道，"
    "只判最终结果，不判过程。按 JSON 输出，不要输出其他文字："
    '{"results": [{"correct": true/false, "thinking": "分步思路，'
    '每步写算什么、算出什么，最后一步停在还差最后一下的地方，不给答案", '
    '"answer": "完整计算过程，一条等号链算到答案"}]}'
    "如果照片里没有可判的数学题，输出 {\"results\": []}。不要编造题目。"
)


class ModelNotConnectedError(Exception):
    def __init__(self):
        super().__init__(MODEL_NOT_CONNECTED["message"])
        self.payload = MODEL_NOT_CONNECTED


class JudgeError(Exception):
    def __init__(self, message: str):
        super().__init__(message)
        self.payload = {"code": "judge_failed", "message": message}


def qwen_api_key() -> str | None:
    return os.environ.get("QWEN_API_KEY") or None


def is_connected() -> bool:
    return bool(qwen_api_key())


def judge_image(image_bytes: bytes, model_id: str = "jt-lite-2.0",
                timeout: int = 60) -> dict:
    """一次输入一张照片，一次输出对错+思路+答案（结构见 JUDGE_PROMPT）。

    返回 {"results": [{"correct": bool|None, "thinking": str, "answer": str}]}。
    无 Key 时 raise ModelNotConnectedError；调用失败 raise JudgeError。
    任何失败路径都不返回编造的判题结果。
    """
    key = qwen_api_key()
    if not key:
        raise ModelNotConnectedError()
    api_model = API_MODEL_MAP.get(model_id, "qwen-vl-max")
    b64 = base64.b64encode(image_bytes).decode("ascii")
    body = {
        "model": api_model,
        "messages": [{
            "role": "user",
            "content": [
                {"type": "image_url",
                 "image_url": {"url": f"data:image/jpeg;base64,{b64}"}},
                {"type": "text", "text": JUDGE_PROMPT},
            ],
        }],
        "temperature": 0,
    }
    req = urllib.request.Request(
        DASH_SCOPE_URL,
        data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type": "application/json",
                 "Authorization": f"Bearer {key}"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        raise JudgeError(f"模型服务返回 HTTP {e.code}，判题未完成。")
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        raise JudgeError(f"模型服务连接失败（{e}），判题未完成。")
    try:
        text = payload["choices"][0]["message"]["content"]
        parsed = json.loads(text)
        results = parsed.get("results", [])
        if not isinstance(results, list):
            raise ValueError("results 不是列表")
    except (KeyError, IndexError, ValueError, TypeError, json.JSONDecodeError):
        raise JudgeError("模型返回无法解析为判题结果，判题未完成。")
    return {"results": results, "raw_text": text}
