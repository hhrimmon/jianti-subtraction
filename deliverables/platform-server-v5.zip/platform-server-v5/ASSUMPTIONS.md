# 假设清单（ASSUMPTIONS）— 服务器端 v5 自己定的每一处

> 规则：接口没定的（对齐文档 M13 清单、接口文档附录 A）按最合理的方式写，逐条标出来，不悄悄定死。
> 每条格式：是什么 / 为什么这样定 / 对应哪个未定项。
> 底本是骨架 `platform-skeleton/ASSUMPTIONS.md` 的 28 条（§0 N1–N5、A1–A23）；本版先写“骨架那套在本版的状态”（§1–§2），再写 v1 新增的自定项（§3，V1-A1 起）、v2 新增（§4，V2-A1 起）、v3 新增（§5，V3-A1 起）、v4 新增（§6，V4-A1 起）、v5 新增（§7，V5-A1 起）。
> 未定项现状（接口文档附录 A）：仍未定 8 项——U1、U8、U13、U14、U15、U18、U21、U22（另 B14 验证码有效期未定）；标未定的接口 7 个——A1、A2、A10、B5、B8、B9、B14。

## §0 本版相对骨架改了什么（最先看）

| 改动 | 骨架 | v1 | 依据 |
|---|---|---|---|
| 预支倍率默认值 | 1（取原型值） | **0** | 手册 §2.3 定稿默认 0；接口 U11 已定 |
| 快照 | 单文件 `snapshot.json`；损坏静默按空库启动 | **15 个分实体文件**；损坏启动失败，退出码 2 | 缺啥清单第 25 条（骨架已知局限）已修 |
| 服务器配置／模型选择 | 全局单份 | **按家庭组分** | 缺啥清单第 26 条已修 |
| 申请单幂等 | 无，重发重复建单 | **支持 `Idempotency-Key` 重发去重** | 缺啥清单第 27 条已修 |
| 家庭组成员加入 | 只有邀请码生成，无加入接口 | **加入／审批／转让／删除已实现**；首个新成员加入翻固化 | N4 定稿落地 |
| MCP 登录 | 501 stub，不校验 | **真校验**（见 V1-A2） | U9 已定（Nyx 筛查，浩爷认过） |
| `/solve` 快照失败 | 判题线程在 `save()` 之后起，`save()` 失败则 job 永远卡 processing | **先起线程再写快照**（见 V1-A3） | v1 验证时发现的真 bug，已修并复测 |

### v2 相对 v1 改了什么（Nyx 2026-11-16 裁决，房间消息 id 152/153/158）

| 改动 | v1 | v2 | 依据 |
|---|---|---|---|
| `/solve` 同键并发重复建 job | 幂等预检在锁外，读体之后才进锁建 job；10 路同键并发建出 10 个 job | **查幂等→建 job→写记录整段进 `store.lock`，判题线程锁内起；10 路同键并发只建 1 个 job**（`tests/conc_probe.py`，v1 副本对照复现过 10 个 job） | Nyx 裁决第 5 条；见 V2-A1、TESTLOG.md §6 |
| 其余幂等口预检位置 | `/cards/deduct`、`/cards/advance`、`POST /applications`、approve、reject 的预检都在锁外 | **预检→业务→写记录同锁内完成**（`store.lock` 是 RLock，业务函数内部再加锁不死锁；请求体在锁外读、响应在锁外发） | Nyx 裁决第 5 条；见 V2-A1 |
| 无题错误码 | `error.code` 与 `solve_failed` 记录里的 `error` 是 `no_question_detected` | **两处都改成 `no_question`**，旧名彻底清掉（`failure_reason` 本来就是 `no_question`，不动） | Nyx 裁决第 4 条；见 V2-A2、TESTLOG.md §7 |
| 冒烟含中文的 `-d` 请求体 | `MEMO` 设置用 `curl -d '{"memo":"今天也要加油。"}'` 行内传 | **改写文件再 `--data-binary @file`**（Windows GBK 下行内中文会被转码；dsh 在 Windows 上验 v1 冒烟 184/2，两项失败就是这个原因） | Nyx 裁决第 6 条（Nyx 146 定）；见 V2-A3 |

### v3 相对 v2 改了什么（Nyx 2026-11-17 裁决，房间消息 id 170/174）

| 改动 | v2 | v3 | 依据 |
|---|---|---|---|
| 429 响应头 | 429 只回错误体，无 `Retry-After` 头 | **429 响应带 `Retry-After: 5`**（只对 429 生效，其它状态码不带；接口文档“无该头时等 5 秒”的兜底句留着，不改文档） | Nyx 裁决，RECHECK #10；见 V3-A1、TESTLOG.md §9 |
| A10／锁屏口鉴权 | `GET /config/environment` 与 `GET /lockscreen` 代码上已不需鉴权，但接口文档 A10 请求头行仍写 `Authorization: Bearer` | **文档标“公开口，不需鉴权”**（锁屏前展示口，温度／MEMO 未登录也要显示）；`POST /config/environment/memo` 仍须管理员会话；代码不动 | Nyx 裁决，RECHECK #14；接口文档 A10 已改 |
| 僵尸 job 启动扫尾 | 重启后 processing 超时的 job 永远卡着（v1 快照写失败卡 job 已修，但重启丢线程的场景没扫尾） | **启动时扫一遍 jobs：processing 且 created_at 超 120 秒（2×POLL_TIMEOUT）标 failed，新 failure_reason `process_interrupted`，并补一条终态 usage 记录** | Nyx 裁决，RECHECK #15；见 V3-A2、TESTLOG.md §10 |
| README §4 快照清单 | 写着旧名 `cards.json`／`terminals.json`／`jobs.json`／`records.json`，漏了 `invites.json` | **按 `store.py` 的磁盘实际名字改对**（15 个：`devices.json`、`card_ledgers.json`、`card_transactions.json`、`solve_sessions.json`、`usage_records.json`、`invites.json` 等） | dsh 175d；见 V3-A3 |

### v4 相对 v3 改了什么（Nyx 2026-11-17 裁决，房间消息 id 284/285/232）

| 改动 | v3 | v4 | 依据 |
|---|---|---|---|
| 扫码绑字段 | `POST /terminals/bind-scan` 只读 `scan_payload`；文档 B5 要 `qr_payload`、App 发 `qr_payload`，服务端收到空串报 422 | **`scan_payload` 或 `qr_payload` 都认**（任一有值即用；两者都空仍传空串，`parse_scan_payload` 照旧 422 `scan_no_data`；解析与校验逻辑不动） | Nyx 裁决，房间消息 id 284/285；见 V4-A1、TESTLOG.md §13 |
| README 限流表变量名 | 限流表写 `JIANTI_RATE_LIMIT_GENERAL`／`JIANTI_RATE_LIMIT_SOLVE`，缺 `_PER_MIN` 后缀 | **补 `_PER_MIN` 后缀**，与代码读的环境变量名一致；代码不动 | Nyx 232 定法②；见 V4-A2 |

### v5 相对 v4 改了什么（Nyx 2026-11-17 裁决，房间消息 id 329）

| 改动 | v4 | v5 | 依据 |
|---|---|---|---|
| keep-alive 报错排空 | 鉴权 401/403 在 `_read_json()` 之前抛错，请求体残留 socket，同一连接下一请求解析失败（实测 400，trae 报 v3 上 501） | **异常出口发错误响应前按 Content-Length 排空未读 body**（`_drain_body`；`_read_json()` 与 `/solve` 记已读字节数，已读完不重排；`/solve` 图片不预读） | Nyx 裁决，房间消息 id 329 定法②；见 V5-A1、TESTLOG.md §14 |

---

## §1 N1–N5 在 v1 的状态

### N1. Qwen 真实调用方式与模型 id 映射——仍未定（部署时定），stub 留着
- **是什么**：`judge.py` 的映射表与 endpoint 仍是骨架那套猜测（JT Lite 2.0 → `qwen-vl-max`、Qwen 3.8 → `qwen-vl-plus`，其余照名字直填；endpoint `https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions`；prompt 要求模型输出 `{"results": [...]}` JSON）。无 `QWEN_API_KEY` 时 F1 停在“大模型”阶段，返回 `model_not_connected`，不编假答案。
- **为什么**：浩爷 2026-11-16 已定：部署时再说，现在不用管，stub 留着，别追这条。
- **对应**：U1、C1。v1 未动这条；接通后须重测 F1 全链（见 TESTLOG.md §5）。

### N2. 申请卡的包形式与批卡回传通道——已定：全部拉取，v1 未动
- **是什么**：批准发卡是数据包（服务端记账＋终端下次调 A3 查卡同步余额）；申请通知是消息记录＋拉取（`GET /push/pending`，原名“推送 stub”已按 6 修复版改名为“待拉取通知队列”）。
- **对应**：U3、U7。v1 未动。

### N3. 处理五阶段真实进度推送——已定：轮询，v1 未动
- **是什么**：不建推送通道。`POST /solve` 异步建 job（202），五阶段状态在 job 里（`stage`／`stage_index`）；终端轮询 `GET /solve/{job_id}`，1 秒一次、最多 60 秒，超时 50401；五阶段名 `uploading`／`gateway`／`model`／`nlp`／`delivering` 已定。
- **对应**：U2。v1 未动；50401 语义已实测（TESTLOG.md §4）：服务端不在 60 秒时杀 job。

### N4. 家庭组建立方式与注册成功下一步——已定，v1 已落地加入流程
- **是什么**：注册时即建**虚拟**家庭组（`status: "virtual"`，ID 服务端生成 8 位纯数字）；首个新成员正式加入时翻为已固化（`status: "solidified"`）、ID 不变；一个人先注册就能直接拍题、绑终端、用卡；先注册的人默认管理员。注册／登录成功后返回 `next_step: "verify_admin_password"`，再输一次管理密码进管理（按原型 v155 原样，U17 已定）。
- **v1 落地**：成员加入／审批／转让／删除已实现（`families.py`，见 V1-A8、V1-A9）；翻固化点在 `approve_member()`，骨架留的“待加入接口实现时接上”已接上。冒烟 §20（26 项）覆盖。
- **对应**：U12。

### N5. 16 位设备 ID 的生成办法——已定，v1 只做校验＋唯一性，未动
- **是什么**：服务端不生成 ID、不做 MAC／标识哈希；只校验（16 位纯数字、首位类型码只认 0–4，5–9 预留号拒 400）＋唯一性（重复直接 409）；扫码绑定接受纯 16 位数字与 `JianTi-<16 位>` 两种载荷，手动绑与扫码绑都容忍空格（先去空格再校验／解析）。
- **对应**：U10。生成办法（MAC 转换／本地稳定哈希）是终端侧的事，服务端不管。

---

## §2 骨架 A1–A23 在 v1 的状态

- **A1 预支倍率默认值——已改：0。** 骨架取原型值 1；v1 按手册 §2.3 定稿取 0（接口 U11 已定：倍率只取整数，不许小数）。`server_config.py`：`ADVANCE_RATIO_DEFAULT = 0`。
- **A2 改每日张数后今日剩余的算法——未动。** `今日剩余 = 新每日张数 − 今日已用 + 今日已预支 + 今日已批`，下限 0。8000 走链实测：倍率 1 时预支后余额 6，倍率改回 0 后余额回到 5。
- **A3 批准“按倍”的发卡数——未动。** 每日张数 × 倍数值。
- **A4 预支／批卡跨天不抵扣——未动。** 次日按新每日张数重置，`advanced_today`／`granted_today` 清零。
- **A5 `/solve` 的请求／响应字段——未动。** raw JPEG body，头 `X-Terminal-Id`＋`Authorization: Bearer`；响应 job 含 `questions[]`，答案默认不出现，只有解锁的题才在 `questions[i].answer` 里出现。对应 U1（仍未定：`job_id`／`batch_id` 格式、模型输入输出字段）。
- **A6 判题失败与识别失败的落点——未动，补了终端侧映射。** 模型未接通／调用失败／返回无法解析时 job 为 `failed`（`model_not_connected`／`judge_failed`），不编思路／答案；无可判数学题时 `no_question`。6 个新错误码（手册 v2 §2.5）是终端侧落点，不在 v1 代码里；服务端的对应责任是快速失败、原子且幂等（见 TESTLOG.md §2）。
- **A7 空白题不直达答案——未动。** 服务端不单独判断空白题；模型 prompt 要求“只判最终结果”，空白卷无最终结果可判时模型应返回空 `results` → 走 `no_question`。判定口径仍未定（见缺啥清单）。
- **A8 申请单字段与状态机——未动，加了幂等。** `{id, family_id, terminal_id, requested{grant_type,value}, status}`；`pending → approved｜rejected｜withdrawn`，只有 `pending` 能批／拒／撤；创建时 `requested` 可空。v1 新增：重发带 `Idempotency-Key` 去重（骨架局限第 27 条已修）。
- **A9 申请推送是 stub——未动，改了名。** 申请通知进“待拉取通知队列”（`GET /push/pending`）；原型“在第 13 屏时不弹条”是客户端展现规则，服务端不硬编码。
- **A10 密码哈希参数——未动。** PBKDF2-HMAC-SHA256，12 万次迭代，16 字节随机盐；哈希与盐分开存，快照里只有哈希。
- **A11 短信验证码是 stub——未动。** 注册接受 `sms_code` 字段，只做“4–6 位数字”格式检查，不发短信、不校验真实性；`POST /auth/send-code` 只回 `sent: true` 并明标 stub。对应 U17（验证码有效期未定）。
- **A12 会话 token——未动。** 注册／登录返回 48 位 hex 随机 token（`secrets.token_hex(24)`），存内存 `sessions`，不落盘，重启失效；无过期时间（TTL 与登出接口未定，留空比编一个更诚实）。对应 U22 的一部分（终端 token 发放方式仍未定——v1 里终端调业务接口用的是用户 Bearer token，终端 token 本身未发）。
- **A13 MCP 登录 stub 与“我的模型”死页——已变：MCP 改真校验；我的模型仍 503。** `POST /models/mcp-login` 不再是 501 stub，改为真实 GET 该网站做校验（见 V1-A2）；`POST /models/my-model` 仍一律 503，不收 Key。Key 存放方案已批（内存-only，见 V1-A11），但未实现、未启用。对应 U9（已定）、U13（仍未定：启用时间与 Key 存储口径）。
- **A14 配置下推是 stub——未动。** `POST /config/server` 只保存到服务端（`mode`＋`custom_address`），返回 `push_mode: "stub"`；本次不向板子推送，板子下次连接拉取。对应 U6（已定：拉取）。
- **A15 自有服务器地址格式——未动。** `custom_address` 只要求非空字符串，不校验 IP／域名格式。对应 U21（基地址协议与自有端口仍未定）。
- **A16 记录上传接口——未动。** 没有单独的记录上传接口；记录由服务端在每次真实事件发生时直接写，客户端只读（`GET /records`）；`GET /usage` 三组数全部由记录表汇总。对应 U5（已定：假问题，不另设上传接口）。
- **A17 用量费用一律不返回——未动，已定。** `/usage` 只有三组计数＋温度／MEMO，没有费用、没有分模型调用次数、没有充值档位。对应 U16（已定：用量计价已停，不做）。
- **A18 温度／MEMO 无数据源——未动。** `temperature`／`memo` 初始为空，`GET /lockscreen` 与 `/usage` 返回 `---°C`／`""`；不做 IP 定位、不内置 MEMO。对应 U15（仍未定：维护人／推送节奏）。v1 加了 `POST /config/environment/memo`（后台可设 MEMO，冒烟 §17 覆盖）。
- **A19 限流数值——未动。** 通用每 IP 每分钟 120 次；`/solve` 每终端每分钟 10 次；超了 429。窗口 60 秒滑动。可由环境变量 `JIANTI_RATE_LIMIT_GENERAL`／`JIANTI_RATE_LIMIT_SOLVE` 覆盖。
- **A20 鉴权方式与额外端点——有新增。** Bearer token 鉴权不变。v1 在骨架 5 个额外端点之外又加了：`POST /solve/{job_id}/cancel`、`/skip`（取消／跳题）、`POST /auth/send-code`、`POST /auth/passwords`（改密码）、`POST /auth/admin-password/reset`、`GET /family`、`POST /family/invite`、`/family/transfer`、`DELETE /family/members/{member_no}`、`GET /cards/rules`（与 `/cards/config` 同义）、`GET /config/environment`、`POST /config/environment/memo`、`GET /applications`。加的理由同骨架：清单里的模块没有这些入口就接不上；不加是缺功能，加了要明说。
- **A21 60 秒自动回锁屏不实现——未动。** 服务端无闲置计时。对应 U20（已定删除）。
- **A22 二维码载荷与热点名格式差异不处理——未动。** 扫码绑定接受纯 16 位数字与 `JianTi-<16 位>` 两种载荷；热点名格式是终端展现问题，服务端不管。
- **A23 快照文件位置——已改。** 不再是单文件 `snapshot.json`；改为 `JIANTI_DATA_DIR` 目录下的 15 个分实体 JSON 文件（默认 `./data`），写时先写临时文件再逐个改名。**快照失败不再“不阻断主流程”**：启动时损坏即退出码 2；运行时写失败，调用方按 500 处理（见 V1-A4）。

---

## §3 v1 新增的自定项（V1-A1 起）

### V1-A1. 取消与跳题端点
- **是什么**：`POST /solve/{job_id}/cancel`（取消未决任务；已终态的 job 不可取消，报 `job_not_cancellable`）、`POST /solve/{job_id}/skip`（跳过当前题）。取消后 job 状态为 `cancelled`，判题线程不再写结果。
- **为什么**：原型 F1 有“取消／跳过”操作，接口文档未单列；服务端必须有个落点，否则终端的取消按钮无处可调。
- **对应**：无未定项编号；冒烟 §9（判题延迟 5 秒窗口内取消）覆盖。

### V1-A2. MCP 登录改为真实校验（U9 定稿的落地）
- **是什么**：`POST /models/mcp-login`（别名 `/models/mcp/login`）真实 GET 该网站（10 秒超时）：不可达 → 503 `mcp_site_unreachable`；401／400 → 401 `mcp_auth_failed`；404／405／501 → 501 `mcp_login_unsupported`（该站未提供可识别的登录口）；其它 5xx → `mcp_site_error`。验证码只留内存临时状态（`mcp_captcha`），用完即丢；账号密码不存、不建库。
- **为什么**：U9 已定“必须真校验”，骨架的 501 stub 已不符合定稿。
- **对应**：U9（已定）。冒烟 §14 覆盖。

### V1-A3. `/solve` 先起判题线程再写快照（v1 验证中发现并修复的 bug）
- **是什么**：`gateway.py` `_post_solve` 原来是“建 job → `store.save()` → 起判题线程”；改为“建 job → 起判题线程 → `store.save()`”。写失败仍返回 500（契约不变），但 job 一定能跑完。
- **为什么**：快照写失败探针实锤：`save()` 一抛错，线程永远没起，job 永远卡在 processing，终端只能等 60 秒按 50401 超时（见 TESTLOG.md §3）。先起线程后，同一场景下 job 在 3 秒内走到 `failed model_not_connected`，终端轮询能拿到终态。
- **对应**：无未定项编号；v1 自决的修复，复测通过。

### V1-A4. 快照写失败的 500 语义与自愈
- **是什么**：写操作里 `store.save()` 抛 `OSError` → `_err_from` 映射为 500 `internal_error`（“服务端内部错误：快照写入失败。”）；内存里的改动保留，不回滚；同幂等键重试在磁盘修好前也 500（因为 `_idem_store` 的 `save()` 同样失败），磁盘修好后不重启即恢复，返回存过的 200 响应，不重复执行。
- **为什么**：`store.py` 的约定就是“写快照失败不再吞掉：`save()` 抛 `OSError`，调用方按 500 处理并记日志”。内存是权威状态，磁盘只是快照；回滚内存反而会丢已确认的操作。已实测自愈（TESTLOG.md §3.4）。
- **对应**：无未定项编号。

### V1-A5. 快照分 15 个文件、损坏启动失败
- **是什么**：`accounts.json`、`family_groups.json`、`members.json`、`devices.json`、`bindings.json`、`card_ledgers.json`、`card_transactions.json`、`applications.json`、`idempotency.json`、`solve_sessions.json`、`usage_records.json`、`server_configs.json`、`model_configs.json`、`weather_memo.json`、`invites.json`。启动时任一文件损坏（坏 JSON／读失败）即 `SnapshotCorruptError`、退出码 2，绝不静默按空库启动。（v2 的本文与 README §4 曾把其中 4 个写成旧名 `terminals.json`／`cards.json`／`jobs.json`／`records.json` 且漏了 `invites.json`，v3 已按 `store.py` 的 `SNAPSHOT_FILES` 改对，见 V3-A3。）
- **为什么**：骨架局限第 25 条点名要修；分实体文件后单文件损坏只影响启动告警的定位，不再整库丢了都不知道。
- **对应**：无未定项编号；冒烟 §22（3 项）覆盖。

### V1-A6. 服务器配置与模型选择按家庭组分
- **是什么**：`server_configs`、`model_configs` 均以 `family_id` 为键；A 组改自有服务器不影响 B 组；模型选择同理。
- **为什么**：骨架局限第 26 条点名要修；多家庭组下全局单份会互相覆盖。
- **对应**：无未定项编号；冒烟 §15（5 项）覆盖。

### V1-A7. 申请单幂等键
- **是什么**：`POST /applications` 支持 `Idempotency-Key`：同键重发回存过的 201 响应，不重复建单；另有“重复待批”拦截（同一家庭组同一终端已有 pending 申请时再建报 409）。
- **为什么**：骨架局限第 27 条点名要修；接口文档附录 B 要求重发去重。
- **对应**：无未定项编号；冒烟 §11（7 项）覆盖。

### V1-A8. 邀请码可复用、无过期时间
- **是什么**：`POST /family/invite` 生成 6 位邀请码，存 `invites` 表；同一码可多次使用，无过期时间；邀请话含下载地址＋邀请码——下载地址是原型占位地址，v1 不编（`INVITE_TEXT_DOWNLOAD_URL` 为空时邀请话里只写邀请码）。
- **为什么**：接口文档 B20 只定了“服务端生成 6 位邀请码”，没定复用与过期；可复用、无过期是最简单的可用做法，且邀请码本身不携带权限（进组仍要看邀请人角色与审批）。
- **对应**：U12（已定：虚拟组）。冒烟 §20 覆盖。

### V1-A9. 成员 3 通过后不自动加终端 5
- **是什么**：原型里“成员 3 通过后第 15 屏自动加一行终端 5”是演示行为；v1 **不做**：终端行只在该成员的设备真实绑定后才出现，不编设备 ID。
- **为什么**：自动加行要编一个设备 ID 出来，违反“不编假数据”红线；真实绑定后自然出现，不缺功能。
- **对应**：无未定项编号。

### V1-A10. 解绑权限口径：暂按“只有管理员能解绑”
- **是什么**：`DELETE /terminals/{device_id}` 只认管理员（非管理员 403）；解绑后终端编号顺延（重绑新编号，不复用旧号）。
- **为什么**：PRD 3.6 与接口文档 B6 对解绑权限的口径不一致（PRD 说成员可解绑自己的终端，接口说只有管理员能解绑）；v1 暂按接口文档执行，冲突项已写进缺啥清单，等 Nyx 确认。
- **对应**：PRD 3.6 vs 接口 B6（冲突待确认）。冒烟 §19 覆盖。

### V1-A11. “我的模型”Key 存放方案已批、未实现
- **是什么**：方案（Nyx 已批）：内存-only，不落盘；Key 不离开服务端；只存后 4 位掩码用于展示；最多 4 个；重启清空；启用前仍 503。v1 **未实现**：`POST /models/my-model` 仍一律 503，不收 Key。
- **为什么**：方案批了不等于启用了；启用时间仍未定（U13），启用前收 Key 就是违规。
- **对应**：U13（仍未定：启用时间与 Key 存储口径）。

### V1-A12. 终端调业务接口用的仍是用户 Bearer token
- **是什么**：v1 里终端调 `/solve` 等业务接口，`Authorization` 用的是注册／登录返回的用户 token，`X-Terminal-Id` 只作终端标识与绑定校验；终端专用的 Bearer token 未发放。
- **为什么**：终端 token 怎么发放（绑定时发还是预置）未定（U22），没法定就先不发；用户 token＋终端绑定校验已能做到“未绑定设备一律拒收”。
- **对应**：U22（仍未定）。

---

## §4 v2 新增的自定项（V2-A1 起）

### V2-A1. 幂等预检与业务同锁内原子完成（修同键并发重复执行，真缺陷）
- **是什么**：`gateway.py` 里 `/solve`、`/cards/deduct`、`/cards/advance`、`POST /applications`、approve、reject 六处，`_idem_lookup` → 业务执行 → `_idem_store` 整段挪进同一个 `with store.lock:`；`/solve` 的判题线程也在锁内起。`store.lock` 是 `RLock`，业务函数（`cards.*`、`applications.*`）内部再加锁不死锁；`store.save()` 仍在锁内调（与 v1 一致）。请求体（JSON／JPEG）在锁外读完、响应在锁外发，socket 读写不进锁。`/solve` 快照仍在锁外写，先起线程再写快照（V1-A3 的修复保持不变：写失败仍 500，但 job 能跑完）。
- **为什么**：v1 的预检在锁外：两路同键请求同时漏过预检，各建一个 job（并发探针在 v1 副本上复现：10 路同键并发建出 10 个 job）；扣卡／建单／审批同理有重复执行窗口。挪进锁内后，并发探针 10 路同键只建 1 个 job（见 TESTLOG.md §6）。
- **对应**：无未定项编号；Nyx 2026-11-16 裁决第 5 条。待 dsh 用 conc_probe2 复测。

### V2-A2. 无题错误码统一为 `no_question`（旧名 `no_question_detected` 清掉）
- **是什么**：`gateway.py` `_run_judge` 空 `results` 分支两处：`job["error"]["code"]` 与 `solve_failed` 记录 `detail.error`，都由 `no_question_detected` 改成 `no_question`；`failure_reason` 本来就是 `no_question`，不动。接口文档、架构文档、主缺啥清单本来就写 `no_question`，**文档不动**。
- **为什么**：接口文档 106 行定的就是 `failure_reason: no_question`；代码里 `error.code` 用另一个名是口径分裂，三端联调会对不上。
- **对应**：无未定项编号；Nyx 2026-11-16 裁决第 4 条。探针 `tests/probe_no_question.py` 进程内验证：空 `results` 时 job 与记录均为 `no_question`，旧名不再出现（见 TESTLOG.md §7）。冒烟无法覆盖这条分支（无 Qwen Key，走不到空 `results`）。

### V2-A3. 冒烟含中文的 `-d` 请求体改 `--data-binary @file`（Windows GBK）
- **是什么**：`tests/run_smoke.sh` §17 的 MEMO 设置（唯一含中文的 `-d` 请求体）改成先 `printf` 写 `/tmp/v2test-memo.json` 再 `--data-binary @file`；其余 `-d` 都是纯 ASCII，不动。另把脚本里的 `v1test` 临时名与 service 名断言同步改成 v2。
- **为什么**：Windows GBK 下 `curl -d` 行内中文会被转码，服务端 JSON 解析失败；`@file` 直接读磁盘字节，不走命令行转码。dsh 在 Windows 上验 v1 冒烟 184/2，两项失败（MEMO 设置 200 与锁屏读 MEMO）就是这个原因。
- **对应**：无未定项编号；Nyx 2026-11-16 裁决第 6 条（Nyx 146 定）。

---

## §5 v3 新增的自定项（V3-A1 起）

### V3-A1. 429 响应带 `Retry-After: 5`（只对 429 生效）
- **是什么**：`gateway.py` `_send` 里 `status == 429` 时补 `send_header("Retry-After", "5")`；其它状态码不带。429 的出错分支经 `_send_error` 走 `_send`，头在该链路上补，不动别处。接口文档的 429 行“等 `Retry-After` 秒（无该头时等 5 秒）”兜底句留着，**文档不动**。
- **为什么**：终端侧 429 处理是“等 `Retry-After` 秒后由用户手动重试一次”；服务端此前没发这个头，终端只能走“无该头等 5 秒”的兜底，值恰好一样但口径是猜的。发头后两端对上，值仍是 5，不改重试语义。
- **对应**：无未定项编号；Nyx 2026-11-17 裁决，RECHECK #10。冒烟 §23 新增 1 项断言（第 121 次通用请求 429 后再打一次，响应头 `Retry-After: 5`），冒烟由 186 项变为 187 项，见 TESTLOG.md §9。

### V3-A2. 僵尸 job 启动扫尾（新 failure_reason `process_interrupted`）
- **是什么**：`gateway.py` 新增 `reap_stale_processing_jobs(store)`，`run()` 里建好 Store 后、起网关前调一次：扫 `jobs`，`status == "processing"` 且 `created_at` 距现在超 120 秒（`2 × POLL_TIMEOUT_SECONDS`，常量 `STALE_JOB_MAX_AGE_SECONDS`）的标 `failed`，`stages.model` 置 `failed`，`error.code` 与 `failure_reason` 均为新码 `process_interrupted`（不撞已定六个码：`recognition_failed`／`model_unavailable`／`no_question`＋手册 §2.5 的六个终端侧码），并补一条终态 usage 记录（`solve_failed`，`detail.error=process_interrupted`）；有扫尾时写一次快照落盘。`created_at` 解析不出的 job 不动（等判题线程／取消处理，不误删）。`cancelled` 的 job 不在 `processing`，不受影响。
- **为什么**：判题线程只活在进程里；进程重启后旧 processing job 的线程没了，再等也不会终结，终端只能等 60 秒按 50401 超时、服务端却永远留一个 processing。120 秒取 2 倍轮询超时：正常判题 60 秒内应有终态（无 Key 的 stub 秒级失败），超 120 秒仍 processing 的只可能是丢了线程的僵尸。
- **对应**：无未定项编号；Nyx 2026-11-17 裁决，RECHECK #15。探针 `tests/probe_stale_jobs.py` 进程内验证：1 小时前的 processing job 标 failed／`process_interrupted` 且有终态记录并落盘重载仍 failed，新 job 仍 processing，旧 done job 不动（见 TESTLOG.md §10）。待 dsh 回归。

### V3-A3. README §4 与本文快照清单的旧名改对（dsh 175d，RECHECK #16）
- **是什么**：v2 的 README §4 与本文 V1-A5 把快照文件写成 `terminals.json`／`cards.json`／`jobs.json`／`records.json`，且漏了 `invites.json`；v3 按 `store.py` 的 `SNAPSHOT_FILES` 改对：`devices.json`（设备登记）、`card_ledgers.json`（卡余额）＋`card_transactions.json`（卡流水）、`solve_sessions.json`（jobs＋unlocked）、`usage_records.json`（records），补上 `invites.json`，共 15 个。代码（`store.py`）本来就是对的，**只改文档**。
- **为什么**：文档清单与磁盘实际名字对不上，三端联调按文档找文件会找不到；`jobs` 与 `records` 不是独立文件，是 `solve_sessions.json`／`usage_records.json` 里的段。
- **对应**：无未定项编号；dsh 175d。主文档（平台接口／架构／主缺啥清单）里查过，没有同样的旧名，不用改。

---

## §6 v4 新增的自定项（V4-A1 起）

### V4-A1. 扫码绑 `scan_payload` 或 `qr_payload` 都认（Nyx 284①）
- **是什么**：`gateway.py` 的 `POST /terminals/bind-scan` 原来只读 `b.get("scan_payload") or ""`；v4 改成 `b.get("scan_payload") or b.get("qr_payload") or ""`，任一有值即用。两者都空仍传 `""`，`binding.parse_scan_payload` 照旧报 422 `scan_no_data`；载荷解析（去空格、`(\d{16})` 匹配、首位白名单）与 `bind_scan` 逻辑一字不动。**文档与 App 都不动**——接口文档 B5 本来就要 `qr_payload`，App 本来就发 `qr_payload`，是服务端这边缺认。
- **为什么**：文档与 App 对上了，服务端却只认旧字段名，App 按文档发过去服务端收到空串、扫码绑定 422。双认后两端都不用改，只修服务端这一处。
- **对应**：无未定项编号；Nyx 2026-11-17 裁决，房间消息 id 284/285。探针 `tests/probe_bind_scan_payload.sh`：`scan_payload` 与 `qr_payload` 各绑一台、结果一致（201、同一设备类型与终端编号顺延），两者都空仍 422 `scan_no_data`，另有中文载荷 `--data-binary` 发送（见 TESTLOG.md §13）。待 dsh 回归。

### V4-A2. README 限流表环境变量名补 `_PER_MIN` 后缀（Nyx 232 定法②）
- **是什么**：README §1 限流表把两个变量写成 `JIANTI_RATE_LIMIT_GENERAL`／`JIANTI_RATE_LIMIT_SOLVE`，补成 `JIANTI_RATE_LIMIT_GENERAL_PER_MIN`／`JIANTI_RATE_LIMIT_SOLVE_PER_MIN`，与 `gateway.py:83-86`／`server_config.py:67-68` 实际读的名字一致。**代码不动**——代码本来就读带后缀的变量名，冒烟与探针也一直用带后缀的名字起服务。
- **为什么**：按 README 原表名配环境变量，服务端读不到、会静默用默认值 120／10；文档与代码对不上，部署时容易配错。
- **对应**：无未定项编号；Nyx 232 定法②。

---

## §7 v5 新增的自定项（V5-A1 起）

### V5-A1. keep-alive 下鉴权报错前排空未读 body（Nyx 329 定法②）
- **是什么**：`gateway.py` 是 HTTP/1.1（默认 keep-alive）；`_dispatch` 里鉴权（`_auth_user`／`_require_admin_session`）在 `_read_json()` 之前抛错时，401/403 错误响应发出时请求体还躺在 socket 缓冲里，同一连接下一个请求从残留 body 处解析而 400。v5 只动 `gateway.py`：`_dispatch` 异常出口发错误响应前调 `_drain_body()` 按 Content-Length 把未读 body 排空（64KB 分块读、尽力而为，读错不影响错误响应发出）；`_read_json()` 与 `/solve` 的 `rfile.read` 各记已读字节数（`self._body_read`，`_dispatch` 入口清零），已读完的不再排。**不采用入口预读**：`/solve` 图片 body 最大 8MB，入口预读会无脑进内存，业务里读的那路保持原样。
- **为什么**：Nyx 329 定的两种修法（鉴权前预读 body／报错前排空）中，排空法改动最小且不碰成功路径与 `/solve` 大 body；预读法要改所有 `_read_json()` 调用点并给 `/solve` 开例外，风险更大。
- **对应**：无未定项编号；Nyx 2026-11-17 裁决，房间消息 id 329。探针 `tests/probe_keepalive.py`：v4 上复现 PASS 9 FAIL 3（A2/B2 得 400，C2 得 501），v5 上 PASS 12 FAIL 0；冒烟重跑 PASS 187 FAIL 0（见 TESTLOG.md §14）。待 dsh 回归。
