"""records.py — 记录 / 用量 / 温度-MEMO（只返回真实入库的记录，v1）.

规则（手册 v2 §3.3、§4，PRD 第 7 章，接口 B11／A9／A10）：
- 第 13 屏只留三组数：拍题成功（次）、做题思路（道）、解题用卡（张），
  全部由 records 表实时汇总；原型里的用量演示数绝不进代码。
- 用量查询（U16 已定：计价已停，不做）：只返回服务端真实记录——
  三组数＋分模型调用次数＋合计次数（合计＝分模型调用次数之和，
  对应 v155 用量页底部的“合计”行；不含费用、单价、档位、充值字段）。
- 详情日志（B11）：日期／时间补零，各列对齐，说明为一句小话，数量放最后；
  来源写终端 N／成员 N；与时间筛选挂钩（7d／30d／90d），服务端按范围过滤。
- 温度／MEMO：store 里没数据就返回 ---°C / 空 MEMO，绝不编数字；
  温度按终端 IP 定位城市的服务未接（见缺啥清单），city 恒为 null。
"""
from __future__ import annotations

import time

from server_config import MEMO_EMPTY, TEMPERATURE_UNKNOWN

RANGE_DAYS = {"7d": 7, "30d": 30, "90d": 90}

# 记录 kind -> 日志页说明（一句小话）
KIND_DESCRIPTIONS = {
    "solve_success": "拍题成功",
    "thinking": "做题思路",
    "deduct": "解题用卡",
    "advance": "预支解题卡",
    "grant": "家长发卡",
    "application": "申请解题卡",
    "solve_failed": "拍题失败",
    "skip": "跳过题目",
}


def _record_ts(rec: dict) -> float:
    try:
        return time.mktime(time.strptime(rec["created_at"], "%Y-%m-%dT%H:%M:%S"))
    except (ValueError, TypeError):
        return time.time()


def _in_range(rec: dict, days: int | None) -> bool:
    if days is None:
        return True
    return _record_ts(rec) >= time.time() - days * 86400


def _source_label(store, family_id: str, rec: dict) -> str:
    """日志来源列：终端 N／成员 N。优先用记录里记的 terminal_id；
    管理类操作（发卡／审批）用操作人的成员编号；缺省为成员 1。"""
    detail = rec.get("detail") or {}
    terminal_id = detail.get("terminal_id")
    if terminal_id:
        b = store.data["bindings"].get(terminal_id)
        if b is not None and b.get("terminal_no"):
            return f"终端 {b['terminal_no']}"
        return "终端 ?"
    member_no = detail.get("member_no") or 1
    return f"成员 {member_no}"


def _record_count(rec: dict) -> int:
    detail = rec.get("detail") or {}
    if rec["kind"] == "solve_success":
        return detail.get("questions", 1)
    if rec["kind"] == "thinking":
        return detail.get("questions", 1)
    return detail.get("cards", 1)


def usage_summary(store, family_id: str, days: int = 7) -> dict:
    """三组数 + 分模型调用次数 + 合计次数 + 温度/MEMO。只算真实入库的记录，不计费。

    合计（v9，Nyx 9080 id 21，浩爷已点头）：total_calls 与“合计次数”
    都是分模型调用次数之和（v155 用量页底部有“合计（调用次数＋费用）”
    行；计价已停、无费用，合计只合计调用次数）。双键写法沿用本文件
    的既有惯例（photo_success／拍题成功次 等）。"""
    solved = thinking = cards = 0
    per_model: dict[str, int] = {}
    for rec in store.data["records"]:
        if rec["family_id"] != family_id or not _in_range(rec, days):
            continue
        if rec["kind"] == "solve_success":
            solved += 1
        elif rec["kind"] == "thinking":
            thinking += rec["detail"].get("questions", 1)
        elif rec["kind"] == "deduct":
            cards += rec["detail"].get("cards", 1)
    for job in store.data["jobs"].values():
        if job["family_id"] != family_id:
            continue
        try:
            ts = time.mktime(time.strptime(
                job["created_at"], "%Y-%m-%dT%H:%M:%S"))
        except (ValueError, TypeError):
            ts = time.time()
        if ts < time.time() - days * 86400:
            continue
        per_model[job.get("model_id", "unknown")] = \
            per_model.get(job.get("model_id", "unknown"), 0) + 1
    temp = store.data.get("temperature") or TEMPERATURE_UNKNOWN
    memo = store.data.get("memo") or MEMO_EMPTY
    total = sum(per_model.values())   # 合计调用次数（v9）
    return {
        "family_id": family_id,
        "days": days,
        "photo_success": solved,       # 拍题成功（次）
        "thinking_count": thinking,    # 做题思路（道，按道计）
        "cards_used": cards,           # 解题用卡（张）
        "拍题成功次": solved,
        "做题思路道": thinking,
        "解题用卡张": cards,
        "models": [{"model": m, "calls": n}
                   for m, n in sorted(per_model.items())],
        "total_calls": total,          # 合计调用次数（= 分模型调用次数之和）
        "合计次数": total,              # 合计次数（同 total_calls）
        "temperature": temp,   # 无数据 -> "---°C"
        "memo": memo,          # 无数据 -> ""
    }


def list_records(store, family_id: str, days: int | None = None) -> dict:
    """B11：summary 三组数 + 详情日志 items（日期时间补零、来源、说明、数量）。

    兼容骨架的调用方式：days=None 时返回全部记录的 B11 形状。
    """
    items = []
    solved = thinking = cards = 0
    for rec in store.data["records"]:
        if rec["family_id"] != family_id or not _in_range(rec, days):
            continue
        if rec["kind"] == "solve_success":
            solved += 1
        elif rec["kind"] == "thinking":
            thinking += rec["detail"].get("questions", 1)
        elif rec["kind"] == "deduct":
            cards += rec["detail"].get("cards", 1)
        date, _, t = rec["created_at"].partition("T")
        items.append({
            "record_id": rec["id"],
            "date": date,                    # YYYY-MM-DD，补零
            "time": t,                       # HH:mm:ss，补零
            "source": _source_label(store, family_id, rec),
            "description": KIND_DESCRIPTIONS.get(rec["kind"], rec["kind"]),
            "count": _record_count(rec),     # 数量放最后
            "kind": rec["kind"],
        })
    items.sort(key=lambda x: (x["date"], x["time"]), reverse=True)
    return {
        "summary": {"photo_success": solved, "thinking_count": thinking,
                    "cards_used": cards},
        "items": items,
        "total": len(items),
    }


def lockscreen_info(store) -> dict:
    """锁屏第 1 屏：温度按终端 IP 定位后下发 —— v1 无定位服务，
    故恒返回 ---°C；MEMO 无后台小模块，恒返回空（管理员可经
    POST /config/environment/memo 设置，见 gateway.py）。"""
    return {
        "temperature": store.data.get("temperature") or TEMPERATURE_UNKNOWN,
        "memo": store.data.get("memo") or MEMO_EMPTY,
    }


def environment_info(store) -> dict:
    """A10：温度／MEMO 下发。city 未查到为 null，不编数字、不编城市。"""
    return {
        "temperature": store.data.get("temperature") or TEMPERATURE_UNKNOWN,
        "city": None,
        "memo": store.data.get("memo") or MEMO_EMPTY,
        "updated_at": None,
    }
