"""app.py — 组装入口：只负责启动网关（8000 唯一入口，平台服务器端 v1）.

用法：
    python3 app.py            # 127.0.0.1:8000
    JIANTI_HOST=0.0.0.0 JIANTI_PORT=8000 python3 app.py
    QWEN_API_KEY=... python3 app.py   # 接通 Qwen 主链路；不设则 stub 模式
    JIANTI_DATA_DIR=/path/to/data python3 app.py  # 快照目录（默认 ./data）
    JIANTI_JUDGE_DELAY_SECONDS=5 python3 app.py  # 仅测试用：判题延迟（测取消分支）

快照损坏时启动失败（退出码 2，stderr 有告警），不静默按空库启动。
"""
from __future__ import annotations

import os

from gateway import GATEWAY_PORT, run

if __name__ == "__main__":
    run(host=os.environ.get("JIANTI_HOST", "127.0.0.1"),
        port=int(os.environ.get("JIANTI_PORT", str(GATEWAY_PORT))),
        data_dir=os.environ.get("JIANTI_DATA_DIR"))
