"""families.py — 家庭组管理（第 14 屏，接口文档 B20，平台服务器端 v1 新增）.

规则（手册 v2 §3.4，PRD 3.6）：
- 家庭组标题行显示 8 位纯数字 ID（服务端生成、终身不变）；注册时建虚拟组，
  首个新成员正式加入时翻固化，ID 不变（翻转点在 users.py 注册带邀请码
  与本文件 approve_member()）。
- 成员编号跟人走，转让不换号，新成员顺延，删掉的编号不复用。
- 只有管理员能转让／删除；转让先二次确认（客户端），服务端只认调用；
  转让给不存在的成员 400，非管理员 403。
- 邀请成员用 6 位邀请码：管理员邀请直接进组，非管理员邀请需审批；
  待审批成员行尾放“通过”“拒绝”，通过变正式成员、行尾换回转让／删除，
  拒绝该行消失。
- 成员 3 通过后第 15 屏自动加一行终端 5 是原型演示行为：v1 不编设备 ID，
  终端行只在该成员的设备真实绑定后才出现（见 ASSUMPTIONS.md V1-A9）。
- 解绑权限口径待 Nyx 确认（PRD 3.6 与接口 B6 不一致）：v1 暂按接口文档
  “只有管理员能解绑”执行，见 binding.py 与缺啥清单。
"""
from __future__ import annotations

from models import member_key, new_member, now_iso
from server_config import INVITE_TEXT_DOWNLOAD_URL
from users import UserError, generate_invite_code


def _family_or_404(store, family_id: str) -> dict:
    fam = store.data["families"].get(family_id)
    if fam is None:
        raise UserError("family_not_found", "家庭组不存在。", 404)
    return fam


def _require_admin(user: dict) -> None:
    if user.get("role") != "管理员":
        raise UserError("forbidden", "只有管理员能做这个操作。", 403)


def _member_type(store, family_id: str, member_no: int) -> str | None:
    """成员的类型标（苹果／安卓等）：取该成员绑定的第一台终端的类型；
    未绑定终端时为 None（不编）。"""
    for b in store.data["bindings"].values():
        if b["family_id"] == family_id and b.get("member_no") == member_no:
            from binding import device_type_name
            term = store.data["terminals"].get(b["device_id"])
            if term is not None:
                return device_type_name(term["device_id"])
    return None


def get_family(store, family_id: str) -> dict:
    with store.lock:
        fam = _family_or_404(store, family_id)
        members = []
        for key in sorted(store.data["members"]):
            m = store.data["members"][key]
            if m["family_id"] != family_id or m["status"] == "rejected":
                continue
            members.append({
                "member_no": m["member_no"],
                "phone": m["phone"],
                "role": m["role"],
                "status": m["status"],
                "type": _member_type(store, family_id, m["member_no"]),
            })
        members.sort(key=lambda x: x["member_no"])
        return {
            "family_group_id": family_id,
            "status": fam["status"],  # virtual 虚拟组 / solidified 已固化
            "admin_member_no": next(
                (m["member_no"] for m in members if m["role"] == "管理员"),
                None),
            "members": members,
        }


def create_invite(store, user: dict) -> dict:
    """点“邀请成员”生成一段话：含下载地址＋6 位邀请码，可复制／分享。
    下载地址是原型占位地址，v1 不编（INVITE_TEXT_DOWNLOAD_URL 为空时
    邀请话里不写下载地址，只写邀请码）。邀请码可复用、无过期时间
    （见 ASSUMPTIONS.md V1-A8）。"""
    with store.lock:
        fam = _family_or_404(store, user["family_id"])
        code = generate_invite_code(store)
        store.data["invites"][code] = {
            "family_id": user["family_id"],
            "inviter_member_no": user.get("member_no"),
            "inviter_role": user.get("role"),
            "created_at": now_iso(),
        }
        store.save()
        text = f"加入我的简题家庭组，邀请码：{code}。"
        if INVITE_TEXT_DOWNLOAD_URL:
            text = (f"加入我的简题家庭组，下载地址："
                    f"{INVITE_TEXT_DOWNLOAD_URL}，邀请码：{code}。")
        return {
            "invite_code": code,
            "invite_text": text,
            "inviter_role": user.get("role"),
            "direct_join": user.get("role") == "管理员",
        }


def approve_member(store, user: dict, member_no: int) -> dict:
    """待审批成员点“通过”变正式成员；首个新成员正式加入时家庭组翻固化。"""
    with store.lock:
        _require_admin(user)
        fam = _family_or_404(store, user["family_id"])
        m = store.data["members"].get(member_key(user["family_id"], member_no))
        if m is None or m["status"] == "rejected":
            raise UserError("member_not_found", "该成员不存在。", 404)
        if m["status"] == "active":
            raise UserError("member_already_active", "该成员已是正式成员。", 409)
        m["status"] = "active"
        m["role"] = "成员"
        u = store.data["users"].get(m["user_id"])
        if u is not None:
            u["role"] = "成员"
        if fam["status"] == "virtual":
            fam["status"] = "solidified"  # 首个新成员加入，翻固化，ID 不变
        store.save()
        return {"member_no": member_no, "role": "成员",
                "family_status": fam["status"]}


def reject_member(store, user: dict, member_no: int) -> dict:
    """待审批成员点“拒绝”，该行消失。"""
    with store.lock:
        _require_admin(user)
        m = store.data["members"].get(member_key(user["family_id"], member_no))
        if m is None or m["status"] == "rejected":
            raise UserError("member_not_found", "该成员不存在。", 404)
        if m["status"] == "active":
            raise UserError("member_already_active", "正式成员不能用拒绝处理。", 409)
        m["status"] = "rejected"
        u = store.data["users"].get(m["user_id"])
        if u is not None:
            # 被拒账号保留登录能力但不属于任何家庭组，重新注册邀请码可再加入。
            u["role"] = "待审批"
        store.save()
        return {"member_no": member_no, "status": "rejected"}


def transfer_admin(store, user: dict, to_member_no: int) -> dict:
    """转让管理员：只问“确认转让管理员？”，确认才转；编号跟人走，不换号。"""
    with store.lock:
        _require_admin(user)
        fam = _family_or_404(store, user["family_id"])
        target = store.data["members"].get(
            member_key(user["family_id"], to_member_no))
        if target is None or target["status"] != "active":
            raise UserError("member_not_found", "转让目标不是正式成员。")
        if target["role"] == "管理员":
            raise UserError("already_admin", "对方已经是管理员。", 409)
        cur = store.data["members"].get(
            member_key(user["family_id"], user.get("member_no")))
        if cur is not None:
            cur["role"] = "成员"
        target["role"] = "管理员"
        fam["owner_user_id"] = target["user_id"]
        cu = store.data["users"].get(user["id"])
        if cu is not None:
            cu["role"] = "成员"
        tu = store.data["users"].get(target["user_id"])
        if tu is not None:
            tu["role"] = "管理员"
        store.save()
        return {"admin_member_no": to_member_no}


def delete_member(store, user: dict, member_no: int) -> dict:
    """删除成员：只有管理员能删；管理员本人须先转让，不能直接删自己。"""
    with store.lock:
        _require_admin(user)
        if member_no == user.get("member_no"):
            raise UserError("cannot_delete_self",
                            "管理员不能直接删除自己，请先转让管理员。")
        m = store.data["members"].get(member_key(user["family_id"], member_no))
        if m is None or m["status"] == "rejected":
            raise UserError("member_not_found", "该成员不存在。", 404)
        del store.data["members"][member_key(user["family_id"], member_no)]
        u = store.data["users"].pop(m["user_id"], None)
        if u is not None:
            store.data["users_by_phone"].pop(u["phone"], None)
        store.save()
        return {"member_no": member_no, "deleted": True}
