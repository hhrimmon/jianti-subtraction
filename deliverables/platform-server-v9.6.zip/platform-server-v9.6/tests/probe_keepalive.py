#!/usr/bin/env python3
# keep-alive 探针（v5 新增，Nyx 房间消息 id 329 定法②）。
# 根因：gateway.py protocol_version 是 HTTP/1.1（默认 keep-alive）；
# _dispatch 里鉴权（_auth_user / _require_admin_session）抛错在
# _read_json() 之前，401/403 错误响应发出时请求体还躺在 socket 缓冲里，
# 同一连接下一个请求就从残留 body 处开始解析而 400 Bad request syntax。
# 用法：python3 tests/probe_keepalive.py [SERVER_DIR] [PORT]
#   默认测本目录（v5）；传 v4 目录可复现旧坑（预期 FAIL）。
#   实例：端口 18006，数据目录 /tmp/v5test-keepalive-data（每次重建），跑完自清。
# 断言（同一连接、裸 http.client，不换连接）：
#   A. POST /config/server 无 token（带 JSON body）→ 401；
#      紧接 POST /auth/register → 201（v4 上是 400 Bad request syntax）。
#   B. 新会话未验管理密码 POST /auth/passwords（带 body）→ 403；
#      紧接 GET /health → 200（v4 上是 400）。
#   C. POST /solve 未绑定终端（带 JPEG body）→ 403 terminal_not_bound；
#      紧接 GET /health → 200（v4 上是 400；验证 /solve 大 body 也被排空）。
#   D. 正常已读 body 的 POST 之后同一连接继续请求 → 200（回归：已读不重排）。
# 注意：脚本里出现的手机号／密码均为测试假数据，不是真实凭证。
import http.client
import json
import os
import shutil
import subprocess
import sys
import time

SERVER_DIR = os.path.abspath(sys.argv[1] if len(sys.argv) > 1
                              else os.path.join(os.path.dirname(__file__), ".."))
PORT = int(sys.argv[2]) if len(sys.argv) > 2 else 18006
DATA = "/tmp/v5test-keepalive-data"
PASS = 0
FAIL = 0
FAILED = []


def check(name, got, want):
    global PASS, FAIL
    if got == want:
        PASS += 1
        print(f"PASS: {name} ({got})")
    else:
        FAIL += 1
        FAILED.append(name)
        print(f"FAIL: {name} (want {want}, got {got})")


def one(method, path, body=None, headers=None):
    """单次请求：每次新开连接（仅用于准备步骤，不测 keep-alive）。"""
    conn = http.client.HTTPConnection("127.0.0.1", PORT, timeout=10)
    try:
        h = dict(headers or {})
        data = None
        if body is not None:
            data = body if isinstance(body, bytes) else json.dumps(
                body, ensure_ascii=False).encode("utf-8")
            h.setdefault("Content-Type", "application/json")
            h["Content-Length"] = str(len(data))
        conn.request(method, path, body=data, headers=h)
        resp = conn.getresponse()
        raw = resp.read()
        try:
            parsed = json.loads(raw.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            parsed = {"_raw": raw[:200]}
        return resp.status, parsed
    finally:
        conn.close()


def main():
    shutil.rmtree(DATA, ignore_errors=True)
    env = dict(os.environ, JIANTI_PORT=str(PORT), JIANTI_DATA_DIR=DATA,
               JIANTI_JUDGE_DELAY_SECONDS="5",
               JIANTI_RATE_LIMIT_GENERAL_PER_MIN="10000")
    proc = subprocess.Popen(
        [sys.executable, "app.py"], cwd=SERVER_DIR, env=env,
        stdout=open("/tmp/v5test-keepalive-server.log", "w"),
        stderr=subprocess.STDOUT)
    try:
        for _ in range(20):
            try:
                code, _ = one("GET", "/health")
                if code == 200:
                    break
            except OSError:
                pass
            time.sleep(0.5)
        else:
            print("服务器没起来")
            return 1

        # 准备：注册 A 并验管理密码；注册 B 后新登录一个未验管理密码的会话。
        code, reg_a = one("POST", "/users/register", {
            "phone": "13800138000", "login_password": "12345678",
            "admin_password": "123456", "sms_code": "123456"})
        check("准备：注册 A 201", code, 201)
        token_a = reg_a.get("token", "")
        code, _ = one("POST", "/users/admin-password/verify", {
            "admin_password": "123456"},
            {"Authorization": f"Bearer {token_a}"})
        check("准备：A 验管理密码 200", code, 200)
        code, _ = one("POST", "/users/register", {
            "phone": "13900139001", "login_password": "12345678",
            "admin_password": "123456", "sms_code": "123456"})
        check("准备：注册 B 201", code, 201)
        code, login_b = one("POST", "/users/login", {
            "phone": "13900139001", "login_password": "12345678"})
        check("准备：B 登录 200（新会话，未验管理密码）", code, 200)
        token_b = login_b.get("token", "")
        tiny_jpeg = b"\xff\xd8\xff\xe0" + b"\x00" * 100

        # A 路：401 后同一连接紧接注册 → 201。
        conn = http.client.HTTPConnection("127.0.0.1", PORT, timeout=10)
        try:
            body = json.dumps({"mode": "custom",
                               "custom_address": "192.168.1.10:8000"}).encode()
            conn.request("POST", "/config/server", body=body, headers={
                "Content-Type": "application/json",
                "Content-Length": str(len(body))})
            r1 = conn.getresponse()
            r1.read()
            check("A1：无 token 改服务器配置 401", r1.status, 401)
            body = json.dumps({"phone": "13700137000", "code": "123456",
                               "password": "12345678",
                               "admin_password": "123456"}).encode()
            conn.request("POST", "/auth/register", body=body, headers={
                "Content-Type": "application/json",
                "Content-Length": str(len(body))})
            r2 = conn.getresponse()
            r2.read()
            check("A2：同一连接紧接注册 201（旧坑：400）", r2.status, 201)
        finally:
            conn.close()

        # B 路：403 后同一连接紧接 GET /health → 200。
        conn = http.client.HTTPConnection("127.0.0.1", PORT, timeout=10)
        try:
            body = json.dumps({"type": "login", "old_password": "12345678",
                               "new_password": "87654321",
                               "new_password_confirm": "87654321"}).encode()
            conn.request("POST", "/auth/passwords", body=body, headers={
                "Content-Type": "application/json",
                "Content-Length": str(len(body)),
                "Authorization": f"Bearer {token_b}"})
            r1 = conn.getresponse()
            r1.read()
            check("B1：未验管理密码改密码 403", r1.status, 403)
            conn.request("GET", "/health")
            r2 = conn.getresponse()
            r2.read()
            check("B2：同一连接紧接 GET /health 200（旧坑：400）",
                  r2.status, 200)
        finally:
            conn.close()

        # C 路：/solve 未绑定终端 403（图片 body 在鉴权后才读，报错时未读），
        # 同一连接紧接 GET /health → 200。
        conn = http.client.HTTPConnection("127.0.0.1", PORT, timeout=10)
        try:
            conn.request("POST", "/solve", body=tiny_jpeg, headers={
                "Content-Type": "image/jpeg",
                "Content-Length": str(len(tiny_jpeg)),
                "Authorization": f"Bearer {token_a}",
                "X-Terminal-Id": "9999059832773436",
                "Idempotency-Key": "ka-solve-1"})
            r1 = conn.getresponse()
            r1.read()
            check("C1：未绑定终端拍题 403", r1.status, 403)
            conn.request("GET", "/health")
            r2 = conn.getresponse()
            r2.read()
            check("C2：同一连接紧接 GET /health 200（旧坑：400）",
                  r2.status, 200)
        finally:
            conn.close()

        # D 路：正常已读 body 的 POST 之后，同一连接继续请求 → 200。
        conn = http.client.HTTPConnection("127.0.0.1", PORT, timeout=10)
        try:
            body = json.dumps({}).encode()
            conn.request("POST", "/cards/check", body=body, headers={
                "Content-Type": "application/json",
                "Content-Length": str(len(body)),
                "Authorization": f"Bearer {token_a}"})
            r1 = conn.getresponse()
            r1.read()
            check("D1：查卡 200", r1.status, 200)
            conn.request("GET", "/health")
            r2 = conn.getresponse()
            r2.read()
            check("D2：同一连接紧接 GET /health 200", r2.status, 200)
        finally:
            conn.close()

        print()
        print(f"PASS: {PASS}  FAIL: {FAIL}")
        if FAILED:
            print("失败项：" + "|".join(FAILED))
        return 0 if FAIL == 0 else 1
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
        shutil.rmtree(DATA, ignore_errors=True)


if __name__ == "__main__":
    sys.exit(main())
