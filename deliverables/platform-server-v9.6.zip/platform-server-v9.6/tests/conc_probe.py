#!/usr/bin/env python3
"""并发探针：同键并发打 POST /solve，distinct job_id 恒=1（v2 修复验证）。

用法：python3 tests/conc_probe.py
  起临时实例（端口 18010、临时快照目录、判题延迟 0、限流调高），注册＋绑终端，
  然后 10 路并发用同一个 Idempotency-Key POST /solve，再用第二个键打 5 路。
  断言：第一波去重后 job_id 只有 1 个且全是 202；第二波只新增 1 个 job。
  退出码 0=通过，1=失败。dsh 之后会用 conc_probe2 复测。

  关键：请求体分两段发——所有路先发一半、屏障对齐、再同时发后一半。
  这样 v1 的旧代码（幂等预检在读请求体之前、建 job 在锁外）一定会让多路
  同时漏过预检、各建一个 job（已在 v1 副本上复现：10 路并发建出多个 job）；
  v2 把“查幂等→建 job→写记录”整段挪进锁内，预检在读完体之后锁内做，
  后到的路在锁内看到命中、直接返回第一个 job。
"""
import http.client
import json
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
import urllib.error

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
PORT = 18010
BASE = f"http://127.0.0.1:{PORT}"
DATA = "/tmp/v4test-conc-data"
TINY_JPG = b"\xff\xd8\xff\xe0" + b"\x00" * 100
TERM = "2040059832773436"


def req(method, path, token=None, headers=None, body=None):
    h = dict(headers or {})
    if token:
        h["Authorization"] = f"Bearer {token}"
    data = body
    if isinstance(body, dict):
        data = json.dumps(body, ensure_ascii=False).encode("utf-8")
        h.setdefault("Content-Type", "application/json")
    r = urllib.request.Request(BASE + path, data=data, method=method, headers=h)
    try:
        with urllib.request.urlopen(r, timeout=30) as resp:
            return resp.status, json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read().decode("utf-8"))


def post_solve_two_phase(key, token, barrier):
    """发一半 body，等屏障，再发另一半：让所有并发路同时越过旧代码的预检点。"""
    conn = http.client.HTTPConnection("127.0.0.1", PORT, timeout=30)
    half = len(TINY_JPG) // 2
    conn.putrequest("POST", "/solve")
    conn.putheader("Authorization", f"Bearer {token}")
    conn.putheader("X-Terminal-Id", TERM)
    conn.putheader("Idempotency-Key", key)
    conn.putheader("Content-Type", "image/jpeg")
    conn.putheader("Content-Length", str(len(TINY_JPG)))
    conn.endheaders()
    conn.send(TINY_JPG[:half])
    barrier.wait(timeout=10)
    time.sleep(0.1)
    conn.send(TINY_JPG[half:])
    resp = conn.getresponse()
    data = json.loads(resp.read().decode("utf-8"))
    conn.close()
    return resp.status, data


def wave(key, n, token):
    barrier = threading.Barrier(n)
    results = []

    def one():
        results.append(post_solve_two_phase(key, token, barrier))

    threads = [threading.Thread(target=one) for _ in range(n)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    return results


def main():
    shutil.rmtree(DATA, ignore_errors=True)
    env = dict(os.environ, JIANTI_PORT=str(PORT), JIANTI_DATA_DIR=DATA,
               JIANTI_JUDGE_DELAY_SECONDS="0",
               JIANTI_RATE_LIMIT_GENERAL_PER_MIN="10000",
               JIANTI_RATE_LIMIT_SOLVE_PER_MIN="10000")
    proc = subprocess.Popen(
        [sys.executable, "app.py"], cwd=ROOT, env=env,
        stdout=open("/tmp/v4test-conc-server.log", "w"),
        stderr=subprocess.STDOUT)
    try:
        for _ in range(30):
            try:
                code, _ = req("GET", "/health")
                if code == 200:
                    break
            except Exception:
                pass
            time.sleep(0.5)
        else:
            print("FAIL: 服务器没起来")
            return 1
        code, reg = req("POST", "/users/register", body={
            "phone": "13800138000", "login_password": "12345678",
            "admin_password": "123456", "sms_code": "123456"})
        assert code == 201, f"注册失败 {code} {reg}"
        token = reg["token"]
        code, _ = req("POST", "/users/admin-password/verify", token=token,
                      body={"admin_password": "123456"})
        assert code == 200, f"管理密码校验失败 {code}"
        code, bind = req("POST", "/terminals/bind", token=token,
                         body={"device_id": TERM})
        assert code == 201, f"绑定失败 {code} {bind}"

        ok = True
        wave1 = wave("conc-solve-1", 10, token)
        codes1 = sorted(c for c, _ in wave1)
        jobs1 = {b.get("job_id") for _, b in wave1}
        print(f"第一波：10 路同键并发 -> HTTP {codes1}，distinct job_id={len(jobs1)}：{sorted(jobs1)}")
        if codes1 != [202] * 10:
            print("FAIL: 第一波应全是 202")
            ok = False
        if len(jobs1) != 1:
            print(f"FAIL: 第一波 distinct job_id 应为 1，实为 {len(jobs1)}（竞态未修）")
            ok = False

        wave2 = wave("conc-solve-2", 5, token)
        jobs2 = {b.get("job_id") for _, b in wave2}
        print(f"第二波：5 路新键并发 -> distinct job_id={len(jobs2)}：{sorted(jobs2)}")
        if len(jobs2) != 1 or jobs2 & jobs1:
            print("FAIL: 第二波应只新增 1 个不同 job")
            ok = False

        code, _ = req("GET", "/usage?range=7d", token=token)
        print(f"复核：GET /usage {code}")
        print("PASS: 同键并发只建一个 job" if ok else "FAIL: 并发探针未通过")
        return 0 if ok else 1
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
        shutil.rmtree(DATA, ignore_errors=True)


if __name__ == "__main__":
    sys.exit(main())
