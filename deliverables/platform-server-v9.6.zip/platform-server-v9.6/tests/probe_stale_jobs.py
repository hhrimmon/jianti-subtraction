#!/usr/bin/env python3
"""僵尸 job 启动扫尾探针（v3，RECHECK #15）：processing 且 created_at 超
2×POLL_TIMEOUT（120 秒）的 job，启动时标 failed，failure_reason 为新码
process_interrupted，并补一条终态 usage 记录；新 job 不受影响。

用法：python3 tests/probe_stale_jobs.py
  进程内跑：建临时 Store，往快照里写 1 个僵尸 job（created_at 1 小时前，
  processing）、1 个新 job（created_at 现在，processing）、1 个旧 done
  job；再建一个新 Store（模拟冷重启加载快照）并调
  gateway.reap_stale_processing_jobs，断言三者状态与终态记录。
  不起 HTTP 服务，不需要 Qwen Key。退出码 0=通过，1=失败。
"""
import os
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)

DATA_DIR = tempfile.mkdtemp(prefix="v4test-stale-")
os.environ["JIANTI_DATA_DIR"] = DATA_DIR

import gateway  # noqa: E402
from models import new_job, now_iso  # noqa: E402
from store import Store  # noqa: E402


def _iso(seconds_ago: float) -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S",
                         time.localtime(time.time() - seconds_ago))


def main():
    # 先建一个 Store 写快照：僵尸 job + 新 job + 旧 done job。
    store = Store()
    stale = new_job("job-probe-stale", "2040059832773436", "12345678",
                    100, "jt-lite-2.0")
    stale["created_at"] = _iso(3600)  # 1 小时前，processing
    fresh = new_job("job-probe-fresh", "2040059832773436", "12345678",
                    100, "jt-lite-2.0")
    fresh["created_at"] = now_iso()  # 现在，processing
    done = new_job("job-probe-done", "2040059832773436", "12345678",
                   100, "jt-lite-2.0")
    done["created_at"] = _iso(3600)
    done["status"] = "done"
    done["stages"]["model"] = "done"
    store.data["jobs"] = {"job-probe-stale": stale,
                          "job-probe-fresh": fresh,
                          "job-probe-done": done}
    store.save()

    # 冷重启：重新加载快照，再跑启动扫尾。
    store2 = Store()
    reaped = gateway.reap_stale_processing_jobs(store2)
    print(f"扫尾标 failed：{reaped}")
    jobs = store2.data["jobs"]
    print(f"stale: status={jobs['job-probe-stale']['status']} "
          f"failure_reason={jobs['job-probe-stale'].get('failure_reason')} "
          f"error={jobs['job-probe-stale'].get('error')}")
    print(f"fresh: status={jobs['job-probe-fresh']['status']}")
    print(f"done: status={jobs['job-probe-done']['status']}")
    recs = [r for r in store2.data["records"]
            if r.get("kind") == "solve_failed"
            and r["detail"].get("error") == "process_interrupted"]
    print(f"process_interrupted 终态记录：{len(recs)} 条，"
          f"detail={recs[0]['detail'] if recs else '无'}")
    # 快照已落盘：再加载一次，僵尸 job 仍是 failed。
    store3 = Store()
    persisted = (store3.data["jobs"]["job-probe-stale"]["status"] == "failed"
                 and store3.data["jobs"]["job-probe-stale"].get(
                     "failure_reason") == "process_interrupted")
    print(f"快照落盘后重载仍 failed：{persisted}")

    ok = (reaped == ["job-probe-stale"]
          and jobs["job-probe-stale"]["status"] == "failed"
          and jobs["job-probe-stale"].get("failure_reason")
          == "process_interrupted"
          and (jobs["job-probe-stale"].get("error") or {}).get("code")
          == "process_interrupted"
          and jobs["job-probe-fresh"]["status"] == "processing"
          and jobs["job-probe-done"]["status"] == "done"
          and len(recs) == 1
          and recs[0]["detail"].get("job_id") == "job-probe-stale"
          and persisted)
    print("PASS: 僵尸 job 标 failed/process_interrupted 且有终态记录，"
          "新 job 不受影响" if ok else "FAIL: 僵尸 job 扫尾探针未通过")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
