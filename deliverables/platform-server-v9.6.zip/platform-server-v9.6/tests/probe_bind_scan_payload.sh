#!/bin/bash
# 扫码绑双字段探针（Nyx 284①，v4 新增）。
# 用法：bash tests/probe_bind_scan_payload.sh
#   实例：端口 18005，数据目录 /tmp/v4test-bindscan-data（每次重建）。
#   断言：POST /terminals/bind-scan 用 scan_payload 能绑 201；
#   用 qr_payload（文档 B5 要的字段、App 发的字段）同样能绑 201，
#   两者结果一致（同为 201、设备类型取码首位、终端编号顺延）；
#   两字段都空（或都不传）仍 422 scan_no_data；两字段都传时
#   scan_payload 优先；中文载荷用 --data-binary 发，解析不受影响。
# 注意：脚本里出现的手机号／密码均为测试假数据，不是真实凭证。
set -u
cd "$(dirname "$0")/.."

PORT=18005
DATA=/tmp/v4test-bindscan-data
BASE=http://127.0.0.1:$PORT
RESP=/tmp/v4test-bindscan-resp.json
PASS=0; FAIL=0; FAILED_NAMES=""

note() { echo; echo "== $* =="; }
req() { local method=$1 path=$2; shift 2; local out
  out=$(curl -s -w "\n%{http_code}" -X "$method" "$BASE$path" "$@")
  CODE="${out##*$'\n'}"; BODY="${out%$'\n'*}"
  printf '%s' "$BODY" > "$RESP"
  echo "[$CODE] $method $path -> $BODY"; }
jget() { python3 -c "import json;d=json.load(open('$RESP'));print($1 if $1 is not None else '')" 2>/dev/null; }
expect_code() { if [ "$CODE" = "$1" ]; then PASS=$((PASS+1)); echo "PASS: $2 (HTTP $1)";
  else FAIL=$((FAIL+1)); FAILED_NAMES="$FAILED_NAMES|$2"; echo "FAIL: $2 (want HTTP $1, got $CODE: $BODY)"; fi; }
expect_eq() { if [ "$1" = "$2" ]; then PASS=$((PASS+1)); echo "PASS: $3 ($1)";
  else FAIL=$((FAIL+1)); FAILED_NAMES="$FAILED_NAMES|$3"; echo "FAIL: $3 (want [$2], got [$1])"; fi; }

rm -rf "$DATA"
JIANTI_PORT=$PORT JIANTI_DATA_DIR=$DATA JIANTI_JUDGE_DELAY_SECONDS=5 \
  JIANTI_RATE_LIMIT_GENERAL_PER_MIN=10000 python3 app.py > /tmp/v4test-bindscan-server.log 2>&1 &
SRVPID=$!
sleep 1
kill -0 $SRVPID 2>/dev/null || { echo "服务器没起来"; cat /tmp/v4test-bindscan-server.log; exit 1; }
trap 'kill $SRVPID 2>/dev/null; rm -rf "$DATA"' EXIT

note "0. 注册并校验管理密码"
printf '%s' '{"phone":"13800138001","login_password":"12345678","admin_password":"123456","sms_code":"123456"}' > /tmp/v4test-bindscan-register.json
req POST /users/register -H 'Content-Type: application/json' --data-binary @/tmp/v4test-bindscan-register.json
expect_code 201 "注册 201"
TOKEN=$(jget "d.get('token')")
printf '%s' '{"admin_password":"123456"}' > /tmp/v4test-bindscan-admin.json
req POST /users/admin-password/verify -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' --data-binary @/tmp/v4test-bindscan-admin.json
expect_code 200 "管理密码校验通过"

note "1. scan_payload 能绑 201（旧字段，v3 即有）"
printf '%s' '{"scan_payload":"JianTi-3040059832773436"}' > /tmp/v4test-bindscan-1.json
req POST /terminals/bind-scan -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' --data-binary @/tmp/v4test-bindscan-1.json
expect_code 201 "scan_payload 扫码绑 201"
expect_eq "$(jget "d.get('device_type')")" "苹果" "scan_payload 类型取码首位 3=苹果"
expect_eq "$(jget "d.get('terminal_no')")" 1 "scan_payload 终端编号 1"

note "2. qr_payload 同样能绑 201（v4 新认，文档 B5／App 用的字段）"
printf '%s' '{"qr_payload":"4040059832773436"}' > /tmp/v4test-bindscan-2.json
req POST /terminals/bind-scan -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' --data-binary @/tmp/v4test-bindscan-2.json
expect_code 201 "qr_payload 扫码绑 201"
expect_eq "$(jget "d.get('device_type')")" "鸿蒙" "qr_payload 类型取码首位 4=鸿蒙"
expect_eq "$(jget "d.get('terminal_no')")" 2 "qr_payload 终端编号顺延 2"

note "3. 两字段都空仍 422 scan_no_data（原有行为不变）"
printf '%s' '{"scan_payload":"","qr_payload":""}' > /tmp/v4test-bindscan-3.json
req POST /terminals/bind-scan -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' --data-binary @/tmp/v4test-bindscan-3.json
expect_code 422 "两字段都空 422"
expect_eq "$(jget "d.get('error',{}).get('code')")" "scan_no_data" "两字段都空错误码 scan_no_data"
printf '%s' '{}' > /tmp/v4test-bindscan-3b.json
req POST /terminals/bind-scan -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' --data-binary @/tmp/v4test-bindscan-3b.json
expect_code 422 "两字段都不传 422"
expect_eq "$(jget "d.get('error',{}).get('code')")" "scan_no_data" "两字段都不传错误码 scan_no_data"

note "4. 中文载荷用 --data-binary 发，qr_payload 照样解析"
printf '%s' '{"qr_payload":"扫码结果：JianTi-2864190752386419"}' > /tmp/v4test-bindscan-4.json
req POST /terminals/bind-scan -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' --data-binary @/tmp/v4test-bindscan-4.json
expect_code 201 "中文 qr_payload 扫码绑 201"
expect_eq "$(jget "d.get('device_id')")" "2864190752386419" "中文载荷解析出的 device_id 对"

note "5. 两字段都传时 scan_payload 优先"
printf '%s' '{"scan_payload":"JianTi-1762904831578260","qr_payload":"1938275680415692"}' > /tmp/v4test-bindscan-5.json
req POST /terminals/bind-scan -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' --data-binary @/tmp/v4test-bindscan-5.json
expect_code 201 "双字段同传绑 201"
expect_eq "$(jget "d.get('device_id')")" "1762904831578260" "双字段同传以 scan_payload 为准"

note "6. 终端列表共 4 台，qr_payload 绑的那台在列"
req GET /terminals -H "Authorization: Bearer $TOKEN"
expect_code 200 "终端列表 200"
expect_eq "$(jget "len(d.get('items',[]))")" 4 "列表 4 台终端"

echo
echo "探针结果：PASS $PASS，FAIL $FAIL"
[ -n "$FAILED_NAMES" ] && echo "失败项：$FAILED_NAMES"
[ "$FAIL" = 0 ]
