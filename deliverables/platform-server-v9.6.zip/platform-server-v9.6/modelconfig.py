"""modelconfig.py — 模型管理：官方模型选择／登录 MCP／我的模型（v1）.

规则（手册 v2 §3.6、§4.2–§4.4，接口 B8／B9／C3／C5）：
- 模型配置按家庭组分（主键家庭组 ID），不再是全局单份（修掉骨架毛病）。
  每组记：当前选中线（official 官方模型／mcp 登录 MCP）、线内选中的
  官方模型（5 选 1，JT Lite 2.0 默认）。
- 官方模型 5 个：JT Lite 2.0（默认）、DeepSeek-V4.1-Flash、千问 Qwen 3.8、
  豆包 Seed-2.1-Turbo、Kimi-K3.1-Pro。路由口径未定（U8，部署时定）：
  选模型只记选择、不承诺链路；判题默认走 Qwen 主链路。
- 登录 MCP（U9 已定口径，红线）：必须真校验，不存密码、不建库、
  只留服务端内存临时验证码状态、用完即丢。
  v1 的真实调用路径：
  1) 校验 site_url 须为 https；
  2) 真实 GET 该网站（10 秒超时），不可达 -> 503 mcp_site_unreachable；
  3) 真实 POST 该站的 Open WebUI 登录口 /api/v1/auths/signin
     （{email: account, password}；风险提示原文即“使用 Open WebUI MCP 技术”），
     200 且返回凭证 -> 校验通过（凭证当即丢弃，不存、不记日志、不返回）；
     401／400 -> 401 mcp_auth_failed；
     404／405／501 -> 501 mcp_login_unsupported（该站未提供可识别的登录口，
     本次未做校验——绝不伪造一次校验成功）；
     其它 5xx -> 503。
  captcha_code 若提供，只用于本次调用（随登录请求发出），用完即丢；
  服务端内存临时状态在调用结束后立即删除，不得落盘、不得复用。
  局限：非 Open WebUI 的网站没有统一登录口，v1 只能按上述约定口径
  尝试；哪一段是 stub、为什么，见 README 与缺啥清单。
- “我的模型”暂未开通（U13）：一律 503，不收 Key；内存也不许落盘。
"""
from __future__ import annotations

import json
import urllib.error
import urllib.request

from models import now_iso
from server_config import DEFAULT_MODEL_ID, OFFICIAL_MODELS

MCP_TIMEOUT_SECONDS = 10


class ModelConfigError(Exception):
    def __init__(self, code: str, message: str, status: int = 400):
        super().__init__(message)
        self.code = code
        self.message = message
        self.status = status


def _config(store, family_id: str) -> dict:
    cfg = store.data["model_configs"].get(family_id)
    if cfg is None:
        cfg = {"line": "official", "selected_model": DEFAULT_MODEL_ID,
               "updated_at": None}
        store.data["model_configs"][family_id] = cfg
    return cfg


def get_models_view(store, family_id: str, model_connected: bool) -> dict:
    cfg = _config(store, family_id)
    items = []
    for m in OFFICIAL_MODELS:
        items.append({
            "model_id": m["id"],
            "model_name": m["name"],
            "is_default": m["default"],
            "selected": cfg["selected_model"] == m["id"]
                      and cfg["line"] == "official",
        })
    return {
        "official_models": OFFICIAL_MODELS,
        "items": items,
        "selected_model": cfg["selected_model"],
        "active_model_id": cfg["selected_model"] if cfg["line"] == "official" else None,
        "line": cfg["line"],  # official | mcp
        "mcp_login": {"status": "real_verification",
                      "note": "登录 MCP 做真实网站登录校验；账号密码不存、不建库；"
                              "验证码临时状态只在内存、用完即丢。"},
        "my_model": {"status": "not_enabled",
                     "note": "暂未开通，无入口；Key 存放位置未定，不接收 Key。"},
        "model_connected": model_connected,
    }


def select_model(store, family_id: str, model_id: str | None,
                 line: str | None) -> dict:
    """B9：先点行选中、再点“进入”；line 定线，model_id 定线内模型。
    line=my 暂未开通，400；官方线 model_id 须为 5 个之一。"""
    with store.lock:
        if line not in ("official", "mcp"):
            raise ModelConfigError(
                "invalid_model_line",
                "line 只能是 official（官方模型）或 mcp（登录 MCP）；"
                "my（我的模型）暂未开通。")
        cfg = _config(store, family_id)
        if line == "official":
            ids = [m["id"] for m in OFFICIAL_MODELS]
            if model_id not in ids:
                raise ModelConfigError(
                    "invalid_model",
                    f"官方模型只有 5 个：{', '.join(ids)}。")
            cfg["selected_model"] = model_id
        cfg["line"] = line
        cfg["updated_at"] = now_iso()
        store.save()
        return {"selected_model": cfg["selected_model"],
                "active_model_id": cfg["selected_model"]
                                 if line == "official" else None,
                "line": line,
                "updated_at": cfg["updated_at"]}


def _http_json(method: str, url: str, body: dict | None, timeout: int):
    """最小 HTTP 客户端（标准库）；返回 (status, parsed_json_or_None)。
    绝不记录请求体（可能含密码）。"""
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib.request.Request(
        url, data=data, method=method,
        headers={"Content-Type": "application/json",
                 "User-Agent": "jianti-platform-server-v1"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read()
            try:
                return resp.status, json.loads(raw.decode("utf-8"))
            except (ValueError, UnicodeDecodeError):
                return resp.status, None
    except urllib.error.HTTPError as e:
        return e.code, None
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        raise ModelConfigError(
            "mcp_site_unreachable",
            f"第三方网站不可达（{type(e).__name__}），本次未做校验。", 503)


def mcp_login(store, family_id: str, site_url: str, account: str,
              password: str, captcha_code: str | None = None) -> dict:
    """C3：向第三方网站做真实登录校验。密码只用于本次调用，绝不存、
    不记日志、不进返回体；验证码临时状态用完即丢。"""
    if not site_url or not site_url.startswith("https://"):
        raise ModelConfigError(
            "invalid_site_url", "登录 MCP 的网站须为 https 地址。")
    if not account or not password:
        raise ModelConfigError("missing_credentials", "账号与密码必填。")
    # 验证码临时状态：只在内存留一次调用的份，用完即丢（红线）。
    captcha_key = f"{family_id}|mcp-captcha"
    if captcha_code:
        store.data["mcp_captcha"][captcha_key] = {"code": captcha_code}
    try:
        # 第 1 步：真实 GET 该网站，确认可达（不取 body 内容作判断，只看通不通）。
        _http_json("GET", site_url, None, MCP_TIMEOUT_SECONDS)
        # 第 2 步：真实 POST Open WebUI 登录口（风险提示原文的约定技术）。
        signin_url = site_url.rstrip("/") + "/api/v1/auths/signin"
        body = {"email": account, "password": password}
        if captcha_code:
            body["captcha"] = captcha_code
        status, _payload = _http_json("POST", signin_url, body,
                                      MCP_TIMEOUT_SECONDS)
        if status == 200:
            # 校验通过；第三方返回的凭证当即丢弃，不存、不返回。
            return {"logged_in": True, "site_url": site_url,
                    "verified_at": now_iso(),
                    "note": "本次为真实网站登录校验；第三方返回的凭证已丢弃，未保存。"}
        if status in (400, 401, 403):
            raise ModelConfigError(
                "mcp_auth_failed", "第三方账号或密码不对，本次校验未通过。", 401)
        if status in (404, 405, 501):
            raise ModelConfigError(
                "mcp_login_unsupported",
                "该网站未提供可识别的登录接口（Open WebUI 登录口不存在），"
                "本次未做校验，未伪造成功。", 501)
        raise ModelConfigError(
            "mcp_site_error",
            f"第三方网站返回 HTTP {status}，本次未做校验。", 503)
    finally:
        # 验证码临时状态用完即丢，不得落盘、不得复用。
        store.data["mcp_captcha"].pop(captcha_key, None)


def my_model_rejected() -> None:
    raise ModelConfigError(
        "my_model_not_enabled",
        "“我的模型”暂未开通：启用时间未定，Key 存放位置未定，"
        "本次不接收、不保存任何 Key。", 503)
