"""store.py — 内存存储 + 分实体 JSON 快照（平台服务器端 v1，标准库 only）.

相对探针骨架的改动（手册 v2 §1.3、§6.1，架构 §4.1）：
- 每实体一张快照文件，放在服务端数据目录下（默认与代码同目录的 data/，
  可由环境变量 JIANTI_DATA_DIR 覆盖）；文件清单与主键见 README。
- 快照损坏 -> 启动失败并告警，不自动丢数据重建，等人工处理。
  探针的“损坏静默按空库启动”已修掉：缺文件按空实体处理（首次运行），
  但文件存在却解析失败 / 结构不对 -> 抛 SnapshotCorruptError，
  app.py 捕获后打印到 stderr 并以非 0 退出码退出。
- 写快照失败不再吞掉：save() 抛 OSError，调用方按 500 处理并记日志。
  写策略仍是先写同目录临时文件、写完原子改名；多文件先全部写临时文件
  再逐个改名，尽量不留“改了一半”的窗口。
- 会话 token 与待拉取通知队列不落盘（内存 only，重启失效）；
  MCP 临时验证码状态同样只在内存、用完即丢（见 modelconfig.py）。
- 快照里只有密码哈希，没有任何明文密码；Key / token 一律不进快照。
"""
from __future__ import annotations

import json
import os
import threading

DEFAULT_DATA_DIR = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "data")

# 文件清单：文件名 -> store.data 里对应的顶层键（一个文件可含多个相关段，
# 但每个段只属于一个文件；段名即实体名）。
SNAPSHOT_FILES = [
    ("accounts.json", ["users", "users_by_phone"]),
    ("family_groups.json", ["families"]),
    ("members.json", ["members"]),
    ("devices.json", ["terminals"]),
    ("bindings.json", ["bindings"]),
    ("card_ledgers.json", ["card_state"]),
    ("card_transactions.json", ["ledger"]),
    ("applications.json", ["applications"]),
    ("idempotency.json", ["idempotency"]),
    ("solve_sessions.json", ["jobs", "unlocked"]),
    ("usage_records.json", ["records"]),
    ("server_configs.json", ["server_configs"]),
    ("model_configs.json", ["model_configs"]),
    ("weather_memo.json", ["temperature", "memo"]),
    ("invites.json", ["invites"]),
]
# 加载顺序即清单顺序（手册 §1.3：启动时按清单顺序加载快照恢复内存）。
# 不落盘的段：sessions（登录会话，重启失效）、push_queue（待拉取通知队列，
# 手册 §1.3：可不落盘）、mcp_captcha（MCP 临时验证码状态，用完即丢）。


class SnapshotCorruptError(Exception):
    """快照文件损坏：启动失败，等人工处理，绝不静默按空库启动。"""


class Store:
    def __init__(self, data_dir: str | None = None):
        self.data_dir = data_dir or os.environ.get(
            "JIANTI_DATA_DIR", DEFAULT_DATA_DIR)
        self.lock = threading.RLock()
        self.data = self._empty()
        self.load_snapshot()

    @staticmethod
    def _empty() -> dict:
        return {
            "users": {},          # user_id -> user dict
            "users_by_phone": {},  # phone -> user_id
            "sessions": {},       # token -> {user_id, admin_verified, created_at}（内存 only）
            "families": {},       # family_id -> family dict
            "members": {},        # "family_id|member_no" -> member dict
            "terminals": {},      # device_id -> device dict（设备登记）
            "bindings": {},       # device_id -> binding dict（设备 <-> 家庭组，一对一）
            "jobs": {},           # job_id -> job dict
            "applications": {},   # application id -> application dict
            "idempotency": {},    # "family_id|endpoint|key" -> {status, body}
            "ledger": [],         # 卡流水（每笔留痕）
            "records": [],        # 使用记录（只记真实事件）
            "card_state": {},     # family_id -> {balance, advanced_today, granted_today, used_today, date}
            "unlocked": {},       # "family_id|batch_id|question_index" -> job_id
            "server_configs": {},  # family_id -> {mode, custom_address, updated_at}（按家庭组分）
            "model_configs": {},   # family_id -> {line, selected_model, updated_at}（按家庭组分）
            "push_queue": [],     # 待拉取通知队列（内存 only，不落盘）
            "temperature": None,  # 无数据 -> None，接口返回 ---°C
            "memo": "",           # 无数据 -> 空字符串
            "invites": {},        # invite_code -> {family_id, inviter_member_no, inviter_role, created_at}
            "mcp_captcha": {},    # 一次性验证码临时状态（内存 only，用完即丢）
        }

    # ---- 快照 ----
    def _file_path(self, filename: str) -> str:
        return os.path.join(self.data_dir, filename)

    def load_snapshot(self) -> None:
        """按清单顺序加载；文件缺失按空实体处理，文件损坏则抛错、启动失败。"""
        os.makedirs(self.data_dir, exist_ok=True)
        for filename, sections in SNAPSHOT_FILES:
            path = self._file_path(filename)
            if not os.path.exists(path):
                continue  # 首次运行：该实体尚无快照，按空处理
            try:
                with open(path, encoding="utf-8") as f:
                    payload = json.load(f)
            except (json.JSONDecodeError, UnicodeDecodeError, OSError) as e:
                raise SnapshotCorruptError(
                    f"快照损坏：{filename} 无法解析（{e}）。"
                    "启动失败，请人工处理该文件（修复或备份后删除），"
                    "服务端不会自动丢数据重建。")
            if not isinstance(payload, dict):
                raise SnapshotCorruptError(
                    f"快照损坏：{filename} 顶层不是 JSON 对象。启动失败，"
                    "请人工处理该文件，服务端不会自动丢数据重建。")
            with self.lock:
                for section in sections:
                    value = payload.get(section)
                    if value is None:
                        continue  # 该文件里没有这一段，按空处理
                    expected = self._empty()[section]
                    if not isinstance(value, type(expected)):
                        raise SnapshotCorruptError(
                            f"快照损坏：{filename} 里 {section} 的类型不对"
                            f"（应为 {type(expected).__name__}）。"
                            "启动失败，请人工处理该文件，"
                            "服务端不会自动丢数据重建。")
                    self.data[section] = value

    def save_snapshot(self) -> None:
        """每次状态变更后同步写全部实体快照；失败即抛错，不静默吞掉。"""
        with self.lock:
            os.makedirs(self.data_dir, exist_ok=True)
            tmp_paths = []
            try:
                for filename, sections in SNAPSHOT_FILES:
                    payload = {s: self.data[s] for s in sections}
                    tmp = self._file_path(filename + ".tmp")
                    with open(tmp, "w", encoding="utf-8") as f:
                        json.dump(payload, f, ensure_ascii=False, indent=2)
                    tmp_paths.append((tmp, self._file_path(filename)))
                for tmp, dest in tmp_paths:
                    os.replace(tmp, dest)
            except OSError:
                for tmp, _ in tmp_paths:
                    try:
                        os.remove(tmp)
                    except OSError:
                        pass
                raise

    # ---- 通用 ----
    def save(self) -> None:
        """写快照；失败抛 OSError（调用方按 500 处理并记日志，不吞掉）。"""
        self.save_snapshot()
