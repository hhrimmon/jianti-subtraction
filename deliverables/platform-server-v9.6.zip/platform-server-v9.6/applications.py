"""applications.py — 申请单：创建 / 待批 / 批准 / 撤回（服务端统一管，v1）.

规则（手册 v2 §2.4、§6.1，PRD F3／F4，接口 A6／A7／B1–B3）：
- 发完停留在领取页，不自动回思路页；只显示“申请已发送。”。
- 取消 = 撤回，家长端不得再批；只关弹窗不撤回（那是客户端行为，
  不发请求，服务端无动作）。
- 申请一次是一次，不累计次数；家长不批也不堵作业。
- 批准时先选按张还是按倍、再填数字（PRD 3.5／6.5）。
- 幂等键（v1 新增，修掉骨架毛病）：重发沿用同一 Idempotency-Key，
  服务端按幂等键去重，不重复建单、不重复批卡（网关层在调本模块前
  查 idempotency 表；本模块另记 application.idempotency_key 备查）。
- 同一终端／同一题已有待批单时，不同幂等键的重发报 409
  application_duplicate_pending（接口 A6 的 40903），不新建。
- 申请消息是消息记录＋拉取：创建成功后只进本机待拉取通知队列
  （见 push.py），不建推送通道。
"""
from __future__ import annotations

import uuid

from cards import grant_cards
from models import new_application, new_record, now_iso
from push import enqueue_application_push
from server_config import GRANT_COUNT_MAX, GRANT_RATIO_MAX


class ApplicationError(Exception):
    def __init__(self, code: str, message: str, status: int = 400):
        super().__init__(message)
        self.code = code
        self.message = message
        self.status = status


def public_application(app: dict) -> dict:
    return {
        "application_id": app["id"],
        "id": app["id"],
        "family_id": app["family_id"],
        "terminal_id": app.get("terminal_id"),
        "question_id": app.get("question_id"),
        "requested": app.get("requested") or {},
        "status": app["status"],
        "granted": app.get("granted"),
        "created_at": app["created_at"],
        "decided_at": app.get("decided_at"),
    }


def create_application(store, family_id: str, terminal_id: str | None = None,
                       requested: dict | None = None,
                       idempotency_key: str | None = None,
                       question_id: str | None = None) -> dict:
    with store.lock:
        if family_id not in store.data["families"]:
            raise ApplicationError("family_not_found", "家庭组不存在。", 404)
        if terminal_id:
            b = store.data["bindings"].get(terminal_id)
            if b is None or b["family_id"] != family_id:
                raise ApplicationError(
                    "terminal_not_bound", "申请单的终端未绑定到当前家庭账号。", 403)
        # 同一终端／同一题已有待批单：不新建（接口 A6 40903）。
        for a in store.data["applications"].values():
            if (a["family_id"] == family_id and a["status"] == "pending"
                    and a.get("terminal_id") == terminal_id
                    and a.get("question_id") == question_id):
                raise ApplicationError(
                    "application_duplicate_pending",
                    "已有一张申请在等审批。", 409)
        app = new_application(f"app-{uuid.uuid4().hex[:12]}", family_id,
                              terminal_id, requested or {},
                              idempotency_key=idempotency_key,
                              question_id=question_id)
        store.data["applications"][app["id"]] = app
        store.data["records"].append(new_record(
            family_id, "application",
            {"application_id": app["id"], "status": "pending",
             "terminal_id": terminal_id}))
        enqueue_application_push(store, app)
        store.save()
        return public_application(app)


def list_applications(store, family_id: str, status: str | None = None,
                      page: int = 1, page_size: int = 20) -> dict:
    """B2 待批列表：status 默认 pending；撤回后 pending 列表不再返回该单。"""
    with store.lock:
        items = [a for a in store.data["applications"].values()
                 if a["family_id"] == family_id
                 and (status is None or a["status"] == status)]
        items.sort(key=lambda a: a["created_at"], reverse=True)
        total = len(items)
        start = max(0, (page - 1) * page_size)
        return {"items": [public_application(a)
                          for a in items[start:start + page_size]],
                "total": total, "page": page, "page_size": page_size}


def _normalize_grant(grant_type: str | None, value) -> tuple[str, int]:
    """grant_type 兼容两种写法：骨架 count／ratio 与接口文档 cards／times。"""
    mapping = {"count": "count", "cards": "count",
               "ratio": "ratio", "times": "ratio"}
    gt = mapping.get(grant_type or "")
    if gt is None:
        raise ApplicationError(
            "invalid_grant_type",
            "批准须先选按张（count）还是按倍（ratio）。")
    if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
        raise ApplicationError("invalid_grant_value", "批准张数/倍数须为正整数。")
    if gt == "count" and value > GRANT_COUNT_MAX:
        raise ApplicationError(
            "invalid_grant_value",
            f"按张批准一次最多 {GRANT_COUNT_MAX} 张。")
    if gt == "ratio" and value > GRANT_RATIO_MAX:
        raise ApplicationError(
            "invalid_grant_value",
            f"按倍批准倍率最大 {GRANT_RATIO_MAX}。")
    return gt, value


def approve_application(store, app_id: str, grant_type: str,
                        value: int, approver_member_no: int | None = None) -> dict:
    """批准：grant_type 为 "count"（按张）或 "ratio"（按倍），value 为数字。

    按张：发 value 张；按倍：发 每日张数 x value 张（与预支上限同口径）。
    撤回/已决的单不得再批。重复审批不重复记账（网关层幂等键兜底，
    本模块状态机亦拦截）。
    """
    with store.lock:
        app = store.data["applications"].get(app_id)
        if app is None:
            raise ApplicationError("application_not_found", "申请单不存在。", 404)
        if app["status"] == "withdrawn":
            raise ApplicationError("application_withdrawn",
                                   "申请单已撤回，家长端不得再批。", 409)
        if app["status"] != "pending":
            raise ApplicationError("application_decided",
                                   f"申请单已是 {app['status']} 状态，不得重复审批。", 409)
        gt, v = _normalize_grant(grant_type, value)
        fam = store.data["families"][app["family_id"]]
        cards = v if gt == "count" else fam["daily_cards"] * v
        grant_cards(store, app["family_id"], cards, ref=app["id"],
                    member_no=approver_member_no)
        app["status"] = "approved"
        app["granted"] = {"grant_type": gt, "value": v, "cards": cards}
        app["decided_at"] = now_iso()
        store.data["records"].append(new_record(
            app["family_id"], "application",
            {"application_id": app["id"], "status": "approved", "cards": cards,
             "member_no": approver_member_no}))
        store.save()
        out = public_application(app)
        out["balance"] = store.data["card_state"][app["family_id"]]["balance"]
        return out


def reject_application(store, app_id: str) -> dict:
    """家长点叉 = 不批（PRD 3.5：对号批 / 叉不批）。"""
    with store.lock:
        app = store.data["applications"].get(app_id)
        if app is None:
            raise ApplicationError("application_not_found", "申请单不存在。", 404)
        if app["status"] == "withdrawn":
            raise ApplicationError("application_withdrawn",
                                   "申请单已撤回，不得再操作。", 409)
        if app["status"] != "pending":
            raise ApplicationError("application_decided",
                                   f"申请单已是 {app['status']} 状态。", 409)
        app["status"] = "rejected"
        app["decided_at"] = now_iso()
        store.data["records"].append(new_record(
            app["family_id"], "application",
            {"application_id": app["id"], "status": "rejected"}))
        store.save()
        return public_application(app)


def withdraw_application(store, app_id: str) -> dict:
    """撤回：只有待批的单能撤回；撤回后家长端不得再批。"""
    with store.lock:
        app = store.data["applications"].get(app_id)
        if app is None:
            raise ApplicationError("application_not_found", "申请单不存在。", 404)
        if app["status"] != "pending":
            raise ApplicationError("application_not_withdrawable",
                                   f"申请单已是 {app['status']} 状态，不能撤回。", 409)
        app["status"] = "withdrawn"
        app["decided_at"] = now_iso()
        store.data["records"].append(new_record(
            app["family_id"], "application",
            {"application_id": app["id"], "status": "withdrawn"}))
        store.save()
        return public_application(app)
