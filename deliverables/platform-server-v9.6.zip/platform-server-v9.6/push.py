"""push.py — 待拉取通知队列（拉取，不建推送通道；平台服务器端 v1）.

规则（手册 v2 §1.4、§4.5，接口 C4；已定：全部拉取）：
- 孩子发申请后，手机任何一屏顶部应弹推送条；点主体跳第 13 屏，
  点条上“批准”当场批完；点 x 只关条不撤回；在第 13 屏时不弹条。
- 不建推送通道：申请创建时只把一条通知写进本机内存队列，供
  GET /push/pending 拉取；不发短信、不调任何外部服务。
- 文件名与端点名沿用旧名 push.py／/push/pending，不改名，只改语义说明
  （手册附录 C 第 12 条）。
- 队列不落盘（手册 §1.3：推送投递记录可不落盘），重启后清空。
"""
from __future__ import annotations

from models import now_iso


def enqueue_application_push(store, application: dict) -> dict:
    note = {
        "id": application["id"],
        "type": "application",
        "family_id": application["family_id"],
        "application_id": application["id"],
        "title": "有新的解题卡申请",
        "body": "孩子申请了解题卡，点主体去第 13 屏审批，点批准当场批完。",
        "created_at": now_iso(),
        "delivered": False,  # 拉取队列：骨架不追踪已读，恒为 False
    }
    store.data["push_queue"].append(note)
    return note


def pending_pushes(store, family_id: str | None = None) -> list:
    out = store.data["push_queue"]
    if family_id:
        out = [p for p in out if p["family_id"] == family_id]
    return out
