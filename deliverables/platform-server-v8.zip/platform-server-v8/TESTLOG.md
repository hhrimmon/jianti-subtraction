# 平台服务器端 v8 测试日志（TESTLOG）

> 时间：2026-11-18。环境：本机容器，Python 3 标准库，无第三方依赖。
> 口径：只写实测结果，token 值一律打码；演示账号凭证值不出现在这里，只写“演示账号”。
> 结论先行：冒烟 **PASS 217，FAIL 0**（v7 基线全过）；测试模式探针仍通过（**PASS 46，FAIL 0**）；A4 顶层字段新探针 **PASS 36，FAIL 0**。
> v8 相对 v7 的改动：只修 A4 偏差两处（Nyx 538，见 §17）；只动 `gateway.py`、`cards.py` 与测试／文档，v7 目录与 v7 包未动。

## §17 A4 偏差补齐（v8，Nyx 538）

- 改动：`gateway.py`：版本号 8.0.0、服务名 `jianti-platform-server-v8`；`_run_judge` 建 `job["questions"]` 时每题写死 `question_id`（`job_id-q<题号>`，如 `job-b7bbe3c7ae98-q1`，落快照、同一题始终同一个值）；`_solve_view` 轮询 question 视图每题补 `question_id` 与 `question_index`（从 1 起，接口 A2 约定；`index` 仍保留 0 起）。`cards.py`：新增 `_deduct_top_level()`，扣卡返回顶层补 `unlocked`／`question_id`／`answer`（取本次解锁的那道题，与 job 内一致；已解锁再点与幂等重放也一样带）；`_job_view` 的 questions 同款补 `question_id`／`question_index`。A3 查卡不用改：它本来就按 `question_id` 查解锁状态，现与轮询给出的 ID 对得上（探针 §D 验证）。
- 冒烟 `bash tests/run_smoke.sh`：**PASS 217，FAIL 0**（与 v7 相同，只改 service 名断言与临时名 `v7test` → `v8test`）。
- 探针 `bash tests/probe_test_mode.sh`：**PASS 46，FAIL 0**（与 v7 相同，只改 service 名断言与临时名）。
- 新探针 `bash tests/probe_a4_top_level.sh`：**PASS 36，FAIL 0**（端口 18013，测试模式开模拟判题）：轮询 question[0].question_id=`<job_id>-q1`、question_index=1、未解锁前 answer 为 null；查卡用该 question_id 认得题（unlocked=false、can_deduct=true）；扣卡顶层 unlocked=true、question_id 与轮询一致、answer 与 job.answer 相同（含“测试模拟”标记）、余额 4；再轮询 question_id 不变、answer 与扣卡顶层一致；重复扣卡不扣（余额仍 4）且顶层字段仍齐全一致；同一 Idempotency-Key 重放回首次结果、余额仍 4。

## §16 演示账号测试模式（v7，Nyx 515）

- 改动：`users.py` 新增演示账号比对（仅测试模式）：`register(..., test_mode)` 演示凭证全对且已建号时重复注册幂等 201（直接发新会话，家庭组 ID 不变；未建号走正常建号流程）；`login(..., test_mode)` 演示凭证对且未建号时按演示凭证现场建号（虚拟家庭组、管理员，与 `register()` 非邀请路径同款），已建号直接发新会话、已存哈希不动（放行不覆写）；`verify_admin_password(..., test_mode)` 演示账号的管理密码按演示凭证放行。凭证不对时一律走正常流程（401／409 不变），非演示账号流程不受影响；`test_mode` 默认 `False`，关时三个函数与 v6 一字不差。`gateway.py`：版本号 7.0.0、服务名 `jianti-platform-server-v7`；四个注册／登录路由与管理密码校验路由传 `test_mode=TEST_MODE`；`/auth/send-code` 测试模式开且是演示账号时返回 `{"sent": true, "test_mode": true, "sms_code_stub": true}`（不真发短信，响应不带码值），其余仍 503。凭证值只出现在 `users.py` 的比对常量处；冒烟脚本运行时从 `users.py` 读值，不把值写进脚本；文档、日志、汇报里只写“演示账号”。
- 冒烟 `bash tests/run_smoke.sh`：**PASS 217，FAIL 0**——§0–§23 与 v6 相同（187 项，service 名断言改成 `jianti-platform-server-v7`，临时名 `v6test` → `v7test`）；新增 §24 演示账号 30 项全过：开实例（端口 18005，`JIANTI_TEST_MODE=1`）：health 与 `test_mode=true`、发码 200（`sent=true`、明标 `sms_code_stub=true`、响应不带码值）、非演示账号发码仍 503、未建号直接登录 200（现场建号，家庭组 8 位、管理员、`next_step` 再输管理密码）、管理密码校验 200、错管理密码 401、重复注册 201 两次且家庭组 ID 不变、错登录密码 401、错凭证注册 409、查卡 200 余额 5、普通账号注册／重复 409／登录 200 不受影响；关实例（端口 18006，默认关）：`test_mode=false`、发码 503、未建号登录 401（不现场建号）、正常注册 201、注册后登录 200、重复注册 409、管理密码校验 200（正常哈希比对）。
- 探针 `bash tests/probe_test_mode.sh`：**PASS 46，FAIL 0**（与 v6 相同，只改 service 名断言与临时名 `v6test` → `v7test`）。

---

## v6 原记录（2026-11-18，保留）

# 平台服务器端 v6 测试日志（TESTLOG）

> 时间：2026-11-18。环境：本机容器，Python 3 标准库，无第三方依赖。
> 口径：只写实测结果，token 值一律打码；演示值（手机号 13800138000、设备 ID）只作走流程用的数，不作验收依据。
> 结论先行：冒烟 **PASS 187，FAIL 0**（与 v5 基线相同，v6 未新增冒烟断言，测试模式默认关；关模式行为由新探针覆盖）；测试模式探针通过（**PASS 46，FAIL 0**）。
> v6 相对 v5 的改动：新增测试模式开关 `JIANTI_TEST_MODE`（默认关，Nyx 498/500，见 §15）；冒烟 service 名断言改成 `jianti-platform-server-v6`、临时名 `v5test` → `v6test`。待 dsh 回归。

## §15 测试模式：测试机认绑定＋模型模拟返回（v6，Nyx 498/500）

- 改动：`gateway.py` 新增模块级 `TEST_MODE`（`JIANTI_TEST_MODE=1` 才开，默认关；启动日志与 `GET /health` 各带 `test_mode`）；`_post_solve` 绑定门禁：测试模式开时格式合法的 16 位设备号按已绑定处理、不再 403（格式白名单首位 0–4 不动，非法格式仍 403；不写绑定记录、不落盘）；`_run_judge`：测试模式开且无真 Key 时调 `judge.mock_judge_result()`（一道固定假题，思路／答案明标“【测试模拟数据，非真实模型输出】”），成功路径与真实判题同一条（五阶段、记录、扣卡全照常），job 打 `mock=true`／`result_source="mock"`（`models.py` `new_job` 默认 `false`／`"real"`，`public_job` 透出）；有真 Key 时仍走真实判题；测试模式关时两处行为与 v5 一字不动。版本号 6.0.0、服务名 `jianti-platform-server-v6`。
- 探针 `bash tests/probe_test_mode.sh`（开实例端口 18011、数据 `/tmp/v6test-mode-on`；关实例端口 18012、数据 `/tmp/v6test-mode-off`，跑完自清）：**PASS 46，FAIL 0**——开实例：health 与启动日志 `test_mode=true`、演示值 `JianTi-2864190752386419` 扫码绑 201（安卓、终端编号 1）、未绑定的 App 生成号 `2864190752386420` 发网关 202、轮询到 done（五阶段全 done、`mock=true`、`result_source=mock`、思路带“测试模拟”标记、未解锁前答案不下发）、终端列表只有扫码绑的 1 台（未写假绑定记录）、扣卡 200（余额 5→4、答案解锁且带标记）、`/records` 里 `solve_success`／`deduct`／`thinking` 各 1 条、首位 9 的非法格式终端仍 403；关实例：health 与启动日志 `test_mode=false`、未绑定终端 403 `terminal_not_bound`、已绑定终端 `/solve` 202 后轮询到 failed（`model_not_connected`、`mock=false`、`result_source=real`、`failure_reason=model_unavailable`）。
- 冒烟重跑：**PASS 187，FAIL 0**（与 v5 基线相同；v6 未新增冒烟断言，24 节逐节计数与 v5 相同，service 名断言改成 `jianti-platform-server-v6`，临时名 `v5test` → `v6test`；§7 未绑定 403 与 §8 `model_not_connected` 两处断言在默认关模式下仍过）。
- 探针脚本首版有一个脚本自身 bug：`muse.write` 落盘时 `[ ... ]` 断言里的 `]` 前空格被吞（`if [ "$CODE" = "$1"];`），致 `[: missing ']'`、42 项误判 FAIL（响应体本身全对）；已逐行补回空格重跑，46/0 通过。教训：新探针先跑一遍看计数，计数异常先查脚本再查服务。

---

## v5 原记录（2026-11-17，保留）

## §13 扫码绑 scan_payload／qr_payload 双认（v4，Nyx 284①）

- 改动：`gateway.py` 约 441 行 `POST /terminals/bind-scan` 由 `b.get("scan_payload") or ""` 改成 `b.get("scan_payload") or b.get("qr_payload") or ""`；两者都空仍传 `""`，`parse_scan_payload` 照旧 422 `scan_no_data`。载荷解析（去空格、`(\d{16})` 匹配、首位白名单）与 `bind_scan` 逻辑不动；文档与 App 都不动。
- 探针 `bash tests/probe_bind_scan_payload.sh`（端口 18005、临时数据目录 `/tmp/v4test-bindscan-data`，跑完自清）：**PASS 18，FAIL 0**——`scan_payload` 绑苹果 201（终端编号 1）、`qr_payload` 绑鸿蒙 201（终端编号顺延 2）、两字段都空与都不传均 422 `scan_no_data`、中文载荷（`扫码结果：JianTi-2864190752386419`，`--data-binary` 发）绑安卓 201 且解析出的 device_id 对、双字段同传以 `scan_payload` 为准、终端列表共 4 台。
- 冒烟重跑：**PASS 187，FAIL 0**（与 v3 基线相同；v4 未新增冒烟断言，24 节逐节计数与 v3 相同，service 名断言改成 `jianti-platform-server-v4`，临时名 `v3test` → `v4test`）。
- README 限流表（v4-2，Nyx 232 定法②）：`JIANTI_RATE_LIMIT_GENERAL`／`JIANTI_RATE_LIMIT_SOLVE` 补 `_PER_MIN` 后缀；代码本来就读带后缀的变量名（`gateway.py:83-86`、`server_config.py:67-68`），**代码不动**，冒烟 §23 限流断言仍过。

## §14 keep-alive 下鉴权报错后残留 body 顶坏下一请求（v5，Nyx 329 定法②）

- 根因：`gateway.py` `protocol_version` 是 HTTP/1.1（默认 keep-alive）；`_dispatch` 里鉴权（`_auth_user`／`_require_admin_session`，行 172-195）在 `_read_json()` 之前抛错，401/403 错误响应发出时请求体还躺在 socket 缓冲里，同一连接下一个请求就从残留 body 处开始解析。实测：同一连接先 POST /config/server 无 token 得 401，紧接 POST /auth/register 得 400 Bad request syntax；403 路（POST /auth/passwords 未验管理密码后接 GET /health）同样；/solve 未绑定终端 403 后接 GET /health 得 501（残留 JPEG 被当成请求行）。trae 报 v3 上是 501，v4 实测是 400，同一根因。
- 修法（Nyx 329 定法②，报错前排空）：只动 `gateway.py`——`_dispatch` 异常出口发错误响应前调 `_drain_body()` 按 Content-Length 排空未读 body；`_read_json()` 与 `/solve` 的 `rfile.read` 各记已读字节数（`self._body_read`，`_dispatch` 入口清零），已读完的不再排；`/solve` 图片 body 只在业务里读，入口不预读、不进内存。版本号 5.0.0、服务名 `jianti-platform-server-v5`。
- 探针 `python3 tests/probe_keepalive.py [SERVER_DIR] [PORT]`（端口 18006、临时数据目录 `/tmp/v5test-keepalive-data`，跑完自清，裸 `http.client` 同一连接连发两请求）：v4 上复现 **PASS 9，FAIL 3**（A2/B2 得 400，C2 得 501）；v5 上 **PASS 12，FAIL 0**——A 路 401 后注册 201、B 路 403 后 GET /health 200、C 路 /solve 403 后 GET /health 200、D 路正常已读 body 后同一连接继续 200。
- 冒烟重跑：**PASS 187，FAIL 0**（与 v4 基线相同；v5 未新增冒烟断言，24 节逐节计数与 v4 相同，service 名断言改成 `jianti-platform-server-v5`，临时名 `v4test` → `v5test`）。
- 扫码绑双字段探针重跑：**PASS 18，FAIL 0**（v4 功能无退化）。

---

## v3 原记录（2026-11-17，保留）

## §9 429 带 `Retry-After: 5`（v3，RECHECK #10）

冒烟 §23（限流）新增 1 项断言：第 121 次通用请求回 429 后再打一次 `/health`，响应头 `Retry-After: 5`。实测通过（见 §11 冒烟重跑：`PASS: 429 带 Retry-After: 5 (5)`）。

- 其它状态码不带该头：实现在 `_send` 里只对 `status == 429` 补头；冒烟其余 186 项全部是 200／201／400／401／403／404／409／413／415／503 等非 429 响应，均通过，未见多余的头导致断言失败。
- 接口文档不用改：429 行“等 `Retry-After` 秒（无该头时等 5 秒）”的兜底句留着；现在服务端发头，终端走“等 `Retry-After` 秒”分支，值仍是 5，重试语义不变。

## §10 僵尸 job 启动扫尾探针（v3，RECHECK #15）

探针 `tests/probe_stale_jobs.py`（进程内跑，不起服务、不需要 Qwen Key）：往快照里写 1 个 1 小时前的 processing job、1 个刚建的 processing job、1 个 1 小时前的 done job；冷重启加载快照后调 `gateway.reap_stale_processing_jobs`，再断言：

- 僵尸 job：`status=failed`，`failure_reason=process_interrupted`，`error={'code': 'process_interrupted', 'message': '服务端重启前该任务未完成，已标记失败，请重拍。'}`。
- 终态 usage 记录：`solve_failed` 1 条，`detail={'job_id': 'job-probe-stale', 'error': 'process_interrupted', 'terminal_id': '2040059832773436'}`。
- 新 job：仍 `processing`，不受影响；旧 done job：仍 `done`，不动。
- 快照落盘：扫尾后重载 Store，僵尸 job 仍是 failed／`process_interrupted`。
- 探针结果：**PASS**（退出码 0）。新码 `process_interrupted` 不撞已定六个码；`cancelled` 的 job 不在 processing，不会被扫尾误伤。

## §11 冒烟重跑（v3）：PASS 187，FAIL 0

`bash tests/run_smoke.sh`（临时端口 18001、临时快照目录 `/tmp/v3test-data`，跑完自清；v3 改动后跑一次，187/0）。相对 v2 脚本的改动：§23 新增 429 带 `Retry-After: 5` 断言 1 项；service 名断言改成 `jianti-platform-server-v3`；临时名 `v2test` → `v3test`。24 节逐节计数与 v2 相同（见下方 v2 原记录 §8），另加 §23 新断言 1 项，无一节失败。并发探针（`tests/conc_probe.py`）重跑通过：第一波 10 路同键 distinct job_id=1，第二波新键 distinct job_id=1。no_question 改名探针重跑通过。

## §12 首位 5–9 白名单＋绑定容忍空格（v3 补三处之①②，Nyx 189②③，RECHECK #12）

- 白名单：`binding.py` `_DEVICE_RE` 改为 `^[0-4]\d{15}$`，首位 5–9 手动／扫码绑一律 400 `invalid_device_id`；`DEVICE_TYPE_NAMES` 里 5–9 的“预留”标注留着当文档说明。
- 容忍空格：手动绑网关层早有去空格（v2 即有，`gateway.py` 约 433 行）；实测发现扫码口真缺口——`parse_scan_payload` 用 `(\d{16})` 连续匹配，带空格载荷报 422 `scan_no_device_id`（修前实测：`JianTi-2864 1907 5238 6419` 与 `2864 1907 5238 6419` 均 422）。v3 修：`parse_scan_payload` 先去空格再解析；修后两组载荷均 201 绑上。探针新增 §4b 覆盖带空格扫码绑。
- 探针 `bash tests/probe_device_id_whitelist.sh`：**PASS 29，FAIL 0**（首位 5–9 手动绑各 2 项、扫码首位 9 各 2 项、首位 0–4 各 1–2 项、带空格手动绑 2 项、新增带空格扫码绑 2 项、列表无 5/9 号 2 项）。
- 冒烟重跑：**PASS 187，FAIL 0**（改动后跑一次，见 §11）。
- 撕裂写入：只记清单、不改代码（见 `缺啥清单-服务器端-v3.md` §四第 11 条与共享 `缺啥清单-20261116.md` 第 36 条）。

---

## v2 原记录（2026-11-16–17，保留）

## §6 同键并发竞态探针：v1 的真缺陷，v2 已修

探针 `tests/conc_probe.py`（起临时实例端口 18010、判题延迟 0、限流调高）：注册＋绑终端后，10 路并发用同一个 `Idempotency-Key` 打 `POST /solve`，再用第二个键打 5 路。请求体分两段发（先发一半、屏障对齐、再同时发后一半），让所有并发路同时越过旧代码的预检点——否则 10 路在 v1 上也撞不上，探针测不出东西。

| 实例 | 第一波（10 路同键） | 第二波（5 路新键） | 结论 |
|---|---|---|---|
| v1 副本（`/tmp/v1-race-check`，只为对照，不改 v1 目录） | 全是 202，但 distinct job_id=**10** | distinct job_id=**5** | **缺陷实锤**：预检在锁外，两路同时漏过预检各建一个 job |
| **v2** | 全是 202，distinct job_id=**1**（`job-50645e558cd6`） | distinct job_id=**1**（`job-612968c7cdeb`，与第一波不同） | **已修**：查幂等→建 job→写记录整段进 `store.lock`，判题线程锁内起 |

其余五口（`/cards/deduct`、`/cards/advance`、`POST /applications`、approve、reject）的预检也已同理挪进锁内（`store.lock` 是 RLock，业务函数内部再加锁不死锁；冒烟 §10–§13 的串行幂等断言仍全过）。待 dsh 用 conc_probe2 复测。

## §7 no_question 改名探针：旧名 `no_question_detected` 已清

探针 `tests/probe_no_question.py`（进程内跑，不起服务、不需要 Qwen Key）：建临时 Store＋job，把 `judge.judge_image` 桩成返回空 `results`，直接调 `gateway._run_judge`，再断言 job 与 `solve_failed` 记录。

- job：`status=failed`，`error={'code': 'no_question', 'message': '照片里没有识别出可判的数学题。'}`，`failure_reason=no_question`。
- 记录：`solve_failed`，`detail={'job_id': 'job-probe-noq', 'error': 'no_question', ...}`。
- 旧名 `no_question_detected` 在 job 与记录里均不再出现；代码里已无该值（探针与变更记录里只剩作为旧名引用的字符串）。
- 冒烟无法覆盖这条分支（无 Qwen Key，走不到空 `results`）；接口文档、架构文档、主缺啥清单本来就写 `no_question`，**文档不动**。

## §8 冒烟重跑（v2）：PASS 186，FAIL 0

`bash tests/run_smoke.sh`（临时端口 18001、临时快照目录 `/tmp/v2test-data`，跑完自清；v2 改动后跑一次，186/0）。相对 v1 脚本的改动：§17 MEMO 设置含中文的 `-d` 请求体改 `--data-binary @/tmp/v2test-memo.json`（Windows GBK，Nyx 146 定）；service 名断言改成 `jianti-platform-server-v2`；临时名 `v1test` → `v2test`。24 节逐节计数与 v1 相同（见下方 v1 原记录 §0 表），无一节失败。

---

## v1 原记录（2026-11-16，保留）

# 平台服务器端 v1 测试日志（TESTLOG）

> 时间：2026-11-16。环境：本机容器，Python 3 标准库，无第三方依赖。
> 口径：只写实测结果，token 值一律打码；演示值（手机号 13800138000、设备 ID）只作走流程用的数，不作验收依据。
> 结论先行：冒烟 **PASS 186，FAIL 0**；8000 手动走链全部通过；快照写失败探针发现一个真 bug（job 卡死），已修并复测通过。

## §0 冒烟测试：PASS 186，FAIL 0

`bash tests/run_smoke.sh`（临时端口 18001、临时快照目录，跑完自清；修复后重跑两次，均为 186/0）。24 节逐节计数：

| 节 | 内容 | PASS |
|---|---|---|
| 0 | 健康检查 | 3 |
| 1 | 注册家庭组 A（13800138000） | 6 |
| 2 | 未登录查卡 401；管理密码校验 | 6 |
| 3 | 查卡：每日默认 5 张，倍率默认 0 | 5 |
| 4 | 预支：倍率 0 时到上限 409；改倍率 1 后可预支，幂等键去重 | 10 |
| 5 | 绑定终端（手动／扫码），重复与跨组校验 | 15 |
| 6 | 家庭组 B 注册；跨组绑同一设备 409 | 3 |
| 7 | `/solve` 拒收分支 | 5 |
| 8 | `/solve` 有效 JPEG：202 异步建 job，轮询到 failed model_not_connected（stub） | 10 |
| 9 | 取消未决任务（判题延迟 5 秒窗口内取消） | 5 |
| 10 | 扣卡：防重扣＋幂等键；无卡 402 | 10 |
| 11 | 申请单：创建／幂等／重复待批／待批列表／待拉取通知 | 7 |
| 12 | 审批：未校验管理密码 403；按张批 2 张；幂等；重复批 409 | 6 |
| 13 | 不批／撤回／再批拦截；按倍批准 | 8 |
| 14 | 模型：列表／选择／我的模型 503／MCP 真校验 | 14 |
| 15 | 服务器配置按家庭组分 | 5 |
| 16 | 用量／记录：只返回真实记录，不含费用字段 | 11 |
| 17 | 温度／MEMO 下发与设置 | 5 |
| 18 | 短信验证码 stub 明标；auth 别名；改密码 | 8 |
| 19 | 解绑：管理员可解绑；解绑后终端拒收；重复解绑 404；重绑编号顺延 | 6 |
| 20 | 家庭组：邀请／加入翻固化／转让／通过／拒绝／删除 | 26 |
| 21 | 重启后快照恢复（余额／防重扣／家庭组／绑定都在，会话失效） | 7 |
| 22 | 快照损坏：启动失败告警（退出码 2），不静默按空库启动 | 3 |
| 23 | 限流 429（通用 120／分钟、`/solve` 每终端 10／分钟） | 3 |
| **合计** | | **186** |

## §1 手动走链（端口 8000，数据 `/tmp/v1-verify-data`）

脚本 `/tmp/v1-verify-walk.sh`，日志 `/tmp/v1-verify-walk.log`。以下均为实测原值（token 已略）：

1. 注册：`family_id 20893363`（8 位纯数字，服务端生成，非演示值）、`member_no 1`、`role 管理员`、`next_step verify_admin_password`。
2. 管理密码校验：`{"verified": true, "family_id": "20893363"}`。
3. 绑定安卓 `2040059832773436`（终端 1，手动）；扫码 `JianTi-3040059832773436` 绑苹果 `3040059832773436`（终端 2）；扫空载荷报 422。
4. 查卡：`daily_cards 5，advance_ratio 0，advance_limit 0，balance 5`。倍率 0 时预支报 409；`POST /cards/rules` 改倍率 1 后 `advance_limit 5，total_available 10`；预支 1 张 → 余额 6，消息原文 `"解题卡已领取，请合理使用。"`；倍率改回 0 后余额回到 5（PRD 今日剩余公式：新每日张数 − 今日已用 ＋ 今日已预支 ＋ 今日已批）。
5. `/solve` 拒收：非 JPEG 415、9MB 图片 413、未绑定终端 403。
6. `/solve` 有效 JPEG：202 建 job；轮询到 `failed`，`error.code model_not_connected`，`thinking`／`answer` 均为 null，`failure_reason model_unavailable`，`poll {interval_seconds 1, timeout_seconds 60, timeout_code 50401}`——没有编任何思路或答案。
7. 扣卡：首次 `deducted true，balance 4`；同一幂等键重试回存过的响应（`deducted true` 是首次结果的重放），余额仍 4，未重复扣；新键同批同题 → `already_unlocked true，balance 4`。
8. 申请单：创建 201；按张批准 2 张 → 余额 6；重复批准报 409 `application_decided`。
9. 模型：列表 5 个官方模型，`jt-lite-2.0` 默认；`POST /models/my-model` 503，响应里不含提交的 Key；`GET /usage` 200，无 `cost`／`price` 字段。

## §2 六个新错误码探针（手册 v2 §2.5，终端侧失败映射）

说明：这 6 个码是**终端侧**的失败落点映射，只出现在手册 v2 §2.5，不在 v1 代码里；服务端的对应责任是快速失败、操作原子且幂等。探针在端口 8000 上做：

| 码 | 探针 | 结果 |
|---|---|---|
| `application_send_failed`（申请发送失败：停领取页，不显示“申请已发送。”，不建单，同幂等键可重试） | 未绑定终端发申请 | 403 `terminal_not_bound`；同键重试仍 403，未建申请单（待批总数 0，已批总数 2）——服务端拒收在先，终端侧按此码落点 |
| `approval_submit_failed`（审批提交失败：停第 13 屏，仍待批，可重试，不重复发卡） | 批卡时 `grant_type` 非法 | 400 `invalid_grant_type`，申请单仍 pending；随后合法批准 200，未重复发卡 |
| `server_config_fetch_failed`（配置拉取失败：保留上次配置，第 7 屏显示“配置未更新”，不阻塞拍题） | `GET /config/server` 带坏 token | 401，快速失败 |
| `connectivity_test_failed`（连通某步失败：停在该步，红叉，修好网络再测） | `GET /connectivity/test` | 404 `not_found`——**v1 没有连通测试端点**，符合设计：手册 §2.6 定板子自己按拉到的配置测 Wi-Fi → 联网 → 服务端，服务端的活是 `GET /config/server` 正常返回 200（已验证） |
| `card_query_timeout`（查卡／扣卡超时：停思路页，同幂等键重试；服务端没收到则不扣） | 见 §3 快照写失败探针 | 扣卡写失败时 500，内存余额已变但未落盘；同键重试在磁盘修好后返回存过的 200，不重复扣 |
| `record_write_failed`（记录写失败：不阻塞流程、不提示学生、按记录 ID 去重、重试到成功） | 见 §3 | 记录写失败走同一快照路径，行为与扣卡一致（500、内存保留、修好后自愈）；终端侧“不阻塞、不提示”由客户端按此码落点 |

## §3 快照写失败探针：发现并修复一个真 bug

### 3.1 第一次探针（方法错了，结论作废）

把数据目录 `chmod a-w` 后跑：扣卡 200、`/solve` 202 正常完成——因为服务端跑在 root 下，root 绕过文件权限检查，写盘根本没失败。这次结果**不能证明任何事**，方法作废。

### 3.2 第二次探针（修前代码）：job 卡死 bug 实锤

方法：先正常启动（端口 18005），注册、绑终端，然后把 `applications.json` 换成同名目录——下次 `save()` 在改名时抛 `OSError`，写失败真实发生。脚本 `/tmp/v1-savefail-test2.sh`：

- 扣卡首次 → **500** `{"error": {"code": "internal_error", "message": "服务端内部错误：快照写入失败。"}}`；查卡内存余额 4（内存已扣，未落盘）。
- 同一幂等键重试扣卡 → **也 500**（不是 `already_unlocked`）：防重扣逻辑本身没错，但 `_idem_store` 的 `save()` 同样失败，所以重放也 500。未重复扣，余额仍 4。
- `/solve` 首次 → **500**（同上）；同一幂等键重发 → 202 取到 job `job-397b7b6332bc`；+3 秒轮询 → `status processing，stage model，error None`；+6 秒轮询 → **仍 processing**。
- **结论：bug 实锤。** `_post_solve` 里判题线程在 `store.save()` 之后才起；`save()` 一抛错，线程永远没起，job 永远卡在 processing，终端只能等 60 秒按 50401 超时。

### 3.3 修复

`gateway.py` `_post_solve`：**先起判题线程，再写快照**。写失败仍按原有约定返回 500（不改契约），但 job 一定能跑完。改动 1 处，见 `ASSUMPTIONS.md` V1-A3。

### 3.4 修复后复测（同一场景）：通过

脚本 `/tmp/v1-savefail-retest.sh`：

- 扣卡首次 → 500（不变）；`/solve` 首次 → 500（不变）。
- 同一幂等键重发 `/solve` → 202 取到 job `job-80c173f3d478`；+3 秒轮询 → **`status failed，error model_not_connected`**（“模型未接通：未配置 QWEN_API_KEY，判题服务不可用，未生成任何答案。”）——**不再卡 processing，修复确认**。
- 恢复可写后**不重启**：扣卡同一幂等键重试 → **200 `already_unlocked，balance 4`**；`/solve` 同一幂等键重试 → 202，job 已是 failed——**自愈确认**（内存里的幂等记录与防重扣标记都在，磁盘一修好就恢复正常，不用重启、不丢状态）。
- 修复后冒烟重跑：**PASS 186，FAIL 0**（两次），修复未破坏任何已有行为。

## §4 60 秒轮询超时语义探针（50401）

`JIANTI_JUDGE_DELAY_SECONDS=65`，端口 18006，脚本 `/tmp/v1-poll65-test.sh`：

| 时刻 | 状态 | 说明 |
|---|---|---|
| T+0s | processing，elapsed 0，timeout_code 50401 | 建 job 即带 poll 口径 |
| T+30s | processing，elapsed 30 | 仍在跑 |
| T+60s | **processing，elapsed 60** | **服务端不在 60 秒时杀 job** |
| T+68s | failed，elapsed 68，error model_not_connected | 判题线程跑完（65 秒延迟）后 job 正常终结 |

结论：50401 是**客户端**超时判定（1 秒一次、最多 60 秒），服务端只在 poll 里带 `timeout_code 50401`，从不主动超时 job；job 的终态只由判题线程或取消决定。

## §5 本次没测的／已知缺口

- Qwen 真实调用：无 `QWEN_API_KEY`，未测（部署时定，见 N1；代码路径在 `judge.py`，接通后须重测 F1 全链）。
- 真实扫码：无摄像头实读，只测了载荷解析与 422 拒空（C1，见缺啥清单）。
- 真实短信通道：stub，只做格式检查（U17 相关）。
- 三端联调：未做（等嵌入式／APP 端接通后做，见缺啥清单第 22 条）。
- 并发与压力：只测了限流 429，未做并发压测；快照是全量写文件，大并发下的写放大与锁竞争未评估。
- 多家庭组隔离：冒烟只覆盖两组交叉校验，配置按组分已测；更大规模未测。
