#!/bin/bash
# 简题平台服务器端 v8 A4 顶层字段探针：Nyx 538（A4 偏差下版补）。
# 用法：bash tests/probe_a4_top_level.sh
# 开实例：端口 18013，数据 /tmp/v8test-a4，JIANTI_TEST_MODE=1（模拟判题出题）。
# 验两处：① 扣卡返回顶层带 answer／question_id／unlocked，且与 job 内一致；
# ② 轮询 question 视图带 question_id（本批内题 ID，接口 A2 约定）。
# 注意：脚本里出现的手机号／密码均为测试假数据，不是真实凭证。
set -u
cd "$(dirname "$0")/.."

PASS=0; FAIL=0; FAILED_NAMES=""
RESP=/tmp/v8test-a4-resp.json

note() { echo; echo "== $* ==";}
req() { # req BASE METHOD PATH [curl args...]；回显并保存 BODY/CODE
local base=$1 method=$2 path=$3; shift 3
local out
out=$(curl -s -w "\n%{http_code}" -X "$method" "$base$path" "$@")
CODE="${out##*$'\n'}"
BODY="${out%$'\n'*}"
printf '%s' "$BODY" > "$RESP"
echo "[$CODE] $method $path -> $BODY"
}
jget() { python3 -c "import json;d=json.load(open('$RESP'));print($1 if $1 is not None else '')" 2>/dev/null;}
expect_code() { # expect_code 200 名称
if [ "$CODE" = "$1" ]; then PASS=$((PASS+1)); echo "PASS: $2 (HTTP $1)";
else FAIL=$((FAIL+1)); FAILED_NAMES="$FAILED_NAMES|$2"; echo "FAIL: $2 (want HTTP $1, got $CODE: $BODY)"; fi
}
expect_eq() { # expect_eq 实际 预期 名称
if [ "$1" = "$2" ]; then PASS=$((PASS+1)); echo "PASS: $3 ($1)";
else FAIL=$((FAIL+1)); FAILED_NAMES="$FAILED_NAMES|$3"; echo "FAIL: $3 (want [$2], got [$1])"; fi
}
expect_contains() { # expect_contains 名称 子串
case "$BODY" in *"$2"*) PASS=$((PASS+1)); echo "PASS: $1";; *) FAIL=$((FAIL+1)); FAILED_NAMES="$FAILED_NAMES|$1"; echo "FAIL: $1 (body 缺少 [$2]: $BODY)";; esac
}
poll_job() { # poll_job BASE TOKEN JOBID：轮询到非 processing，最多 20 秒
local base=$1 token=$2 job=$3 i=0
while [ $i -lt 20 ]; do
req "$base" GET "/solve/$job" -H "Authorization: Bearer $token"
st=$(jget "d.get('status')")
[ "$st" != "processing" ] && return 0
sleep 1; i=$((i+1))
done
return 1
}

python3 -c "open('/tmp/tiny.jpg','wb').write(b'\xff\xd8\xff\xe0'+b'\x00'*100)"

# ---------- 启动实例（测试模式开，模拟判题） ----------
PORT=18013; DATA=/tmp/v8test-a4; BASE=http://127.0.0.1:$PORT
rm -rf "$DATA"
JIANTI_PORT=$PORT JIANTI_DATA_DIR=$DATA JIANTI_TEST_MODE=1 \
JIANTI_RATE_LIMIT_GENERAL_PER_MIN=10000 JIANTI_RATE_LIMIT_SOLVE_PER_MIN=1000 \
python3 app.py > /tmp/v8test-a4.log 2>&1 &
SRVPID=$!
sleep 1
kill -0 $SRVPID 2>/dev/null || { echo "实例没起来"; cat /tmp/v8test-a4.log; exit 1;}

note "A. health：服务名 v8，测试模式开"
req "$BASE" GET /health
expect_code 200 "health 200"
expect_eq "$(jget "d.get('service')")" "jianti-platform-server-v8" "service 名 v8"
expect_eq "$(jget "d.get('test_mode')")" "True" "health test_mode=true"

note "B. 注册＋演示值扫码绑定"
req "$BASE" POST /users/register -H 'Content-Type: application/json' \
-d '{"phone":"13800138000","login_password":"12345678","admin_password":"123456","sms_code":"123456"}'
expect_code 201 "注册 201"
TOKEN=$(jget "d.get('token')")
req "$BASE" POST /users/admin-password/verify -H "Authorization: Bearer $TOKEN" \
-H 'Content-Type: application/json' -d '{"admin_password":"123456"}' >/dev/null
req "$BASE" POST /terminals/bind-scan -H "Authorization: Bearer $TOKEN" \
-H 'Content-Type: application/json' -d '{"scan_payload":"JianTi-2864190752386419"}'
expect_code 201 "演示值扫码绑 201"

note "C. 模拟判题走完，轮询 question 视图带 question_id"
req "$BASE" POST /solve -H "Authorization: Bearer $TOKEN" -H "X-Terminal-Id: 2864190752386419" \
-H "Idempotency-Key: a4-solve-1" -H 'Content-Type: image/jpeg' --data-binary @/tmp/tiny.jpg
expect_code 202 "/solve 202"
JOB=$(jget "d.get('job_id')")
poll_job "$BASE" "$TOKEN" "$JOB" || { FAIL=$((FAIL+1)); echo "FAIL: 模拟 job 20 秒未终结";}
expect_eq "$(jget "d.get('status')")" "done" "模拟 job 轮询终态 done"
QID_POLL=$(jget "d.get('questions',[{}])[0].get('question_id')")
expect_eq "$QID_POLL" "$JOB-q1" "轮询 question[0].question_id=job-q1"
expect_eq "$(jget "d.get('questions',[{}])[0].get('question_index')")" "1" "轮询 question[0].question_index=1（从 1 起）"
expect_eq "$(jget "d.get('questions',[{}])[0].get('unlocked')")" "False" "未解锁前 question unlocked=false"
expect_eq "$(jget "d.get('questions',[{}])[0].get('answer')")" "" "未解锁前 question answer 不下发（null）"

note "D. 查卡：用轮询拿到的 question_id 查，认得这道题"
req "$BASE" POST /cards/check -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
-d "{\"question_id\":\"$QID_POLL\"}"
expect_code 200 "查卡 200"
expect_eq "$(jget "d.get('unlocked')")" "False" "查卡：该题未解锁"
expect_eq "$(jget "d.get('can_deduct')")" "True" "查卡：有卡且未解锁可扣"

note "E. 扣卡：顶层带 answer／question_id／unlocked，与 job 内一致"
req "$BASE" POST /cards/deduct -H "Authorization: Bearer $TOKEN" \
-H "Idempotency-Key: a4-ded-1" -H 'Content-Type: application/json' \
-d "{\"job_id\":\"$JOB\",\"question_index\":0}"
expect_code 200 "扣卡 200"
expect_eq "$(jget "d.get('deducted')")" "True" "扣卡成功"
expect_eq "$(jget "d.get('balance')")" "4" "扣卡后余额 4"
expect_eq "$(jget "d.get('unlocked')")" "True" "扣卡返回顶层 unlocked=true"
expect_eq "$(jget "d.get('question_id')")" "$QID_POLL" "扣卡返回顶层 question_id=轮询的 question_id"
expect_contains "扣卡返回顶层 answer 带标记" "测试模拟"
ANS_DEDUCT=$(jget "d.get('answer')")
ANS_JOB=$(jget "d.get('job',{}).get('answer')")
expect_eq "$ANS_DEDUCT" "$ANS_JOB" "扣卡顶层 answer=job.answer"
QID_JOB=$(jget "d.get('job',{}).get('questions',[{}])[0].get('question_id')")
expect_eq "$(jget "d.get('question_id')")" "$QID_JOB" "扣卡顶层 question_id=job 内 question_id"

note "F. 再轮询：question 视图的 question_id 不变，答案与扣卡顶层一致"
req "$BASE" GET "/solve/$JOB" -H "Authorization: Bearer $TOKEN"
expect_eq "$(jget "d.get('questions',[{}])[0].get('question_id')")" "$QID_POLL" "扣卡后轮询 question_id 不变"
expect_eq "$(jget "d.get('questions',[{}])[0].get('unlocked')")" "True" "扣卡后 question unlocked=true"
ANS_POLL=$(jget "d.get('questions',[{}])[0].get('answer')")
expect_eq "$ANS_POLL" "$ANS_DEDUCT" "轮询 question answer=扣卡顶层 answer"

note "G. 再扣同一题：不重复扣，顶层字段仍齐全一致"
req "$BASE" POST /cards/deduct -H "Authorization: Bearer $TOKEN" \
-H "Idempotency-Key: a4-ded-2" -H 'Content-Type: application/json' \
-d "{\"job_id\":\"$JOB\",\"question_index\":0}"
expect_code 200 "重复扣卡 200（不 409、不扣）"
expect_eq "$(jget "d.get('already_unlocked')")" "True" "重复扣卡 already_unlocked=true"
expect_eq "$(jget "d.get('balance')")" "4" "重复扣卡余额仍 4"
expect_eq "$(jget "d.get('unlocked')")" "True" "重复扣卡顶层 unlocked=true"
expect_eq "$(jget "d.get('question_id')")" "$QID_POLL" "重复扣卡顶层 question_id 一致"
expect_eq "$(jget "d.get('answer')")" "$ANS_DEDUCT" "重复扣卡顶层 answer 一致"

note "H. 幂等重放：同一 Idempotency-Key 返回同一顶层字段，不重复扣"
req "$BASE" POST /cards/deduct -H "Authorization: Bearer $TOKEN" \
-H "Idempotency-Key: a4-ded-1" -H 'Content-Type: application/json' \
-d "{\"job_id\":\"$JOB\",\"question_index\":0}"
expect_code 200 "幂等重放 200"
expect_eq "$(jget "d.get('deducted')")" "True" "幂等重放仍是首次扣卡结果"
expect_eq "$(jget "d.get('question_id')")" "$QID_POLL" "幂等重放顶层 question_id 一致"
expect_eq "$(jget "d.get('answer')")" "$ANS_DEDUCT" "幂等重放顶层 answer 一致"
expect_eq "$(jget "d.get('balance')")" "4" "幂等重放余额仍 4"

kill $SRVPID 2>/dev/null; sleep 1

# ---------- 汇总 ----------
echo
echo "=================================="
echo "PASS: $PASS FAIL: $FAIL"
[ -n "$FAILED_NAMES" ] && echo "失败项：$FAILED_NAMES"
echo "=================================="
[ "$FAIL" = "0" ]
