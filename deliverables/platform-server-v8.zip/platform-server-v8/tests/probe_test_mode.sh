#!/bin/bash
# 简题平台服务器端 v8 测试模式探针：Nyx 498/500（JIANTI_TEST_MODE 开关）。
# 用法：bash tests/probe_test_mode.sh
# 开实例：端口 18011，数据 /tmp/v8test-mode-on，JIANTI_TEST_MODE=1，
# 演示值扫码绑不 403、未绑定的 App 生成号发网关不 403、/solve 模拟
# 走完结果+扣卡+使用记录；非法格式仍 403；不写假绑定记录。
# 关实例：端口 18012，数据 /tmp/v8test-mode-off，不设开关，
# 未绑定 403、无 Key /solve 仍 model_not_connected（与 v5 一字不差）。
# 注意：脚本里出现的手机号／密码均为测试假数据，不是真实凭证。
set -u
cd "$(dirname "$0")/.."

PASS=0; FAIL=0; FAILED_NAMES=""
RESP=/tmp/v8test-mode-resp.json

note() { echo; echo "== $* ==";}
req() { # req BASE METHOD PATH [curl args...]；回显并保存 BODY/CODE
local base=$1 method=$2 path=$3; shift 3
local out
out=$(curl -s -w "\n%{http_code}" -X "$method" "$base$path" "$@")
CODE="${out##*$'\n'}"
BODY="${out%$'\n'*}"
printf '%s' "$BODY" > "$RESP"
echo "[$CODE] $method $path -> $BODY"
}
jget() { python3 -c "import json;d=json.load(open('$RESP'));print($1 if $1 is not None else '')" 2>/dev/null;}
expect_code() { # expect_code 200 名称
if [ "$CODE" = "$1" ]; then PASS=$((PASS+1)); echo "PASS: $2 (HTTP $1)";
else FAIL=$((FAIL+1)); FAILED_NAMES="$FAILED_NAMES|$2"; echo "FAIL: $2 (want HTTP $1, got $CODE: $BODY)"; fi
}
expect_eq() { # expect_eq 实际 预期 名称
if [ "$1" = "$2" ]; then PASS=$((PASS+1)); echo "PASS: $3 ($1)";
else FAIL=$((FAIL+1)); FAILED_NAMES="$FAILED_NAMES|$3"; echo "FAIL: $3 (want [$2], got [$1])"; fi
}
expect_contains() { # expect_contains 名称 子串
case "$BODY" in *"$2"*) PASS=$((PASS+1)); echo "PASS: $1";; *) FAIL=$((FAIL+1)); FAILED_NAMES="$FAILED_NAMES|$1"; echo "FAIL: $1 (body 缺少 [$2]: $BODY)";; esac
}
poll_job() { # poll_job BASE TOKEN JOBID：轮询到非 processing，最多 20 秒
local base=$1 token=$2 job=$3 i=0
while [ $i -lt 20 ]; do
req "$base" GET "/solve/$job" -H "Authorization: Bearer $token"
st=$(jget "d.get('status')")
[ "$st" != "processing" ] && return 0
sleep 1; i=$((i+1))
done
return 1
}

python3 -c "open('/tmp/tiny.jpg','wb').write(b'\xff\xd8\xff\xe0'+b'\x00'*100)"

# ---------- 启动开实例（测试模式开） ----------
ON_PORT=18011; ON_DATA=/tmp/v8test-mode-on; ON=http://127.0.0.1:$ON_PORT
rm -rf "$ON_DATA"
JIANTI_PORT=$ON_PORT JIANTI_DATA_DIR=$ON_DATA JIANTI_TEST_MODE=1 \
JIANTI_RATE_LIMIT_GENERAL_PER_MIN=10000 JIANTI_RATE_LIMIT_SOLVE_PER_MIN=1000 \
python3 app.py > /tmp/v8test-mode-on.log 2>&1 &
ONPID=$!
sleep 1
kill -0 $ONPID 2>/dev/null || { echo "开实例没起来"; cat /tmp/v8test-mode-on.log; exit 1;}

note "A. 开实例：health 明标 test_mode=true，启动日志同标"
req "$ON" GET /health
expect_code 200 "开实例 health 200"
expect_eq "$(jget "d.get('service')")" "jianti-platform-server-v8" "开实例 service 名 v8"
expect_eq "$(jget "d.get('test_mode')")" "True" "开实例 health test_mode=true"
grep -q "test_mode=True" /tmp/v8test-mode-on.log \
&& { PASS=$((PASS+1)); echo "PASS: 开实例启动日志 test_mode=True";} \
|| { FAIL=$((FAIL+1)); FAILED_NAMES="$FAILED_NAMES|开实例启动日志"; echo "FAIL: 开实例启动日志缺 test_mode=True"; cat /tmp/v8test-mode-on.log;}

note "B. 开实例：注册＋管理密码校验"
req "$ON" POST /users/register -H 'Content-Type: application/json' \
-d '{"phone":"13800138000","login_password":"12345678","admin_password":"123456","sms_code":"123456"}'
expect_code 201 "开实例注册 201"
TOKEN_ON=$(jget "d.get('token')")
req "$ON" POST /users/admin-password/verify -H "Authorization: Bearer $TOKEN_ON" \
-H 'Content-Type: application/json' -d '{"admin_password":"123456"}' >/dev/null

note "C. 开实例：演示值扫码绑定 201（Nyx 498 演示值 2864190752386419）"
req "$ON" POST /terminals/bind-scan -H "Authorization: Bearer $TOKEN_ON" \
-H 'Content-Type: application/json' -d '{"scan_payload":"JianTi-2864190752386419"}'
expect_code 201 "演示值扫码绑 201"
expect_eq "$(jget "d.get('device_type')")" "安卓" "演示值类型 2=安卓"
expect_eq "$(jget "d.get('terminal_no')")" 1 "演示值终端编号 1"

note "D. 开实例：未绑定的 App 生成号发网关不 403（Nyx 498 核心）"
APP_GEN=2864190752386420
req "$ON" POST /solve -H "Authorization: Bearer $TOKEN_ON" -H "X-Terminal-Id: $APP_GEN" \
-H "Idempotency-Key: mode-on-1" -H 'Content-Type: image/jpeg' --data-binary @/tmp/tiny.jpg
expect_code 202 "未绑定 App 生成号 /solve 202（不 403）"
JOB_ON=$(jget "d.get('job_id')")
expect_eq "$(jget "d.get('status')")" "processing" "建 job 时 processing"
poll_job "$ON" "$TOKEN_ON" "$JOB_ON" || { FAIL=$((FAIL+1)); echo "FAIL: 模拟 job 20 秒未终结";}
expect_eq "$(jget "d.get('status')")" "done" "模拟 job 轮询终态 done"
expect_eq "$(jget "d.get('mock')")" "True" "job 打 mock=true"
expect_eq "$(jget "d.get('result_source')")" "mock" "job result_source=mock"
expect_eq "$(jget "d.get('stage_index')")" "5" "五阶段全 done（stage_index=5）"
expect_eq "$(jget "d.get('stage')")" "delivering" "终态阶段 delivering"
expect_contains "模拟思路带标记" "测试模拟"
expect_eq "$(jget "d.get('answer')")" "" "未解锁前答案不下发（null）"
expect_eq "$(jget "d.get('correct')")" "True" "模拟判题 correct=true"

note "E. 开实例：不写假绑定记录——未绑定的 App 生成号不在终端列表里"
req "$ON" GET /terminals -H "Authorization: Bearer $TOKEN_ON"
expect_code 200 "终端列表 200"
expect_eq "$(jget "len(d.get('items',[]))")" "1" "列表只有扫码绑的演示值 1 台"
case "$BODY" in *"$APP_GEN"*) FAIL=$((FAIL+1)); FAILED_NAMES="$FAILED_NAMES|假绑定记录"; echo "FAIL: 终端列表不应含未绑定的 App 生成号";; *) PASS=$((PASS+1)); echo "PASS: 终端列表不含未绑定的 App 生成号";; esac

note "F. 开实例：扣卡解锁答案＋使用记录（全链路）"
req "$ON" POST /cards/check -H "Authorization: Bearer $TOKEN_ON" -H 'Content-Type: application/json' -d '{}'
expect_eq "$(jget "d.get('balance')")" "5" "扣卡前余额 5"
req "$ON" POST /cards/deduct -H "Authorization: Bearer $TOKEN_ON" \
-H "Idempotency-Key: mode-on-ded-1" -H 'Content-Type: application/json' \
-d "{\"job_id\":\"$JOB_ON\",\"question_index\":0}"
expect_code 200 "扣卡 200"
expect_eq "$(jget "d.get('deducted')")" "True" "扣卡成功"
expect_eq "$(jget "d.get('balance')")" "4" "扣卡后余额 4"
expect_contains "扣卡返回的答案带标记" "测试模拟"
req "$ON" GET "/solve/$JOB_ON" -H "Authorization: Bearer $TOKEN_ON"
expect_eq "$(jget "d.get('unlocked')")" "True" "扣卡后 job 已解锁"
expect_contains "解锁后答案可见且带标记" "测试模拟"
req "$ON" GET "/records?days=7" -H "Authorization: Bearer $TOKEN_ON"
expect_code 200 "使用记录 200"
expect_eq "$(jget "sum(1 for r in d.get('items',[]) if r.get('kind')=='solve_success')")" "1" "记录里有 1 条 solve_success"
expect_eq "$(jget "sum(1 for r in d.get('items',[]) if r.get('kind')=='deduct')")" "1" "记录里有 1 条 deduct"
expect_eq "$(jget "sum(1 for r in d.get('items',[]) if r.get('kind')=='thinking')")" "1" "记录里有 1 条 thinking"

note "G. 开实例：非法格式终端仍 403（白名单不动）"
req "$ON" POST /solve -H "Authorization: Bearer $TOKEN_ON" -H "X-Terminal-Id: 9999059832773436" \
-H "Idempotency-Key: mode-on-bad-1" -H 'Content-Type: image/jpeg' --data-binary @/tmp/tiny.jpg
expect_code 403 "首位 9 的非法格式终端仍 403 terminal_not_bound"
kill $ONPID 2>/dev/null; sleep 1

# ---------- 启动关实例（测试模式关，默认行为） ----------
OFF_PORT=18012; OFF_DATA=/tmp/v8test-mode-off; OFF=http://127.0.0.1:$OFF_PORT
rm -rf "$OFF_DATA"
JIANTI_PORT=$OFF_PORT JIANTI_DATA_DIR=$OFF_DATA \
JIANTI_RATE_LIMIT_GENERAL_PER_MIN=10000 JIANTI_RATE_LIMIT_SOLVE_PER_MIN=1000 \
python3 app.py > /tmp/v8test-mode-off.log 2>&1 &
OFFPID=$!
sleep 1
kill -0 $OFFPID 2>/dev/null || { echo "关实例没起来"; cat /tmp/v8test-mode-off.log; exit 1;}

note "H. 关实例：health 明标 test_mode=false，启动日志同标"
req "$OFF" GET /health
expect_code 200 "关实例 health 200"
expect_eq "$(jget "d.get('test_mode')")" "False" "关实例 health test_mode=false"
grep -q "test_mode=False" /tmp/v8test-mode-off.log \
&& { PASS=$((PASS+1)); echo "PASS: 关实例启动日志 test_mode=False";} \
|| { FAIL=$((FAIL+1)); FAILED_NAMES="$FAILED_NAMES|关实例启动日志"; echo "FAIL: 关实例启动日志缺 test_mode=False"; cat /tmp/v8test-mode-off.log;}

note "I. 关实例：注册＋未绑定发网关 403（与 v5 一字不差）"
req "$OFF" POST /users/register -H 'Content-Type: application/json' \
-d '{"phone":"13800138000","login_password":"12345678","admin_password":"123456","sms_code":"123456"}'
expect_code 201 "关实例注册 201"
TOKEN_OFF=$(jget "d.get('token')")
req "$OFF" POST /users/admin-password/verify -H "Authorization: Bearer $TOKEN_OFF" \
-H 'Content-Type: application/json' -d '{"admin_password":"123456"}' >/dev/null
req "$OFF" POST /solve -H "Authorization: Bearer $TOKEN_OFF" -H "X-Terminal-Id: 2864190752386419" \
-H "Idempotency-Key: mode-off-1" -H 'Content-Type: image/jpeg' --data-binary @/tmp/tiny.jpg
expect_code 403 "关实例未绑定终端 403 terminal_not_bound"
expect_contains "关实例 403 码 terminal_not_bound" "terminal_not_bound"

note "J. 关实例：已绑定终端 /solve 仍 model_not_connected（与 v5 一字不差）"
req "$OFF" POST /terminals/bind -H "Authorization: Bearer $TOKEN_OFF" \
-H 'Content-Type: application/json' -d '{"device_id":"2864190752386419","member_no":1}'
expect_code 201 "关实例手动绑演示值 201"
req "$OFF" POST /solve -H "Authorization: Bearer $TOKEN_OFF" -H "X-Terminal-Id: 2864190752386419" \
-H "Idempotency-Key: mode-off-2" -H 'Content-Type: image/jpeg' --data-binary @/tmp/tiny.jpg
expect_code 202 "关实例已绑定 /solve 202"
JOB_OFF=$(jget "d.get('job_id')")
poll_job "$OFF" "$TOKEN_OFF" "$JOB_OFF" || { FAIL=$((FAIL+1)); echo "FAIL: 关实例 job 20 秒未终结";}
expect_eq "$(jget "d.get('status')")" "failed" "关实例 job 终态 failed"
expect_eq "$(jget "d.get('error',{}).get('code')")" "model_not_connected" "关实例失败码 model_not_connected，不编假答案"
expect_eq "$(jget "d.get('mock')")" "False" "关实例 job mock=false"
expect_eq "$(jget "d.get('result_source')")" "real" "关实例 job result_source=real"
expect_eq "$(jget "d.get('failure_reason')")" "model_unavailable" "关实例 failure_reason=model_unavailable"
kill $OFFPID 2>/dev/null; sleep 1

# ---------- 汇总 ----------
echo
echo "=================================="
echo "PASS: $PASS FAIL: $FAIL"
[ -n "$FAILED_NAMES" ] && echo "失败项：$FAILED_NAMES"
echo "=================================="
[ "$FAIL" = "0" ]
