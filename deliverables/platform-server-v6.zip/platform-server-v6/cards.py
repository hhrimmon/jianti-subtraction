"""cards.py — 解题卡：查卡 / 扣卡 / 预支 / 卡规则配置（服务端结算，v1）.

规则（手册 v2 §2.3，PRD 第 4 章）：
- 点卡直接扣 1 张，无确认弹窗（网关层不弹，服务端只管扣）。
- 同一批同一题只扣一次；已解锁再点不扣卡，直接进结果。
- 余额不为负，网关强制校验；多端并发以服务端实时结算为准（Store 锁；
  v1 用一把全局写锁串行化全部写操作，比手册“按家庭组串行”更严，
  见 ASSUMPTIONS.md V1-A13）。
- 预支每次 1 张、每笔留痕；上限 = 每日张数 x 倍率；
  总可用 = 每日张数 x (1 + 倍率)。倍率默认 0（定稿）。
- 改每日张数点完立即生效，今日剩余按 PRD 公式重算：
  今日剩余 = 新张数 - 今日已用（手册 §2.3、架构 §4.2 已同步）。
  注意：该公式不保留当日已预支／已批的增量（与骨架探针的扩展算法不同，
  见 ASSUMPTIONS.md V1-A2）。
- 幂等：扣卡／预支由网关层按 Idempotency-Key 去重（见 gateway.py），
  本模块只保证同一批同一题只扣一次（防重扣键进快照，重启仍有效）。
"""
from __future__ import annotations

from models import new_card_ledger_entry, new_record
from server_config import (ADVANCE_PER_TIME, ADVANCE_RATIO_DEFAULT,
                           ADVANCE_RATIO_MAX, DAILY_CARDS_DEFAULT,
                           DAILY_CARDS_MAX)


class CardError(Exception):
    def __init__(self, code: str, message: str, status: int = 400):
        super().__init__(message)
        self.code = code
        self.message = message
        self.status = status


def _today() -> str:
    import time
    return time.strftime("%Y-%m-%d", time.localtime())


def _card_state(store, family_id: str) -> dict:
    """取当日卡状态；跨天则重置（今日剩余按新每日张数重算）。"""
    st = store.data["card_state"].get(family_id)
    today = _today()
    fam = store.data["families"].get(family_id)
    daily = fam["daily_cards"] if fam else DAILY_CARDS_DEFAULT
    if st is None or st.get("date") != today:
        st = {"balance": daily, "advanced_today": 0,
              "granted_today": 0, "used_today": 0, "date": today}
        store.data["card_state"][family_id] = st
    return st


def _limits(store, family_id: str) -> dict:
    fam = store.data["families"].get(family_id)
    daily = fam["daily_cards"] if fam else DAILY_CARDS_DEFAULT
    ratio = fam["advance_ratio"] if fam else ADVANCE_RATIO_DEFAULT
    return {
        "daily_cards": daily,
        "advance_ratio": ratio,
        "advance_limit": daily * ratio,
        "total_available": daily * (1 + ratio),
    }


def check_cards(store, family_id: str, question_id: str | None = None,
                batch_id: str | None = None) -> dict:
    with store.lock:
        if family_id not in store.data["families"]:
            raise CardError("family_not_found", "家庭组不存在。", 404)
        st = _card_state(store, family_id)
        out = dict(_limits(store, family_id))
        out.update({
            "family_id": family_id,
            "balance": st["balance"],           # 今日剩余
            "daily_total": out["daily_cards"],   # 接口 A3 字段名
            "advanced": st["advanced_today"],    # 接口 A3 字段名：已预支
            "advanced_today": st["advanced_today"],
            "granted_today": st["granted_today"],
            "used_today": st["used_today"],
        })
        if question_id is not None:
            key = f"{family_id}|{batch_id or 'nobatch'}|{question_id}"
            out["unlocked"] = key in store.data["unlocked"]
            out["can_deduct"] = st["balance"] > 0 and not out["unlocked"]
        return out


def set_card_rules(store, family_id: str, daily_cards=None,
                   advance_ratio=None) -> dict:
    """家长在 13 屏改每日张数/倍率，点确认才生效（PRD 3.5）。"""
    with store.lock:
        fam = store.data["families"].get(family_id)
        if fam is None:
            raise CardError("family_not_found", "家庭组不存在。", 404)
        if daily_cards is not None:
            if not isinstance(daily_cards, int) or not 1 <= daily_cards <= DAILY_CARDS_MAX:
                raise CardError("invalid_daily_cards",
                                f"每日张数须为 1-{DAILY_CARDS_MAX} 的整数。")
            fam["daily_cards"] = daily_cards
        if advance_ratio is not None:
            if not isinstance(advance_ratio, int) or not 0 <= advance_ratio <= ADVANCE_RATIO_MAX:
                raise CardError("invalid_advance_ratio",
                                f"预支倍率须为 0-{ADVANCE_RATIO_MAX} 的整数。")
            fam["advance_ratio"] = advance_ratio
        # 改完立即生效：今日剩余 = 新张数 - 今日已用（PRD 公式，不含增量）。
        st = _card_state(store, family_id)
        st["balance"] = max(0, fam["daily_cards"] - st["used_today"])
        store.save()
        return check_cards(store, family_id)


def deduct_card(store, family_id: str, job_id: str | None = None,
                batch_id: str | None = None,
                question_index: int | None = None) -> dict:
    """点解题卡扣 1 张。返回含解锁状态；已解锁再点不扣卡。

    job_id 优先：解锁该 job 的答案。若只给 batch/question，
    用 (family, batch, question) 做防重扣键。
    """
    with store.lock:
        if family_id not in store.data["families"]:
            raise CardError("family_not_found", "家庭组不存在。", 404)
        job = store.data["jobs"].get(job_id) if job_id else None
        if job_id and job is None:
            raise CardError("job_not_found", "题目不存在。", 404)
        key = f"{family_id}|{batch_id or (job['job_id'] if job else 'nobatch')}|" \
              f"{question_index if question_index is not None else 0}"
        # 防重扣键用字符串：tuple 键进不了 JSON 快照，重启后会失效。
        questions = job.get("questions") if job else None
        if questions is not None and question_index is not None:
            if not 0 <= question_index < len(questions):
                raise CardError("question_not_found", "题号不存在。", 404)
            already = questions[question_index].get("unlocked", False)
        else:
            already = key in store.data["unlocked"] or (job and job["unlocked"])
        if already:
            unlocked_job = store.data["jobs"].get(store.data["unlocked"].get(key, job_id or "")) or job
            return {"deducted": False, "already_unlocked": True,
                    "balance": _card_state(store, family_id)["balance"],
                    "job": _job_view(unlocked_job) if unlocked_job else None}
        st = _card_state(store, family_id)
        if st["balance"] <= 0:
            raise CardError("no_cards", "解题卡已用光，请预支或向家长申请。", 402)
        st["balance"] -= 1
        st["used_today"] += 1
        store.data["ledger"].append(new_card_ledger_entry(
            family_id, "deduct", -1, st["balance"], job_id or str(key)))
        if job is not None:
            if questions is not None and question_index is not None:
                questions[question_index]["unlocked"] = True
                job["unlocked"] = all(q.get("unlocked") for q in questions)
                job["answer"] = questions[question_index].get("answer")
                job["thinking"] = questions[question_index].get("thinking")
                job["correct"] = questions[question_index].get("correct")
            else:
                job["unlocked"] = True
        # 防重扣标记与扣卡记录：无论是否关联 job 都要落（无 job 的按批扣卡也一样）。
        store.data["unlocked"][key] = job["job_id"] if job else "batch"
        store.data["records"].append(new_record(
            family_id, "deduct",
            {"job_id": job["job_id"] if job else None, "cards": 1,
             "question_index": question_index, "batch_id": batch_id}))
        store.save()
        return {"deducted": True, "already_unlocked": False,
                "balance": st["balance"],
                "job": _job_view(job) if job else None}


def _job_view(job):
    if job is None:
        return None
    view = {"job_id": job["job_id"], "unlocked": job["unlocked"],
            "answer": job["answer"] if job["unlocked"] else None,
            "thinking": job["thinking"], "correct": job["correct"]}
    questions = job.get("questions")
    if questions:
        view["questions"] = [{
            "index": i,
            "correct": q.get("correct"),
            "thinking": q.get("thinking"),
            "unlocked": q.get("unlocked", False),
            # 答案只对已解锁的题下发
            "answer": q.get("answer") if q.get("unlocked") else None,
        } for i, q in enumerate(questions)]
    return view


def advance_card(store, family_id: str) -> dict:
    """预支：每次 1 张，不限次数，每笔留痕；到上限停，余额不许成负数。"""
    with store.lock:
        if family_id not in store.data["families"]:
            raise CardError("family_not_found", "家庭组不存在。", 404)
        st = _card_state(store, family_id)
        lim = _limits(store, family_id)
        if st["advanced_today"] >= lim["advance_limit"]:
            raise CardError("advance_limit_reached",
                            f"预支已到上限（每日 {lim['daily_cards']} 张 x "
                            f"倍率 {lim['advance_ratio']} = "
                            f"{lim['advance_limit']} 张）。", 409)
        st["advanced_today"] += ADVANCE_PER_TIME
        st["balance"] += ADVANCE_PER_TIME
        store.data["ledger"].append(new_card_ledger_entry(
            family_id, "advance", ADVANCE_PER_TIME, st["balance"], "manual"))
        store.data["records"].append(new_record(
            family_id, "advance", {"cards": ADVANCE_PER_TIME}))
        store.save()
        return {"advanced": ADVANCE_PER_TIME,
                "advanced_today": st["advanced_today"],
                "advance_limit": lim["advance_limit"],
                "balance": st["balance"],
                "message": "解题卡已领取，请合理使用。"}


def grant_cards(store, family_id: str, cards: int, ref: str,
                member_no: int | None = None) -> dict:
    """家长批准申请后发卡（见 applications.py）：余额 += cards，留痕。"""
    with store.lock:
        if cards <= 0:
            raise CardError("invalid_grant", "发卡张数须大于 0。")
        st = _card_state(store, family_id)
        st["balance"] += cards
        st["granted_today"] += cards
        store.data["ledger"].append(new_card_ledger_entry(
            family_id, "grant", cards, st["balance"], ref))
        store.data["records"].append(new_record(
            family_id, "grant", {"cards": cards, "ref": ref,
                                 "member_no": member_no}))
        store.save()
        return {"balance": st["balance"], "granted_today": st["granted_today"]}
