# 简题平台服务器端 v6.0.0 — README

> 底稿：开发手册 v2 正式版（`jianti-kaifa-shouce-v2.docx`）＋ PRD v5.5（`jianti-prd-v5.5.docx`，v5.4 作废）。
> 来源：探针骨架 `platform-skeleton/` 往生产版走的第六步；v6 相对 v5 改了什么见 `ASSUMPTIONS.md` §8（Nyx 2026-11-18 裁决，房间消息 id 498/500）。v5 已冻结（`platform-server-v5.zip`，MD5 4d1d41df5f326f6bb1d6435069cba724），本版不动 v5 目录与 v5 包。
> 语言：Python 3，只用标准库，不装第三方包，不连外部数据库。网关 8000 是唯一入口。
> 红线：不编假数据——模型未接通时 `/solve` 只回 `model_not_connected`，思考与答案为空；用量只返回服务端真实入库的记录，不计费。**测试模式是唯一的例外**：`JIANTI_TEST_MODE=1` 时无真 Key 的 `/solve` 走模拟返回，思路／答案明标“测试模拟”、job 打 `mock` 标记；测试模式关时红线与 v5 一字不差。

## 1. 怎么跑

```bash
cd platform-server-v6
python3 app.py
# 默认只听 127.0.0.1:8000，快照写 ./data（15 个分实体 JSON 文件）
# 测试模式：JIANTI_TEST_MODE=1 python3 app.py（默认关；见 §1.1）
```

环境变量（全部可选；Key、密码、token 一律只走环境变量，绝不写进代码和文档）：

| 变量 | 默认 | 说明 |
|---|---|---|
| `JIANTI_HOST` | `127.0.0.1` | 监听地址 |
| `JIANTI_PORT` | `8000` | 网关端口，唯一入口 |
| `JIANTI_DATA_DIR` | `./data` | 快照目录（15 个文件，见 §4） |
| `QWEN_API_KEY` | （空） | 配了才走 Qwen 真实判题；不配则 F1 停在“大模型”阶段，job 回 `model_not_connected`（部署时定，见 N1） |
| `JIANTI_TEST_MODE` | （空） | **v6 测试模式开关**：`1` 才开，默认关。开时：格式合法的 16 位设备号按已绑定处理（`/solve` 不再 403 `terminal_not_bound`）、无真 Key 的 `/solve` 走模拟模型（job 打 `mock=true`／`result_source="mock"`，思路／答案明标“测试模拟”）；关时未绑定仍 403、无 Key 的 `/solve` 仍 `model_not_connected` 503，与 v5 一字不差。只影响测试行为，绝不默认开 |
| `JIANTI_JUDGE_DELAY_SECONDS` | `0` | 仅测试用：判题延迟秒数（测取消分支、测 60 秒轮询超时） |
| `JIANTI_RATE_LIMIT_GENERAL_PER_MIN` | `120` | 通用限流：每 IP 每分钟次数，超了 429 |
| `JIANTI_RATE_LIMIT_SOLVE_PER_MIN` | `10` | `/solve` 限流：每终端每分钟次数，超了 429 |

启动输出示例（无 Key 的 stub 模式，测试模式关）：

```
jianti platform server v6.0.0 listening on http://127.0.0.1:8000 (model_connected=False test_mode=False)
```

测试模式开时同一行末尾是 `test_mode=True`。健康检查：`GET /health` → `{"ok": true, "service": "jianti-platform-server-v6", "gateway_port": 8000, "model_connected": false, "test_mode": false, "official_server": "solve.mhq-ai.xyz"}`。

## 2. 怎么测

```bash
bash tests/run_smoke.sh
# 187 项，0 失败为通过；用临时端口 18001、临时快照目录，跑完自清
# （测试模式默认关：未绑定 403 与 model_not_connected 仍按 v5 断言）
bash tests/probe_test_mode.sh
# 测试模式探针：开时全链路走通（扫码绑／未绑定发网关不 403、/solve 模拟
# 走完结果+扣卡+使用记录），关时未绑定 403、无 Key /solve 仍 model_not_connected
```

并发探针（v2 新增，v3 仍过，v4 仍过）：同键并发打 `/solve`，distinct job_id 恒=1：

```bash
python3 tests/conc_probe.py
# 10 路同键并发只建 1 个 job，第二波新键只新增 1 个 job；退出码 0 为通过
```

改名探针（v2 新增）：空判题结果时错误码为 `no_question`：

```bash
python3 tests/probe_no_question.py
# 进程内跑，不起服务、不需要 Qwen Key；退出码 0 为通过
```

僵尸 job 探针（v3 新增，RECHECK #15）：启动扫尾把超 120 秒的 processing job 标 failed：

```bash
python3 tests/probe_stale_jobs.py
# 进程内跑：造 1 个 1 小时前的 processing job 进快照，冷重启加载后扫尾；
# 断言它变 failed/process_interrupted 且有终态 usage 记录，新 job 不受影响；
# 退出码 0 为通过
```

冒烟覆盖 24 节（§0–§23）：注册／管理密码／查卡／预支／绑定（手动＋扫码）／跨组校验／`/solve` 拒收分支／异步判题 stub／取消／扣卡防重扣／申请单幂等／审批／模型／服务器配置按家庭组／用量与记录／温度与 MEMO／短信 stub／解绑／家庭组（邀请／加入翻固化／转让／通过／拒绝／删除）／重启快照恢复／快照损坏启动失败／限流。逐项实测结果见 `TESTLOG.md`。

手动走一遍关键链路（端口 8000，`$TOKEN` 为注册返回的 Bearer token）：

```bash
# 注册（返回 8 位家庭组 ID、member_no 1、角色 管理员、next_step verify_admin_password）
curl -s -X POST http://127.0.0.1:8000/users/register -H 'Content-Type: application/json' \
  -d '{"phone":"13800138000","login_password":"12345678","admin_password":"123456","sms_code":"123456"}'
# 再输一次管理密码进管理（按原型 v155 原样，U17 已定）
curl -s -X POST http://127.0.0.1:8000/users/admin-password/verify -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' -d '{"admin_password":"123456"}'
# 绑定终端（16 位纯数字，首位类型码：1 嵌入式、2 安卓、3 苹果、4 鸿蒙、0 其他；5–9 预留，不许绑定，首位 5–9 拒 400 invalid_device_id，Nyx 189③）
curl -s -X POST http://127.0.0.1:8000/terminals/bind -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' -d '{"device_id":"2040059832773436"}'
# 扫码绑定（载荷带 JianTi- 前缀或纯 16 位数字都认；无真实扫码数据报 422）
curl -s -X POST http://127.0.0.1:8000/terminals/bind-scan -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' -d '{"scan_payload":"JianTi-3040059832773436"}'
# 查卡（每日默认 5 张，预支倍率默认 0；改倍率见 POST /cards/rules）
curl -s -X POST http://127.0.0.1:8000/cards/check -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' -d '{}'
# 拍题（只收 raw JPEG 且 < 8MB；非 JPEG 415、超大 413、未绑定终端 403）
curl -s -X POST http://127.0.0.1:8000/solve -H "Authorization: Bearer $TOKEN" \
  -H "X-Terminal-Id: 2040059832773436" -H "Idempotency-Key: <唯一键>" \
  -H 'Content-Type: image/jpeg' --data-binary @photo.jpg
# 轮询（1 秒一次、最多 60 秒，超时 50401；服务端不杀 job，见 TESTLOG.md §4）
curl -s http://127.0.0.1:8000/solve/<job_id> -H "Authorization: Bearer $TOKEN"
```

## 3. 接口（按模块；字段与错误码以《平台接口-20261116.md》为准）

| 模块 | 端点 | 说明 |
|---|---|---|
| 网关 | `GET /health`、`GET /lockscreen`、`GET /config/environment` | 健康检查；锁屏温度／MEMO（无数据源时 `---°C`／空串） |
| 账号 | `POST /users/register`、`/users/login`、`/auth/register`、`/auth/login`（别名）、`POST /users/admin-password/verify`、`/auth/admin-password/reset`、`POST /auth/passwords`（改密码）、`POST /auth/send-code`（短信 stub） | 注册即建虚拟家庭组；会话 token 48 位 hex，内存、不落盘、重启失效、无 TTL |
| 卡 | `POST /cards/check`、`/cards/deduct`、`/cards/advance`、`/cards/config`、`/cards/rules`（后两者同义） | 每日默认 5 张，倍率默认 0、最大 3，每次预支 1 张；同批同题只扣一次；无卡 402 |
| 申请单 | `POST /applications`、`GET /applications`、`POST /applications/{id}/approve`、`/reject`、`/withdraw` | 状态 `pending → approved｜rejected｜withdrawn`；只有 `pending` 能批／拒／撤；重发幂等（`Idempotency-Key`）；批准按张或按倍 |
| 终端 | `POST /terminals/bind`、`/terminals/bind-scan`、`GET /terminals`、`DELETE /terminals/{device_id}` | 16 位校验＋唯一性，重复 409；无真实扫码数据 422；解绑只认管理员（PRD 3.6 与接口 B6 口径不一致，见缺啥清单） |
| 判题 | `POST /solve`、`GET /solve/{job_id}`、`POST /solve/{job_id}/cancel`、`/skip` | 异步建 job（202），五阶段 `uploading／gateway／model／nlp／delivering`；无 Key 时 `model_not_connected` |
| 模型 | `GET /models`、`POST /models/select`、`POST /models/mcp-login`（别名 `/models/mcp/login`）、`POST /models/my-model` | 官方 5 个，JT Lite 2.0 默认；MCP 真校验（不存密码）；“我的模型”暂未开通，503，不收 Key |
| 服务器配置 | `GET /config/server`、`POST /config/server`、`POST /config/environment/memo` | 按家庭组分；官方／自有互斥，自有须填地址；下发方式是终端下次连接拉取，不主动推 |
| 通知 | `GET /push/pending` | 待拉取通知队列（申请消息记录＋拉取，无推送通道） |
| 用量／记录 | `GET /usage`、`GET /records` | 只返回真实入库的记录；无费用、无分模型次数、无充值档位（计价已停，U16 已定） |
| 家庭组 | `GET /family`、`POST /family/invite`、`/family/transfer`、`DELETE /family/members/{member_no}`、审批通过／拒绝（见 `families.py`） | 6 位邀请码；管理员邀请直接进组，非管理员邀请需审批；首个新成员加入翻固化，ID 不变；编号跟人走，删掉的不复用 |

通用规则：网关只做路由、鉴权、限流（通用每 IP 每分钟 120 次，`/solve` 每终端每分钟 10 次，超了 429 且带 `Retry-After: 5` 头，终端等 5 秒再由用户手动重试一次；接口文档“无该头时等 5 秒”的兜底句留着，见 ASSUMPTIONS.md V3-A1）；写操作建议带 `Idempotency-Key`，同键重发回存过的响应，不重复执行；错误一律 `{"error": {"code", "message"}}`。

## 4. 数据与快照

- 内存是权威状态；快照是 15 个分实体 JSON 文件（`accounts.json`、`family_groups.json`、`members.json`、`devices.json`、`bindings.json`、`card_ledgers.json`、`card_transactions.json`、`applications.json`、`idempotency.json`、`solve_sessions.json`、`usage_records.json`、`server_configs.json`、`model_configs.json`、`weather_memo.json`、`invites.json`），写时先写临时文件再逐个改名。v2 的 README §4 曾把其中 4 个写成旧名（`terminals.json`／`cards.json`／`jobs.json`／`records.json`，且漏了 `invites.json`），v3 已按 `store.py` 的磁盘实际名字改对（RECHECK #16，dsh 175d）。
- **快照损坏启动失败**：启动时任一快照损坏（坏 JSON／读失败）即报 `SnapshotCorruptError`、退出码 2，绝不静默按空库启动（骨架的毛病已修，见缺啥清单第 25 条→已修）。
- **快照写失败**：写操作返回 500 `internal_error`（“服务端内部错误：快照写入失败。”），内存里的改动仍在；同幂等键重试在磁盘修好前也 500，修好后不重启即恢复、返回存过的 200 响应（见 `TESTLOG.md` §3，自愈已实测）。
- 会话 token 不落盘，重启失效，须重新登录；其余状态（余额、防重扣标记、家庭组、绑定）随快照恢复。

## 5. 本版与骨架的不同（摘要，详见 `ASSUMPTIONS.md` §0 与缺啥清单）

- v6 新增（Nyx 2026-11-18 裁决，房间消息 id 498/500）：测试模式 `JIANTI_TEST_MODE=1`（默认关）：开时格式合法的 16 位设备号按已绑定处理（`/solve` 不再 403 `terminal_not_bound`，格式白名单不动、不写绑定记录）、无真 Key 的 `/solve` 走模拟模型（`judge.mock_judge_result()`，思路／答案明标“测试模拟”、job 打 `mock=true`／`result_source="mock"`，五阶段照常走完、扣卡与使用记录照常落）；关时未绑定仍 403、无 Key 仍 `model_not_connected` 503，与 v5 一字不差；启动日志与 `GET /health` 各带 `test_mode`。探针 `tests/probe_test_mode.sh`（见 `TESTLOG.md` §15）。
- v5 新增（Nyx 2026-11-17 裁决，房间消息 id 329 定法②）：keep-alive 下鉴权 401/403 报错前排空未读请求体（`_dispatch` 异常出口调 `_drain_body` 按 Content-Length 排空；`_read_json()` 与 `/solve` 记已读字节数，已读完不重排；`/solve` 图片不预读），同一连接下一请求不再从残留 body 处解析而 400；探针 `tests/probe_keepalive.py`（v4 上复现 PASS 9 FAIL 3，v5 上 PASS 12 FAIL 0，见 `TESTLOG.md` §14）。
- v4 新增（Nyx 2026-11-17 裁决，房间消息 id 284/285/232）：扫码绑 `scan_payload` 或 `qr_payload` 都认（RECHECK 补项 v4-1，文档 B5 要 `qr_payload`、App 发 `qr_payload`，v3 只读 `scan_payload` 会 422）；README §1 限流表环境变量名补 `_PER_MIN` 后缀（v4-2，代码本来就读带后缀的变量名，只改文档）。
- v3 新增（Nyx 2026-11-17 裁决，房间消息 id 170/174）：429 响应带 `Retry-After: 5` 头（RECHECK #10）；启动时扫尾僵尸 job——processing 超 120 秒标 failed，新 failure_reason `process_interrupted`，并补一条终态 usage 记录（RECHECK #15）；`GET /config/environment` 与 `GET /lockscreen` 标公开口、不需鉴权，`POST /config/environment/memo` 仍须管理员会话（RECHECK #14，见接口文档 A10）；README §4 快照清单按 `store.py` 磁盘实际名字改对（dsh 175d）。
- v2 新增（Nyx 2026-11-16 裁决）：`/solve`、扣卡、预支、建单、审批、不批六处幂等预检与业务同锁内原子完成，同键并发只执行一次（修了 v1 的真缺陷：10 路同键并发建出 10 个 job）；无题错误码统一为 `no_question`（旧名 `no_question_detected` 清掉）；冒烟含中文的 `-d` 请求体改 `--data-binary @file`（Windows GBK）。
- 预支倍率默认 0（骨架取原型值 1；手册 §2.3 定稿默认 0）。
- 快照由单文件改 15 个分实体文件；损坏启动失败（退出码 2），不再静默空库。
- 服务器配置与模型选择按家庭组分（骨架是全局单份）。
- 申请单支持幂等键重发去重（骨架没有）。
- 家庭组成员加入／审批／转让／删除已实现（骨架只有邀请码生成）：首个新成员加入翻固化。
- MCP 登录改真校验（只留内存临时验证码状态，密码不存、不建库）。
- 修了一个快照写失败时的卡 job 缺陷：`/solve` 先起判题线程再写快照，写失败也不让 job 永远卡在 processing（见 `TESTLOG.md` §3）。
- 仍是 stub：Qwen 真实调用（等部署时定）、短信验证码、温度／MEMO 数据源、真实扫码实现。

## 6. 文件清单

```
platform-server-v6/
  app.py            # 启动入口（默认 127.0.0.1:8000）
  gateway.py        # 网关：路由、鉴权、限流、幂等、/solve 异步判题、启动扫尾僵尸 job、TEST_MODE
  store.py          # 15 文件快照（原子改名；损坏启动失败退出码 2）
  models.py         # 实体与新记录构造（家庭组、成员、终端、申请单、job…；job 含 mock 标记）
  users.py          # 注册／登录／管理密码／邀请码生成
  cards.py          # 查卡／扣卡／预支／卡规则（今日剩余公式）
  applications.py   # 申请单创建／审批／拒绝／撤回
  binding.py        # 终端绑定（手动／扫码）、解绑、设备 ID 校验
  judge.py          # Qwen 主链路（无 Key 时 model_not_connected，绝不编答案）＋测试模式模拟判题
  records.py        # 记录写入与查询（服务端直接记）
  server_config.py  # 常量与服务器配置（官方／自有；TEST_MODE_ENV_VAR）
  push.py           # 待拉取通知队列
  families.py       # 家庭组：邀请／加入翻固化／转让／通过／拒绝／删除
  modelconfig.py    # 模型选择、MCP 真校验、“我的模型”503
  README.md         # 本文件
  TESTLOG.md        # 逐项实测结果（v6 测试模式见 §15）
  ASSUMPTIONS.md    # 自定项清单（每条标出来，不悄悄定死；v6 见 §8）
  缺啥清单-服务器端-v6.md  # 缺什么、哪个接口未定、下一版补什么
  tests/run_smoke.sh       # 冒烟测试（187 项）
  tests/conc_probe.py      # 并发探针：同键并发 POST /solve 只建 1 个 job
  tests/probe_no_question.py  # 改名探针：空判题结果时错误码为 no_question
  tests/probe_stale_jobs.py   # 僵尸 job 探针：启动扫尾标 failed/process_interrupted
  tests/probe_bind_scan_payload.sh  # 扫码绑双字段探针（v4 新增）：scan_payload / qr_payload 都认、都空仍 422
  tests/probe_keepalive.py  # keep-alive 探针（v5 新增）：同一连接鉴权 401/403 后紧接下一请求，不再 400
  tests/probe_test_mode.sh  # 测试模式探针（v6 新增）：开时全链路走通，关时 403／model_not_connected 不变
```
