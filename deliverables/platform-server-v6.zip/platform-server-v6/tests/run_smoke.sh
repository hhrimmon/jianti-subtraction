#!/bin/bash
# 简题平台服务器端 v6 冒烟测试：全部 curl 实测，断言计分。
# 用法：bash tests/run_smoke.sh
#   主实例：端口 18001，数据目录 /tmp/v6test-data（每次重建），
#   判题延迟 5 秒（测取消分支与轮询），通用限流调高以免套件自限流。
#   限流 429 另起默认限流实例测（见本脚本末尾）。
# 注意：脚本里出现的手机号／密码／Key 均为测试假数据，不是真实凭证。
set -u
cd "$(dirname "$0")/.."

PORT=18001
DATA=/tmp/v6test-data
BASE=http://127.0.0.1:$PORT
RESP=/tmp/v6test-resp.json
PASS=0; FAIL=0; FAILED_NAMES=""

# ---------- 小工具 ----------
note() { echo; echo "== $* =="; }
req() { # req METHOD PATH [curl args...]；回显并保存 BODY/CODE
  local method=$1 path=$2; shift 2
  local out
  out=$(curl -s -w "\n%{http_code}" -X "$method" "$BASE$path" "$@")
  CODE="${out##*$'\n'}"
  BODY="${out%$'\n'*}"
  printf '%s' "$BODY" > "$RESP"
  echo "[$CODE] $method $path -> $BODY"
}
jget() { python3 -c "import json;d=json.load(open('$RESP'));print($1 if $1 is not None else '')" 2>/dev/null; }
expect_code() { # expect_code 200 名称
  if [ "$CODE" = "$1" ]; then PASS=$((PASS+1)); echo "PASS: $2 (HTTP $1)";
  else FAIL=$((FAIL+1)); FAILED_NAMES="$FAILED_NAMES|$2"; echo "FAIL: $2 (want HTTP $1, got $CODE: $BODY)"; fi
}
expect_eq() { # expect_eq 实际 预期 名称
  if [ "$1" = "$2" ]; then PASS=$((PASS+1)); echo "PASS: $3 ($1)";
  else FAIL=$((FAIL+1)); FAILED_NAMES="$FAILED_NAMES|$3"; echo "FAIL: $3 (want [$2], got [$1])"; fi
}
expect_contains() { # expect_contains 名称 子串
  case "$BODY" in *"$2"*) PASS=$((PASS+1)); echo "PASS: $1";; *) FAIL=$((FAIL+1)); FAILED_NAMES="$FAILED_NAMES|$1"; echo "FAIL: $1 (body 缺少 [$2]: $BODY)";; esac
}
expect_absent() { # expect_absent 名称 子串
  case "$BODY" in *"$2"*) FAIL=$((FAIL+1)); FAILED_NAMES="$FAILED_NAMES|$1"; echo "FAIL: $1 (body 不应含 [$2]: $BODY)";; *) PASS=$((PASS+1)); echo "PASS: $1";; esac
}
poll_job() { # poll_job JOBID：轮询到非 processing，最多 20 秒
  local job=$1 i=0
  while [ $i -lt 20 ]; do
    req GET "/solve/$job" -H "Authorization: Bearer $TOKEN_A"
    st=$(jget "d.get('status')")
    [ "$st" != "processing" ] && return 0
    sleep 1; i=$((i+1))
  done
  return 1
}

# ---------- 准备测试图片 ----------
python3 -c "open('/tmp/tiny.jpg','wb').write(b'\xff\xd8\xff\xe0'+b'\x00'*100)"
python3 -c "open('/tmp/big.jpg','wb').write(b'\xff\xd8\xff'+b'\x00'*(9*1024*1024))"
printf 'hello' > /tmp/notjpeg.txt

# ---------- 启动主实例 ----------
rm -rf "$DATA"
JIANTI_PORT=$PORT JIANTI_DATA_DIR=$DATA JIANTI_JUDGE_DELAY_SECONDS=5 \
  JIANTI_RATE_LIMIT_GENERAL_PER_MIN=10000 python3 app.py > /tmp/v6test-server.log 2>&1 &
SRVPID=$!
sleep 1
kill -0 $SRVPID 2>/dev/null || { echo "服务器没起来"; cat /tmp/v6test-server.log; exit 1; }

note "0. 健康检查"
req GET /health
expect_code 200 "health 200"
expect_eq "$(jget "d.get('service')")" "jianti-platform-server-v6" "service 名 v6"
expect_eq "$(jget "d.get('model_connected')")" "False" "无 Key 时 model_connected=false"

note "1. 注册家庭组 A（13800138000）"
req POST /users/register -H 'Content-Type: application/json' \
  -d '{"phone":"13800138000","login_password":"12345678","admin_password":"123456","sms_code":"123456"}'
expect_code 201 "注册 201"
FAM_A=$(jget "d.get('family_id')")
TOKEN_A=$(jget "d.get('token')")
expect_eq "${#FAM_A}" 8 "家庭组 ID 8 位"
[ "$FAM_A" != "12345678" ] && { PASS=$((PASS+1)); echo "PASS: 家庭组 ID 不是演示值 12345678"; } || { FAIL=$((FAIL+1)); echo "FAIL: 家庭组 ID 是演示值"; }
expect_eq "$(jget "d.get('sms_code_stub')")" "True" "注册响应明标 sms_code_stub=true"
expect_eq "$(jget "d.get('next_step')")" "verify_admin_password" "注册下一步：再输一次管理密码"

req POST /users/register -H 'Content-Type: application/json' \
  -d '{"phone":"13800138000","login_password":"12345678","admin_password":"123456","sms_code":"123456"}'
expect_code 409 "重复手机号注册 409 phone_registered"

note "2. 未登录查卡 401；管理密码校验"
req POST /cards/check -H 'Content-Type: application/json' -d '{}'
expect_code 401 "无 token 查卡 401"
req POST /users/admin-password/verify -H "Authorization: Bearer $TOKEN_A" \
  -H 'Content-Type: application/json' -d '{"admin_password":"000000"}'
expect_code 401 "管理密码错 401"
req POST /users/admin-password/verify -H "Authorization: Bearer $TOKEN_A" \
  -H 'Content-Type: application/json' -d '{"admin_password":"123456"}'
expect_code 200 "管理密码对 verified=true"
# 未校验管理密码的新会话调管理接口应 403
req POST /users/login -H 'Content-Type: application/json' \
  -d '{"phone":"13800138000","login_password":"12345678"}'
expect_code 200 "登录 200"
TOKEN_A2=$(jget "d.get('token')")
req POST /cards/rules -H "Authorization: Bearer $TOKEN_A2" \
  -H 'Content-Type: application/json' -d '{"daily_total":5,"advance_ratio":1}'
expect_code 403 "未输管理密码调管理接口 403 admin_password_required"
req POST /users/admin-password/verify -H "Authorization: Bearer $TOKEN_A2" \
  -H 'Content-Type: application/json' -d '{"admin_password":"123456"}'
expect_code 200 "第二会话校验管理密码通过"

note "3. 查卡：每日默认 5 张，倍率默认 0"
req POST /cards/check -H "Authorization: Bearer $TOKEN_A" -H 'Content-Type: application/json' -d '{}'
expect_code 200 "查卡 200"
expect_eq "$(jget "d.get('balance')")" 5 "余额 5"
expect_eq "$(jget "d.get('advance_ratio')")" 0 "倍率默认 0（定稿）"
expect_eq "$(jget "d.get('advance_limit')")" 0 "预支上限 0"
expect_eq "$(jget "d.get('total_available')")" 5 "总可用 5"

note "4. 预支：倍率 0 时到上限 409；改倍率 1 后可预支，幂等键去重"
req POST /cards/advance -H "Authorization: Bearer $TOKEN_A" \
  -H "Idempotency-Key: adv-000" -H 'Content-Type: application/json' -d '{}'
expect_code 409 "倍率 0 预支 409 advance_limit_reached"
req POST /cards/rules -H "Authorization: Bearer $TOKEN_A" \
  -H 'Content-Type: application/json' -d '{"daily_total":5,"advance_ratio":1}'
expect_code 200 "改卡规则（倍率 1）200"
expect_eq "$(jget "d.get('balance')")" 5 "改规则后余额按 PRD 公式=新张数-已用=5"
req POST /cards/advance -H "Authorization: Bearer $TOKEN_A" \
  -H "Idempotency-Key: adv-001" -H 'Content-Type: application/json' -d '{}'
expect_code 200 "预支 1 张 200"
expect_eq "$(jget "d.get('balance')")" 6 "预支后余额 6"
expect_eq "$(jget "d.get('message')")" "解题卡已领取，请合理使用。" "预支文案一字不差"
req POST /cards/advance -H "Authorization: Bearer $TOKEN_A" \
  -H "Idempotency-Key: adv-001" -H 'Content-Type: application/json' -d '{}'
expect_eq "$(jget "d.get('balance')")" 6 "同一幂等键重发不重复预支（余额仍 6）"
req POST /cards/advance -H "Authorization: Bearer $TOKEN_A" \
  -H "Idempotency-Key: adv-002" -H 'Content-Type: application/json' -d '{}'
expect_eq "$(jget "d.get('balance')")" 7 "新幂等键预支余额 7"
req POST /cards/rules -H "Authorization: Bearer $TOKEN_A" \
  -H 'Content-Type: application/json' -d '{"daily_total":5,"advance_ratio":0}'
expect_eq "$(jget "d.get('balance')")" 5 "改回倍率 0：余额按 PRD 公式=5-已用 0=5（预支增量被公式折掉，见 ASSUMPTIONS V1-A2）"
req POST /cards/check -H "Authorization: Bearer $TOKEN_A" -H 'Content-Type: application/json' -d '{}'
expect_eq "$(jget "d.get('advanced_today')")" 2 "今日已预支 2 张仍有记录"

note "5. 绑定终端（手动／扫码），重复与跨组校验"
TERM_ANDROID=2040059832773436
req POST /terminals/bind -H "Authorization: Bearer $TOKEN_A" \
  -H 'Content-Type: application/json' -d "{\"device_id\":\"$TERM_ANDROID\",\"member_no\":1}"
expect_code 201 "手动绑安卓 201"
expect_eq "$(jget "d.get('terminal_no')")" 1 "终端编号 1"
expect_eq "$(jget "d.get('device_type')")" "安卓" "类型取码首位 2=安卓"
expect_eq "$(jget "d.get('already_bound')")" "False" "新绑定 already_bound=false"
req POST /terminals/bind -H "Authorization: Bearer $TOKEN_A" \
  -H 'Content-Type: application/json' -d "{\"device_id\":\"$TERM_ANDROID\"}"
expect_code 201 "同一家庭组重复绑定返回 200（已绑定，不重复加行）"
expect_eq "$(jget "d.get('already_bound')")" "True" "already_bound=true"
req POST /terminals/bind-scan -H "Authorization: Bearer $TOKEN_A" \
  -H 'Content-Type: application/json' -d '{"scan_payload":""}'
expect_code 422 "扫码无数据 422 scan_no_data"
req POST /terminals/bind-scan -H "Authorization: Bearer $TOKEN_A" \
  -H 'Content-Type: application/json' -d '{"scan_payload":"hello-qr"}'
expect_code 422 "扫码无合法 ID 422 scan_no_device_id"
req POST /terminals/bind-scan -H "Authorization: Bearer $TOKEN_A" \
  -H 'Content-Type: application/json' -d '{"scan_payload":"JianTi-3040059832773436"}'
expect_code 201 "扫码 JianTi- 前缀载荷绑苹果成功"
expect_eq "$(jget "d.get('device_type')")" "苹果" "类型取码首位 3=苹果"
expect_eq "$(jget "d.get('terminal_no')")" 2 "终端编号顺延 2"
req POST /terminals/bind-scan -H "Authorization: Bearer $TOKEN_A" \
  -H 'Content-Type: application/json' -d '{"scan_payload":"4040059832773436"}'
expect_code 201 "扫码纯 16 位数字绑鸿蒙成功"
expect_eq "$(jget "d.get('terminal_no')")" 3 "终端编号顺延 3"
req GET /terminals -H "Authorization: Bearer $TOKEN_A"
expect_code 200 "已绑定终端列表 200"
expect_eq "$(jget "len(d.get('items',[]))")" 3 "列表 3 台终端"

note "6. 家庭组 B 注册；跨组绑同一设备 409"
req POST /users/register -H 'Content-Type: application/json' \
  -d '{"phone":"13900138001","login_password":"12345678","admin_password":"123456","sms_code":"123456"}'
expect_code 201 "家庭组 B 注册 201"
FAM_B=$(jget "d.get('family_id')")
TOKEN_B=$(jget "d.get('token')")
req POST /users/admin-password/verify -H "Authorization: Bearer $TOKEN_B" \
  -H 'Content-Type: application/json' -d '{"admin_password":"123456"}' >/dev/null
req POST /terminals/bind -H "Authorization: Bearer $TOKEN_B" \
  -H 'Content-Type: application/json' -d "{\"device_id\":\"$TERM_ANDROID\"}"
expect_code 409 "跨组重复设备 ID 409 device_id_duplicate"
req GET /config/server -H "Authorization: Bearer $TOKEN_B"
expect_eq "$(jget "d.get('mode')")" "official" "B 组服务器配置默认官方（与 A 组独立）"

note "7. /solve 拒收分支"
req POST /solve -H "Authorization: Bearer $TOKEN_A" -H "X-Terminal-Id: $TERM_ANDROID" \
  -H 'Content-Type: image/jpeg' --data-binary @/tmp/tiny.jpg
expect_code 400 "缺 Idempotency-Key 400"
req POST /solve -H "Authorization: Bearer $TOKEN_A" -H "X-Terminal-Id: $TERM_ANDROID" \
  -H "Idempotency-Key: solve-bad-1" -H 'Content-Type: text/plain' --data-binary @/tmp/notjpeg.txt
expect_code 415 "非 JPEG 415 unsupported_media_type"
req POST /solve -H "Authorization: Bearer $TOKEN_A" -H "X-Terminal-Id: $TERM_ANDROID" \
  -H "Idempotency-Key: solve-bad-2" -H 'Content-Type: image/jpeg' --data-binary @/tmp/big.jpg
expect_code 413 "超 8MB 413 payload_too_large"
req POST /solve -H "Authorization: Bearer $TOKEN_A" -H "X-Terminal-Id: 9999059832773436" \
  -H "Idempotency-Key: solve-bad-3" -H 'Content-Type: image/jpeg' --data-binary @/tmp/tiny.jpg
expect_code 403 "未绑定终端 403 terminal_not_bound"
req POST /solve -H "Authorization: Bearer $TOKEN_A" \
  -H "Idempotency-Key: solve-bad-4" -H 'Content-Type: image/jpeg' --data-binary @/tmp/tiny.jpg
expect_code 400 "缺 X-Terminal-Id 400 missing_terminal_id"

note "8. /solve 有效 JPEG：202 异步建 job，轮询到 failed model_not_connected（stub）"
req POST /solve -H "Authorization: Bearer $TOKEN_A" -H "X-Terminal-Id: $TERM_ANDROID" \
  -H "Idempotency-Key: solve-ok-1" -H 'Content-Type: image/jpeg' --data-binary @/tmp/tiny.jpg
expect_code 202 "POST /solve 202 异步"
JOB1=$(jget "d.get('job_id')")
expect_eq "$(jget "d.get('status')")" "processing" "建 job 时 processing"
expect_eq "$(jget "d.get('stage')")" "model" "阶段停在 model（判题中）"
expect_eq "$(jget "d.get('poll',{}).get('timeout_code')")" "50401" "轮询超时码 50401 在响应里"
poll_job "$JOB1"
expect_eq "$(jget "d.get('status')")" "failed" "轮询终态 failed"
expect_eq "$(jget "d.get('error',{}).get('code')")" "model_not_connected" "失败码 model_not_connected，不编假答案"
expect_eq "$(jget "d.get('thinking')")" "" "思路为空（null）"
expect_eq "$(jget "d.get('answer')")" "" "答案为空（null）"
expect_eq "$(jget "d.get('failure_reason')")" "model_unavailable" "failure_reason=model_unavailable"
# 同一幂等键重发同一张照片：返回同一个 job，不新建
req POST /solve -H "Authorization: Bearer $TOKEN_A" -H "X-Terminal-Id: $TERM_ANDROID" \
  -H "Idempotency-Key: solve-ok-1" -H 'Content-Type: image/jpeg' --data-binary @/tmp/tiny.jpg
expect_eq "$(jget "d.get('job_id')")" "$JOB1" "同一幂等键重发返回同一 job"

note "9. 取消未决任务（判题延迟 5 秒窗口内取消）"
req POST /solve -H "Authorization: Bearer $TOKEN_A" -H "X-Terminal-Id: $TERM_ANDROID" \
  -H "Idempotency-Key: solve-cancel-1" -H 'Content-Type: image/jpeg' --data-binary @/tmp/tiny.jpg
JOB2=$(jget "d.get('job_id')")
req POST "/solve/$JOB2/cancel" -H "Authorization: Bearer $TOKEN_A" -H 'Content-Type: application/json' -d '{}'
expect_code 200 "取消进行中的 job 200"
expect_eq "$(jget "d.get('status')")" "cancelled" "取消后状态 cancelled"
sleep 6
req GET "/solve/$JOB2" -H "Authorization: Bearer $TOKEN_A"
expect_eq "$(jget "d.get('status')")" "cancelled" "判题线程未覆盖已取消的 job"
req POST "/solve/$JOB2/cancel" -H "Authorization: Bearer $TOKEN_A" -H 'Content-Type: application/json' -d '{}'
expect_code 409 "已终结的 job 再取消 409"
req POST "/solve/$JOB1/skip" -H "Authorization: Bearer $TOKEN_A" -H 'Content-Type: application/json' -d '{"question_index":0}'
expect_code 200 "跳过记录 200 skipped=true"

note "10. 扣卡：防重扣＋幂等键；无卡 402"
req POST /cards/deduct -H "Authorization: Bearer $TOKEN_A" \
  -H "Idempotency-Key: ded-001" -H 'Content-Type: application/json' \
  -d '{"batch_id":"batch-001","question_index":0}'
expect_code 200 "扣卡 200"
expect_eq "$(jget "d.get('deducted')")" "True" "扣卡成功"
expect_eq "$(jget "d.get('balance')")" 4 "扣卡后余额 4"
req POST /cards/deduct -H "Authorization: Bearer $TOKEN_A" \
  -H "Idempotency-Key: ded-001" -H 'Content-Type: application/json' \
  -d '{"batch_id":"batch-001","question_index":0}'
expect_eq "$(jget "d.get('balance')")" 4 "同一幂等键重发不重复扣卡"
req POST /cards/deduct -H "Authorization: Bearer $TOKEN_A" \
  -H "Idempotency-Key: ded-002" -H 'Content-Type: application/json' \
  -d '{"batch_id":"batch-001","question_index":0}'
expect_eq "$(jget "d.get('already_unlocked')")" "True" "同一批同一题再点不扣卡 already_unlocked"
expect_eq "$(jget "d.get('balance')")" 4 "余额不变 4"
req POST /cards/deduct -H "Authorization: Bearer $TOKEN_A" \
  -H 'Content-Type: application/json' -d '{"batch_id":"batch-001","question_index":0}'
expect_code 400 "扣卡缺幂等键 400"
req POST /cards/rules -H "Authorization: Bearer $TOKEN_A" \
  -H 'Content-Type: application/json' -d '{"daily_total":1,"advance_ratio":0}'
expect_eq "$(jget "d.get('balance')")" 0 "每日改 1 张：余额=1-已用 1=0"
req POST /cards/deduct -H "Authorization: Bearer $TOKEN_A" \
  -H "Idempotency-Key: ded-003" -H 'Content-Type: application/json' \
  -d '{"batch_id":"batch-002","question_index":0}'
expect_code 402 "无卡扣卡 402 no_cards"
req POST /cards/rules -H "Authorization: Bearer $TOKEN_A" \
  -H 'Content-Type: application/json' -d '{"daily_total":5,"advance_ratio":0}'
expect_eq "$(jget "d.get('balance')")" 4 "每日改回 5 张：余额=5-已用 1=4"

note "11. 申请单：创建／幂等／重复待批／待批列表／待拉取通知"
req POST /applications -H "Authorization: Bearer $TOKEN_A" -H "X-Terminal-Id: $TERM_ANDROID" \
  -H "Idempotency-Key: app-001" -H 'Content-Type: application/json' \
  -d "{\"terminal_id\":\"$TERM_ANDROID\",\"question_id\":\"q1\",\"requested\":{\"grant_type\":\"count\",\"value\":2}}"
expect_code 201 "创建申请单 201"
APP1=$(jget "d.get('application_id')")
expect_eq "$(jget "d.get('status')")" "pending" "申请单待批"
req POST /applications -H "Authorization: Bearer $TOKEN_A" -H "X-Terminal-Id: $TERM_ANDROID" \
  -H "Idempotency-Key: app-001" -H 'Content-Type: application/json' \
  -d "{\"terminal_id\":\"$TERM_ANDROID\",\"question_id\":\"q1\"}"
expect_eq "$(jget "d.get('application_id')")" "$APP1" "同一幂等键重发返回同一申请单"
req POST /applications -H "Authorization: Bearer $TOKEN_A" -H "X-Terminal-Id: $TERM_ANDROID" \
  -H "Idempotency-Key: app-002" -H 'Content-Type: application/json' \
  -d "{\"terminal_id\":\"$TERM_ANDROID\",\"question_id\":\"q1\"}"
expect_code 409 "同一终端同一题已有待批单 409 application_duplicate_pending"
req GET "/applications?status=pending" -H "Authorization: Bearer $TOKEN_A"
expect_code 200 "待批列表 200"
expect_eq "$(jget "d.get('total')")" 1 "待批 1 张"
req GET /push/pending -H "Authorization: Bearer $TOKEN_A"
expect_eq "$(jget "len(d.get('pending',[]))")" 1 "待拉取通知队列 1 条（申请消息）"

note "12. 审批：未校验管理密码 403；按张批 2 张；幂等；重复批 409"
# 先用一个全新会话（未输管理密码）测 403
req POST /users/login -H 'Content-Type: application/json' \
  -d '{"phone":"13800138000","login_password":"12345678"}'
TOKEN_FRESH=$(jget "d.get('token')")
req POST "/applications/$APP1/approve" -H "Authorization: Bearer $TOKEN_FRESH" \
  -H "Idempotency-Key: apr-001" -H 'Content-Type: application/json' \
  -d '{"grant_type":"count","value":2}'
expect_code 403 "未输管理密码审批 403"
req POST "/applications/$APP1/approve" -H "Authorization: Bearer $TOKEN_A" \
  -H "Idempotency-Key: apr-001" -H 'Content-Type: application/json' \
  -d '{"grant_type":"count","value":2}'
expect_code 200 "批准按张 2 张 200"
expect_eq "$(jget "d.get('granted',{}).get('cards')")" 2 "发卡 2 张"
expect_eq "$(jget "d.get('balance')")" 6 "批后余额 4+2=6"
req POST "/applications/$APP1/approve" -H "Authorization: Bearer $TOKEN_A" \
  -H "Idempotency-Key: apr-001" -H 'Content-Type: application/json' \
  -d '{"grant_type":"count","value":2}'
expect_eq "$(jget "d.get('balance')")" 6 "同一幂等键重批不重复记账"
req POST "/applications/$APP1/approve" -H "Authorization: Bearer $TOKEN_A" \
  -H "Idempotency-Key: apr-002" -H 'Content-Type: application/json' \
  -d '{"grant_type":"count","value":2}'
expect_code 409 "已决申请单再批 409 application_decided"

note "13. 不批／撤回／再批拦截；按倍批准"
req POST /applications -H "Authorization: Bearer $TOKEN_A" -H "X-Terminal-Id: $TERM_ANDROID" \
  -H "Idempotency-Key: app-003" -H 'Content-Type: application/json' \
  -d "{\"terminal_id\":\"$TERM_ANDROID\",\"question_id\":\"q2\"}"
APP2=$(jget "d.get('application_id')")
req POST "/applications/$APP2/reject" -H "Authorization: Bearer $TOKEN_A" \
  -H "Idempotency-Key: rej-001" -H 'Content-Type: application/json' -d '{}'
expect_code 200 "不批 200"
expect_eq "$(jget "d.get('status')")" "rejected" "状态 rejected"
req POST "/applications/$APP2/reject" -H "Authorization: Bearer $TOKEN_A" \
  -H "Idempotency-Key: rej-002" -H 'Content-Type: application/json' -d '{}'
expect_code 409 "已决单再不批 409"
req POST /applications -H "Authorization: Bearer $TOKEN_A" -H "X-Terminal-Id: $TERM_ANDROID" \
  -H "Idempotency-Key: app-004" -H 'Content-Type: application/json' \
  -d "{\"terminal_id\":\"$TERM_ANDROID\",\"question_id\":\"q3\"}"
APP3=$(jget "d.get('application_id')")
req POST "/applications/$APP3/withdraw" -H "Authorization: Bearer $TOKEN_A" \
  -H 'Content-Type: application/json' -d '{}'
expect_code 200 "撤回 200"
req POST "/applications/$APP3/approve" -H "Authorization: Bearer $TOKEN_A" \
  -H "Idempotency-Key: apr-003" -H 'Content-Type: application/json' \
  -d '{"grant_type":"count","value":1}'
expect_code 409 "撤回后家长端不得再批 409 application_withdrawn"
req POST /applications -H "Authorization: Bearer $TOKEN_A" -H "X-Terminal-Id: $TERM_ANDROID" \
  -H "Idempotency-Key: app-005" -H 'Content-Type: application/json' \
  -d "{\"terminal_id\":\"$TERM_ANDROID\",\"question_id\":\"q4\"}"
APP4=$(jget "d.get('application_id')")
req POST "/applications/$APP4/approve" -H "Authorization: Bearer $TOKEN_A" \
  -H "Idempotency-Key: apr-004" -H 'Content-Type: application/json' \
  -d '{"grant_type":"ratio","value":1}'
expect_code 200 "按倍批准（1 倍=每日 5 张）200"
expect_eq "$(jget "d.get('granted',{}).get('cards')")" 5 "按倍发 5 张"
expect_eq "$(jget "d.get('balance')")" 11 "余额 6+5=11"

note "14. 模型：列表／选择／我的模型 503／MCP 真校验"
req GET /models -H "Authorization: Bearer $TOKEN_A"
expect_code 200 "模型列表 200"
expect_eq "$(jget "len(d.get('items',[]))")" 5 "官方 5 个模型"
expect_eq "$(jget "d.get('selected_model')")" "jt-lite-2.0" "默认 JT Lite 2.0"
req POST /models/select -H "Authorization: Bearer $TOKEN_A" \
  -H 'Content-Type: application/json' -d '{"model_id":"qwen-3.8","line":"official"}'
expect_code 200 "选 Qwen 3.8 200"
req POST /models/select -H "Authorization: Bearer $TOKEN_A" \
  -H 'Content-Type: application/json' -d '{"model_id":"gpt-4.0","line":"official"}'
expect_code 400 "选不在 5 个内的模型 400"
req POST /models/select -H "Authorization: Bearer $TOKEN_A" \
  -H 'Content-Type: application/json' -d '{"line":"my"}'
expect_code 400 "选我的模型线 400（暂未开通）"
req POST /models/my-model -H "Authorization: Bearer $TOKEN_A" \
  -H 'Content-Type: application/json' -d '{"api_key":"test-key-xxx"}'
expect_code 503 "我的模型 503，不收 Key"
expect_absent "响应里不含提交的 Key" "test-key-xxx"
req POST /models/select -H "Authorization: Bearer $TOKEN_A" \
  -H 'Content-Type: application/json' -d '{"model_id":"jt-lite-2.0","line":"official"}'
expect_code 200 "选回 JT Lite 2.0"
req POST /models/mcp-login -H "Authorization: Bearer $TOKEN_A" \
  -H 'Content-Type: application/json' \
  -d '{"site_url":"http://example.com","account":"a","password":"pw-test-001"}'
expect_code 400 "MCP 非 https 400"
req POST /models/mcp-login -H "Authorization: Bearer $TOKEN_A" \
  -H 'Content-Type: application/json' \
  -d '{"site_url":"https://nonexistent.invalid","account":"a","password":"pw-test-001"}'
expect_code 503 "MCP 不可达网站 503 mcp_site_unreachable（真实调用，未伪造）"
expect_absent "不可达响应不含密码" "pw-test-001"
req POST /models/mcp-login -H "Authorization: Bearer $TOKEN_A" \
  -H 'Content-Type: application/json' \
  -d '{"site_url":"https://example.com","account":"a","password":"pw-test-001"}'
expect_code 501 "MCP 无登录口网站 501 mcp_login_unsupported（真实调用，未伪造成功）"
expect_absent "501 响应不含密码" "pw-test-001"

note "15. 服务器配置按家庭组分"
req POST /config/server -H "Authorization: Bearer $TOKEN_A" \
  -H 'Content-Type: application/json' -d '{"mode":"custom"}'
expect_code 400 "改自有不填地址 400"
req POST /config/server -H "Authorization: Bearer $TOKEN_A" \
  -H 'Content-Type: application/json' -d '{"mode":"custom","custom_address":"192.168.1.10:8000"}'
expect_code 200 "A 组改自有 200"
req GET /config/server -H "Authorization: Bearer $TOKEN_B"
expect_eq "$(jget "d.get('mode')")" "official" "B 组仍是官方（按家庭组分，不互相覆盖）"
req GET /config/server -H "Authorization: Bearer $TOKEN_A"
expect_eq "$(jget "d.get('custom_address')")" "192.168.1.10:8000" "A 组自有地址已存"
req POST /config/server -H "Authorization: Bearer $TOKEN_A" \
  -H 'Content-Type: application/json' -d '{"mode":"official"}'
expect_eq "$(jget "d.get('custom_address')")" "" "切回官方清空自有地址（互斥）"

note "16. 用量／记录：只返回真实记录，不含费用字段"
req GET "/usage?range=7d" -H "Authorization: Bearer $TOKEN_A"
expect_code 200 "用量 200"
expect_eq "$(jget "d.get('photo_success')")" 0 "拍题成功 0 次（stub 无成功判题）"
expect_eq "$(jget "d.get('thinking_count')")" 0 "做题思路 0 道"
expect_eq "$(jget "d.get('cards_used')")" 1 "解题用卡 1 张"
expect_eq "$(jget "d.get('temperature')")" "---°C" "无温度数据 ---°C"
expect_absent "用量响应无 cost 字段（计价已停）" "cost"
expect_absent "用量响应无 price 字段" "price"
req GET "/records?range=7d" -H "Authorization: Bearer $TOKEN_A"
expect_code 200 "记录 200"
expect_eq "$(jget "d.get('total')")" 15 "记录共 15 条（真实事件：失败 1＋跳过 1＋扣卡 1＋预支 2＋发卡 2＋申请 8）"
expect_eq "$(jget "d.get('summary',{}).get('cards_used')")" 1 "记录汇总解题用卡 1 张"
ITEM0_SRC=$(jget "d.get('items',[{}])[0].get('source')")
echo "最新一条记录来源：$ITEM0_SRC"
[ -n "$ITEM0_SRC" ] && { PASS=$((PASS+1)); echo "PASS: 记录有来源列"; } || { FAIL=$((FAIL+1)); echo "FAIL: 记录无来源列"; }

note "17. 温度／MEMO 下发与设置"
req GET /config/environment
expect_code 200 "环境信息 200（无需登录）"
expect_eq "$(jget "d.get('temperature')")" "---°C" "温度 ---°C"
expect_eq "$(jget "d.get('memo')")" "" "MEMO 为空"
# v2：含中文的请求体不用 curl -d 行内传，改写文件再 --data-binary @file
# （Nyx 146 定：Windows GBK 下 -d 行内中文会被转码，服务端 JSON 解析失败；
#  @file 直接读磁盘字节，不走命令行转码。）
printf '%s' '{"memo":"今天也要加油。"}' > /tmp/v6test-memo.json
req POST /config/environment/memo -H "Authorization: Bearer $TOKEN_A" \
  -H 'Content-Type: application/json' --data-binary @/tmp/v6test-memo.json
expect_code 200 "管理员设置 MEMO 200"
req GET /lockscreen
expect_eq "$(jget "d.get('memo')")" "今天也要加油。" "锁屏读到新 MEMO"

note "18. 短信验证码 stub 明标；auth 别名；改密码"
req POST /auth/send-code -H 'Content-Type: application/json' \
  -d '{"phone":"13800138000","purpose":"register"}'
expect_code 503 "发短信验证码 503 sms_not_configured（stub 明标）"
req POST /auth/register -H 'Content-Type: application/json' \
  -d '{"phone":"13700137000","code":"123456","password":"12345678","admin_password":"123456"}'
expect_code 201 "auth/register 别名 201"
TOKEN_C=$(jget "d.get('token')")
req POST /auth/login -H 'Content-Type: application/json' \
  -d '{"phone":"13700137000","password":"12345678"}'
expect_code 200 "auth/login 别名 200"
req POST /users/admin-password/verify -H "Authorization: Bearer $TOKEN_C" \
  -H 'Content-Type: application/json' -d '{"admin_password":"123456"}' >/dev/null
req POST /auth/passwords -H "Authorization: Bearer $TOKEN_C" \
  -H 'Content-Type: application/json' \
  -d '{"type":"login","old_password":"12345678","new_password":"87654321","new_password_confirm":"87654321"}'
expect_code 200 "改登录密码 200"
req POST /auth/login -H 'Content-Type: application/json' \
  -d '{"phone":"13700137000","password":"87654321"}'
expect_code 200 "新密码可登录"
req POST /auth/login -H 'Content-Type: application/json' \
  -d '{"phone":"13700137000","password":"12345678"}'
expect_code 401 "旧密码已失效 401"
req POST /auth/admin-password/reset -H 'Content-Type: application/json' \
  -d '{"phone":"13700137000","code":"123456","new_admin_password":"654321"}'
expect_code 200 "重置管理密码 200"
expect_eq "$(jget "d.get('sms_code_stub')")" "True" "重置响应明标 sms stub"

note "19. 解绑：管理员可解绑；解绑后终端拒收；重复解绑 404；重绑编号顺延"
req DELETE "/terminals/4040059832773436" -H "Authorization: Bearer $TOKEN_A"
expect_code 200 "管理员解绑 200"
req POST /solve -H "Authorization: Bearer $TOKEN_A" -H "X-Terminal-Id: 4040059832773436" \
  -H "Idempotency-Key: solve-unbound-1" -H 'Content-Type: image/jpeg' --data-binary @/tmp/tiny.jpg
expect_code 403 "已解绑终端拍题 403 terminal_not_bound"
req DELETE "/terminals/4040059832773436" -H "Authorization: Bearer $TOKEN_A"
expect_code 404 "重复解绑 404 terminal_not_found"
req POST /terminals/bind-scan -H "Authorization: Bearer $TOKEN_A" \
  -H 'Content-Type: application/json' -d '{"scan_payload":"4040059832773436"}'
expect_code 201 "重绑同一设备 201"
expect_eq "$(jget "d.get('terminal_no')")" 4 "重绑编号顺延 4（不复用）"
expect_eq "$(jget "d.get('already_bound')")" "False" "重绑是新绑定 already_bound=false"

note "20. 家庭组：邀请／加入翻固化／转让／通过／拒绝／删除"
req GET /family -H "Authorization: Bearer $TOKEN_A"
expect_code 200 "家庭组 200"
expect_eq "$(jget "d.get('status')")" "virtual" "注册时虚拟组"
expect_eq "$(jget "len(d.get('members',[]))")" 1 "成员 1 人"
req POST /family/invite -H "Authorization: Bearer $TOKEN_A" -H 'Content-Type: application/json' -d '{}'
expect_code 200 "管理员邀请 200"
INV1=$(jget "d.get('invite_code')")
expect_eq "$(jget "d.get('direct_join')")" "True" "管理员邀请直接进组"
req POST /users/register -H 'Content-Type: application/json' \
  -d "{\"phone\":\"13500138004\",\"login_password\":\"12345678\",\"admin_password\":\"654321\",\"sms_code\":\"123456\",\"invite_code\":\"$INV1\"}"
expect_code 201 "成员 2 凭邀请码加入 201"
expect_eq "$(jget "d.get('role')")" "成员" "成员 2 角色成员"
TOKEN_M2=$(jget "d.get('token')")
req GET /family -H "Authorization: Bearer $TOKEN_A"
expect_eq "$(jget "d.get('status')")" "solidified" "首个新成员加入后翻固化（ID 不变）"
expect_eq "$(jget "d.get('family_group_id')")" "$FAM_A" "家庭组 ID 不变"
expect_eq "$(jget "len(d.get('members',[]))")" 2 "成员 2 人"
# 转让管理员给成员 2
req POST /users/admin-password/verify -H "Authorization: Bearer $TOKEN_M2" \
  -H 'Content-Type: application/json' -d '{"admin_password":"654321"}' >/dev/null
req POST /family/transfer -H "Authorization: Bearer $TOKEN_A" \
  -H 'Content-Type: application/json' -d '{"to_member_no":2}'
expect_code 200 "转让管理员给成员 2 200"
expect_eq "$(jget "d.get('admin_member_no')")" 2 "新管理员编号 2"
req POST /family/transfer -H "Authorization: Bearer $TOKEN_M2" \
  -H 'Content-Type: application/json' -d '{"to_member_no":99}'
expect_code 400 "转让给不存在的成员 400"
# 成员 1 现为非管理员：解绑应 403；成员 2（新管理员）可解绑
req DELETE "/terminals/3040059832773436" -H "Authorization: Bearer $TOKEN_A"
expect_code 403 "非管理员解绑 403 forbidden"
req DELETE "/terminals/3040059832773436" -H "Authorization: Bearer $TOKEN_M2"
expect_code 200 "新管理员解绑 200"
# 非管理员邀请需审批：成员 1 邀请 -> 成员 3 待审批 -> 通过；成员 4 拒绝
req POST /family/invite -H "Authorization: Bearer $TOKEN_A" -H 'Content-Type: application/json' -d '{}'
INV2=$(jget "d.get('invite_code')")
expect_eq "$(jget "d.get('direct_join')")" "False" "非管理员邀请不直接进组"
req POST /users/register -H 'Content-Type: application/json' \
  -d "{\"phone\":\"13600138005\",\"login_password\":\"12345678\",\"admin_password\":\"123456\",\"sms_code\":\"123456\",\"invite_code\":\"$INV2\"}"
expect_eq "$(jget "d.get('role')")" "待审批" "成员 3 待审批"
req GET /family -H "Authorization: Bearer $TOKEN_M2"
expect_eq "$(jget "len(d.get('members',[]))")" 3 "待审批成员也在列表里（3 人）"
req POST /family/members/3/approve -H "Authorization: Bearer $TOKEN_M2" \
  -H 'Content-Type: application/json' -d '{}'
expect_code 200 "管理员通过成员 3 200"
req POST /users/register -H 'Content-Type: application/json' \
  -d "{\"phone\":\"13600138006\",\"login_password\":\"12345678\",\"admin_password\":\"123456\",\"sms_code\":\"123456\",\"invite_code\":\"$INV2\"}"
expect_eq "$(jget "d.get('role')")" "待审批" "成员 4 待审批"
req POST /family/members/4/reject -H "Authorization: Bearer $TOKEN_M2" \
  -H 'Content-Type: application/json' -d '{}'
expect_code 200 "管理员拒绝成员 4 200"
req GET /family -H "Authorization: Bearer $TOKEN_M2"
expect_eq "$(jget "len(d.get('members',[]))")" 3 "拒绝后成员 4 的行消失（剩 3 人）"
req DELETE /family/members/2 -H "Authorization: Bearer $TOKEN_M2"
expect_code 400 "管理员不能直接删自己 400"
req DELETE /family/members/1 -H "Authorization: Bearer $TOKEN_A"
expect_code 403 "非管理员删除成员 403"
req DELETE /family/members/3 -H "Authorization: Bearer $TOKEN_M2"
expect_code 200 "管理员删除成员 3 200"
# B 组申请单越权：A 的单 B 批不到
req POST "/applications/$APP1/approve" -H "Authorization: Bearer $TOKEN_B" \
  -H "Idempotency-Key: apr-x" -H 'Content-Type: application/json' \
  -d '{"grant_type":"count","value":1}'
expect_code 404 "别家申请单批不到 404（不泄露）"

note "21. 重启后快照恢复（余额／防重扣／家庭组／绑定都在，会话失效）"
BAL_BEFORE=$(curl -s -X POST "$BASE/cards/check" -H "Authorization: Bearer $TOKEN_A" -H 'Content-Type: application/json' -d '{}' | python3 -c "import json,sys;print(json.load(sys.stdin)['balance'])")
echo "重启前余额：$BAL_BEFORE"
kill $SRVPID; sleep 1
JIANTI_PORT=$PORT JIANTI_DATA_DIR=$DATA JIANTI_JUDGE_DELAY_SECONDS=5 \
  JIANTI_RATE_LIMIT_GENERAL_PER_MIN=10000 python3 app.py > /tmp/v6test-server2.log 2>&1 &
SRVPID=$!
sleep 1
req GET /health
expect_code 200 "重启后 health 200"
req POST /cards/check -H "Authorization: Bearer $TOKEN_A" -H 'Content-Type: application/json' -d '{}'
expect_code 401 "重启后旧 token 失效 401（会话不落盘）"
req POST /users/login -H 'Content-Type: application/json' \
  -d '{"phone":"13800138000","login_password":"12345678"}'
expect_code 200 "重启后重新登录 200"
TOKEN_A=$(jget "d.get('token')")
req POST /users/admin-password/verify -H "Authorization: Bearer $TOKEN_A" \
  -H 'Content-Type: application/json' -d '{"admin_password":"123456"}' >/dev/null
req POST /cards/check -H "Authorization: Bearer $TOKEN_A" -H 'Content-Type: application/json' -d '{}'
expect_eq "$(jget "d.get('balance')")" "$BAL_BEFORE" "重启后余额恢复（$BAL_BEFORE）"
req POST /cards/deduct -H "Authorization: Bearer $TOKEN_A" \
  -H "Idempotency-Key: ded-restart-1" -H 'Content-Type: application/json' \
  -d '{"batch_id":"batch-001","question_index":0}'
expect_eq "$(jget "d.get('already_unlocked')")" "True" "重启后防重扣标记仍有效"
req GET /family -H "Authorization: Bearer $TOKEN_A"
expect_eq "$(jget "d.get('status')")" "solidified" "重启后家庭组仍是已固化"
req GET /terminals -H "Authorization: Bearer $TOKEN_A"
expect_eq "$(jget "len(d.get('items',[]))")" 2 "重启后绑定终端 2 台（2040＋重绑的 4040；3040 已解绑）"

note "22. 快照损坏：启动失败告警（退出码 2），不静默按空库启动"
kill $SRVPID; sleep 1
CORRUPT=/tmp/v6test-corrupt
rm -rf "$CORRUPT"; cp -r "$DATA" "$CORRUPT"
echo '{损坏的 json,,,' > "$CORRUPT/applications.json"
JIANTI_PORT=18002 JIANTI_DATA_DIR=$CORRUPT python3 app.py > /tmp/v6test-corrupt.log 2>&1
CORRUPT_CODE=$?
echo "损坏快照启动退出码：$CORRUPT_CODE"
cat /tmp/v6test-corrupt.log
if [ "$CORRUPT_CODE" = "2" ] && grep -q "启动失败" /tmp/v6test-corrupt.log; then
  PASS=$((PASS+1)); echo "PASS: 快照损坏启动失败（退出 2，有告警）"
else
  FAIL=$((FAIL+1)); FAILED_NAMES="$FAILED_NAMES|快照损坏启动失败"; echo "FAIL: 快照损坏应启动失败"
fi
# 快照文件清单
ls "$DATA"
[ -f "$DATA/accounts.json" ] && [ -f "$DATA/family_groups.json" ] && [ -f "$DATA/members.json" ] \
  && [ -f "$DATA/devices.json" ] && [ -f "$DATA/bindings.json" ] \
  && [ -f "$DATA/card_ledgers.json" ] && [ -f "$DATA/card_transactions.json" ] \
  && [ -f "$DATA/applications.json" ] && [ -f "$DATA/idempotency.json" ] \
  && [ -f "$DATA/solve_sessions.json" ] && [ -f "$DATA/usage_records.json" ] \
  && [ -f "$DATA/server_configs.json" ] && [ -f "$DATA/model_configs.json" ] \
  && [ -f "$DATA/weather_memo.json" ] && [ -f "$DATA/invites.json" ] \
  && { PASS=$((PASS+1)); echo "PASS: 15 个分实体快照文件都在"; } \
  || { FAIL=$((FAIL+1)); FAILED_NAMES="$FAILED_NAMES|分实体快照文件"; echo "FAIL: 快照文件缺失"; }
[ -f "$DATA/sessions.json" ] && { FAIL=$((FAIL+1)); echo "FAIL: 会话不应落盘"; } || { PASS=$((PASS+1)); echo "PASS: 会话 token 不落盘"; }

note "23. 限流 429（默认限流实例：通用 120／分钟、/solve 每终端 10／分钟）"
rm -rf /tmp/v6test-rate; mkdir -p /tmp/v6test-rate
JIANTI_PORT=18003 JIANTI_DATA_DIR=/tmp/v6test-rate python3 app.py > /tmp/v6test-rate.log 2>&1 &
RPID=$!
sleep 1
RBASE=http://127.0.0.1:18003
# 通用限流：121 次 /health，第 121 次应 429
LAST=0
for i in $(seq 1 121); do
  LAST=$(curl -s -o /dev/null -w "%{http_code}" "$RBASE/health")
done
expect_eq "$LAST" 429 "第 121 次通用请求 429 rate_limited"
# v3（RECHECK #10）：429 响应须带 Retry-After: 5 头
RH=$(curl -s -D - -o /dev/null "$RBASE/health" | grep -i "^Retry-After:" | tr -d '\r' | awk '{print $2}')
expect_eq "$RH" "5" "429 带 Retry-After: 5"
kill $RPID; sleep 1
# /solve 限流：另起实例（通用桶已空），同一终端 11 次 /solve
rm -rf /tmp/v6test-rate2; mkdir -p /tmp/v6test-rate2
JIANTI_PORT=18004 JIANTI_DATA_DIR=/tmp/v6test-rate2 python3 app.py > /tmp/v6test-rate2.log 2>&1 &
RPID=$!
sleep 1
RBASE=http://127.0.0.1:18004
RT=$(curl -s -X POST "$RBASE/users/register" -H 'Content-Type: application/json' \
  -d '{"phone":"13800138000","login_password":"12345678","admin_password":"123456","sms_code":"123456"}' \
  | python3 -c "import json,sys;print(json.load(sys.stdin)['token'])")
curl -s -X POST "$RBASE/users/admin-password/verify" -H "Authorization: Bearer $RT" \
  -H 'Content-Type: application/json' -d '{"admin_password":"123456"}' >/dev/null
curl -s -X POST "$RBASE/terminals/bind" -H "Authorization: Bearer $RT" \
  -H 'Content-Type: application/json' -d '{"device_id":"2040059832773436"}' >/dev/null
LAST=0
for i in $(seq 1 11); do
  LAST=$(curl -s -o /dev/null -w "%{http_code}" -X POST "$RBASE/solve" \
    -H "Authorization: Bearer $RT" -H "X-Terminal-Id: 2040059832773436" \
    -H "Idempotency-Key: rl-$i" -H 'Content-Type: image/jpeg' --data-binary @/tmp/tiny.jpg)
done
expect_eq "$LAST" 429 "同一终端第 11 次 /solve 429"
kill $RPID 2>/dev/null; sleep 1

# ---------- 汇总 ----------
echo
echo "=================================="
echo "PASS: $PASS  FAIL: $FAIL"
[ -n "$FAILED_NAMES" ] && echo "失败项：$FAILED_NAMES"
echo "=================================="
[ "$FAIL" = "0" ]
