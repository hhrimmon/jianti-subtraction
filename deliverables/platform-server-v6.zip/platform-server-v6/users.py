"""users.py — 账号 / 家庭组 / 管理密码（中心服务器口径，平台服务器端 v1）.

规则（手册 v2 §3.1、§3.4，PRD 3.1–3.4／3.6）：
- 登录、注册、绑定、管理一律走中心服务器。
- 家庭组 ID：8 位纯数字，服务端生成，终身不变；绝不用原型演示值 12345678。
- 管理密码：6 位数字，只存 PBKDF2-HMAC-SHA256 哈希 + 随机盐，绝不明文；
  登录密码同理。哈希参数沿用骨架自定值（见 ASSUMPTIONS.md V1-A11）；
  架构称“具体哈希口径未定，等技术方书面确认”，v1 不替技术方定稿。
- 注册成功后按原型走：下一步去输一次管理密码（第 11 屏），
  register() 返回 next_step="verify_admin_password"。
- 家庭组建立方式（已定）：注册时即建**虚拟**家庭组（status: "virtual"），
  首个新成员加入时翻为已固化（status: "solidified"）、ID 不变；
  一个人先注册就能直接拍题、绑终端、用卡，不用等家里人；
  先注册的人默认管理员。成员加入翻固化在本文件 register()（带邀请码）
  与 families.py 的 approve_member() 里接上（骨架暂无该接口，v1 已补）。
- 短信验证码仍是 stub：只做 4–6 位数字格式检查，不发短信、不校验真实性；
  真实短信通道未定（见 ASSUMPTIONS.md V1-A10）。注册响应里用
  "sms_code_stub": true 明标出来，不假装已验证。
- 会话：注册／登录返回 token，存内存不落盘、重启失效；verify 通过后
  该 token 记 admin_verified=true，管理类接口凭它放行（进管理输一次，
  管理内不再重复输）；过期时间与登出接口未定（见缺啥清单）。
"""
from __future__ import annotations

import hashlib
import hmac
import os
import re
import secrets

from models import member_key, new_family_group, new_member, new_user, now_iso

PHONE_RE = re.compile(r"^\d{11}$")
ADMIN_PASSWORD_RE = re.compile(r"^\d{6}$")
HASH_ITERATIONS = 120_000


class UserError(Exception):
    def __init__(self, code: str, message: str, status: int = 400):
        super().__init__(message)
        self.code = code
        self.message = message
        self.status = status


def _hash_password(password: str, salt: bytes | None = None) -> tuple[str, str]:
    salt = salt or os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"),
                                 salt, HASH_ITERATIONS)
    return digest.hex(), salt.hex()


def _check_password(password: str, stored_hash: str, salt_hex: str) -> bool:
    digest, _ = _hash_password(password, bytes.fromhex(salt_hex))
    return hmac.compare_digest(digest, stored_hash)


def _generate_family_id(store) -> str:
    """8 位纯数字，服务端生成，保证唯一；排除原型演示值 12345678。"""
    for _ in range(100):
        fid = f"{secrets.randbelow(90_000_000) + 10_000_000:08d}"
        if fid != "12345678" and fid not in store.data["families"]:
            return fid
    raise UserError("family_id_exhausted", "家庭组 ID 生成失败。", 500)


def _new_session(store, user_id: str) -> str:
    token = secrets.token_hex(24)
    store.data["sessions"][token] = {
        "user_id": user_id,
        "admin_verified": False,  # 进管理输一次管理密码后置 True
        "created_at": now_iso(),
    }
    return token


def get_session(store, token: str | None) -> dict | None:
    if not token:
        return None
    return store.data["sessions"].get(token)


def register(store, phone: str, login_password: str, admin_password: str,
             sms_code: str | None = None,
             invite_code: str | None = None) -> dict:
    with store.lock:
        if not PHONE_RE.match(phone or ""):
            raise UserError("invalid_phone", "手机号须为 11 位数字。")
        if phone in store.data["users_by_phone"]:
            raise UserError("phone_registered", "该手机号已注册。", 409)
        if not login_password or len(login_password) < 6:
            raise UserError("invalid_login_password", "登录密码至少 6 位。")
        if not ADMIN_PASSWORD_RE.match(admin_password or ""):
            raise UserError("invalid_admin_password", "管理密码须为 6 位数字。")
        # 短信验证码：stub，不校验真实性（无短信通道）；只要求填了 4-6 位数字。
        if sms_code is not None and not re.match(r"^\d{4,6}$", sms_code):
            raise UserError("invalid_sms_code", "验证码格式不正确。")
        login_hash, login_salt = _hash_password(login_password)
        admin_hash, admin_salt = _hash_password(admin_password)
        if invite_code:
            return _register_with_invite(
                store, phone, login_hash, login_salt,
                admin_hash, admin_salt, invite_code)
        family_id = _generate_family_id(store)
        user = new_user(phone, login_hash, login_salt,
                        admin_hash, admin_salt, family_id, member_no=1,
                        role="管理员")
        store.data["users"][user["id"]] = user
        store.data["users_by_phone"][phone] = user["id"]
        store.data["families"][family_id] = new_family_group(user["id"], family_id)
        store.data["members"][member_key(family_id, 1)] = new_member(
            family_id, 1, user["id"], phone, role="管理员", status="active")
        token = _new_session(store, user["id"])
        store.save()
        return {
            "user_id": user["id"],
            "phone": phone,
            "family_id": family_id,
            "member_no": 1,
            "role": "管理员",
            "token": token,
            # 按原型：注册成功后下一步去输一次管理密码（第 11 屏）。
            "next_step": "verify_admin_password",
            "sms_code_stub": True,  # 明标：验证码未真实校验（无短信通道）
            "message": "注册成功，请输一次六位管理密码进入管理。",
        }


def _register_with_invite(store, phone, login_hash, login_salt,
                          admin_hash, admin_salt, invite_code: str) -> dict:
    """凭 6 位邀请码加入已有家庭组：管理员邀请直接进组，非管理员邀请需审批；
    首个新成员正式加入时家庭组翻固化（ID 不变）。"""
    invite = store.data["invites"].get(invite_code or "")
    if invite is None:
        raise UserError("invalid_invite_code", "邀请码不正确。", 422)
    family_id = invite["family_id"]
    fam = store.data["families"].get(family_id)
    if fam is None:
        raise UserError("family_not_found", "家庭组不存在。", 404)
    member_no = fam["next_member_no"]
    fam["next_member_no"] += 1
    direct = invite["inviter_role"] == "管理员"
    role = "成员" if direct else "待审批"
    status = "active" if direct else "pending"
    user = new_user(phone, login_hash, login_salt,
                    admin_hash, admin_salt, family_id, member_no=member_no,
                    role=role)
    store.data["users"][user["id"]] = user
    store.data["users_by_phone"][phone] = user["id"]
    store.data["members"][member_key(family_id, member_no)] = new_member(
        family_id, member_no, user["id"], phone, role=role, status=status)
    if direct and fam["status"] == "virtual":
        fam["status"] = "solidified"  # 首个新成员加入，翻固化，ID 不变
    token = _new_session(store, user["id"])
    store.save()
    return {
        "user_id": user["id"],
        "phone": phone,
        "family_id": family_id,
        "member_no": member_no,
        "role": role,
        "family_status": fam["status"],
        "token": token,
        "next_step": "verify_admin_password",
        "sms_code_stub": True,
        "message": ("已加入家庭组。" if direct
                    else "邀请已提交，待管理员通过后成为正式成员。"),
    }


def login(store, phone: str, login_password: str) -> dict:
    with store.lock:
        user_id = store.data["users_by_phone"].get(phone or "")
        user = store.data["users"].get(user_id or "")
        if user is None or not _check_password(
                login_password or "", user["login_password_hash"], user["login_salt"]):
            raise UserError("invalid_credentials", "手机号或密码不正确。", 401)
        token = _new_session(store, user["id"])
        store.save()
        return {
            "user_id": user["id"],
            "phone": phone,
            "family_id": user["family_id"],
            "member_no": user.get("member_no"),
            "role": user.get("role"),
            "token": token,
            "next_step": "verify_admin_password",
            "message": "登录成功，请输一次六位管理密码进入管理。",
        }


def verify_admin_password(store, user_id: str, admin_password: str,
                          token: str | None = None) -> dict:
    """进管理时输一次 6 位管理密码；通过后该会话记 admin_verified，
    管理内不再重复输（批申请、改卡等凭此放行）。"""
    with store.lock:
        user = store.data["users"].get(user_id or "")
        if user is None:
            raise UserError("user_not_found", "账号不存在。", 404)
        if not _check_password(admin_password or "",
                              user["admin_password_hash"], user["admin_salt"]):
            raise UserError("wrong_admin_password", "管理密码不正确。", 401)
        if token:
            sess = store.data["sessions"].get(token)
            if sess is not None:
                sess["admin_verified"] = True
        return {"verified": True, "family_id": user["family_id"],
                "message": "管理密码正确，已进入管理。"}


def reset_admin_password(store, phone: str, new_admin_password: str,
                         sms_code: str | None = None) -> dict:
    """重置管理密码（第 11 屏“重置”）：手机号 → 验证码 → 重设六位。
    验证码仍是 stub（只做格式检查，不校验真实性），见模块头说明。"""
    with store.lock:
        if not PHONE_RE.match(phone or ""):
            raise UserError("invalid_phone", "手机号须为 11 位数字。")
        user_id = store.data["users_by_phone"].get(phone)
        user = store.data["users"].get(user_id or "")
        if user is None:
            raise UserError("user_not_found", "账号不存在。", 404)
        if sms_code is not None and not re.match(r"^\d{4,6}$", sms_code):
            raise UserError("invalid_sms_code", "验证码格式不正确。")
        if not ADMIN_PASSWORD_RE.match(new_admin_password or ""):
            raise UserError("invalid_admin_password", "管理密码须为 6 位数字。")
        h, s = _hash_password(new_admin_password)
        user["admin_password_hash"], user["admin_salt"] = h, s
        store.save()
        return {"reset": True, "sms_code_stub": True}


def change_login_password(store, user_id: str, old_password: str,
                          new_password: str, new_password_confirm: str | None = None) -> dict:
    with store.lock:
        user = store.data["users"].get(user_id or "")
        if user is None:
            raise UserError("user_not_found", "账号不存在。", 404)
        if not _check_password(old_password or "",
                              user["login_password_hash"], user["login_salt"]):
            raise UserError("wrong_password", "旧密码不正确。", 401)
        if len(new_password or "") < 6:
            raise UserError("invalid_login_password", "新登录密码至少 6 位。")
        if (new_password_confirm is not None
                and new_password_confirm != new_password):
            raise UserError("password_mismatch", "新密码两次输入不一致。")
        h, s = _hash_password(new_password)
        user["login_password_hash"], user["login_salt"] = h, s
        store.save()
        return {"changed": True}


def change_admin_password(store, user_id: str, new_admin_password: str) -> dict:
    """管理密码修改：按原型，直接重输一遍新六位，不用旧密码、不用输两遍。"""
    with store.lock:
        user = store.data["users"].get(user_id or "")
        if user is None:
            raise UserError("user_not_found", "账号不存在。", 404)
        if not ADMIN_PASSWORD_RE.match(new_admin_password or ""):
            raise UserError("invalid_admin_password", "管理密码须为 6 位数字。")
        h, s = _hash_password(new_admin_password)
        user["admin_password_hash"], user["admin_salt"] = h, s
        store.save()
        return {"changed": True}


def generate_invite_code(store) -> str:
    """6 位邀请码（PRD 3.6）；邀请话里的下载地址是原型占位地址，v1 不编。"""
    for _ in range(100):
        code = f"{secrets.randbelow(900_000) + 100_000:06d}"
        if code not in store.data["invites"]:
            return code
    raise UserError("invite_code_exhausted", "邀请码生成失败。", 500)
